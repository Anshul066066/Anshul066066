import {
  BrowserRouter,
  Navigate, Route, Routes
} from 'react-router-dom'
import Login from './pages/Login/Login'
import MainPanel from './components/MainPanel/MainPanel'
import PersonManagement from './pages/PersonManagement/PersonManagement'
import LoginAccountManagement from './pages/LoginAccountManagement/LoginAccountManagement'
import RoleManager from './pages/RoleManager/RoleManager'
import DesktopManager from './pages/DesktopManager/DesktopManager'
import AuditTrail from './pages/AuditTrail/AuditTrail'
import Clusters from './pages/Clusters/Clusters'
import ProcessSets from './pages/ProcessSets/ProcessSets'
import Process from './pages/Process/Process'
import UserClusters from './pages/UserClusters/UserClusters'
import Audience from './pages/Audience/Audience'
import RecordStages from './pages/RecordStages/RecordStages'
import Actions from './pages/Actions/Actions'
import MultiActions from './pages/MultiActions/MultiActions'
import Ancestors from './pages/Ancestors/Ancestors'
import Divisions from './pages/Divisions/Divisions'
import DataFields from './pages/DataFields/DataFields'
import DependentElements from './pages/DependentElements/DependentElements'
import MandatoryFields from './pages/MandatoryFields/MandatoryFields'
import ConditionallyMandatory from './pages/ConditionallyMandatory/ConditionallyMandatory'
import ConditionallyView from './pages/ConditionallyView/ConditionallyView'
import TemplateDesigner from './pages/TemplateDesigner/TemplateDesigner'
import ReportManager from './pages/ReportManager/ReportManager'
import NotificationTemplates from './pages/NotificationTemplates/NotificationTemplates'
import NotificationRules from './pages/NotificationRules/NotificationRules'
import ChildRestrictionsAutomations from './pages/ChildRestrictionsAutomations/ChildRestrictionsAutomations'
import ChildDateAutomation from './pages/ChildDateAutomation/ChildDateAutomation'
import DateUpdateAutomation from './pages/DateUpdateAutomation/DateUpdateAutomation'
import ChildAutoCreationAutomation from './pages/ChildAutoCreationAutomation/ChildAutoCreationAutomation'
import OtpVerification from './pages/Login/OtpVerification'
import AllReport from './components/AllReport/AllReport'
import PersonInformation from './pages/PersonInformation/PersonInformation'
import AddRoleManager from './pages/RoleManager/AddRoleManager'
import AddLoginAccountManagement from './pages/LoginAccountManagement/AddLoginAccountManagement'
import AddDesktopInformation from './pages/DesktopManager/AddDesktopInformation'
import EditRoleManager from './pages/RoleManager/EditRoleManager'
import AddAudience from './pages/Audience/AddAudience'
import AddAncestors from './pages/Ancestors/AddAncestors'
import AddProcessSets from './pages/ProcessSets/AddProcessSets'
import AddUserCluster from './pages/UserClusters/AddUserCluster'
import AddClusters from "./pages/Clusters/AddClusters";
import AddRecordStages from "./pages/RecordStages/AddRecordStages";
import AddDivision from "./pages/Divisions/AddDivision"
import AddMultiActions from './pages/MultiActions/AddMultiActions'
import AddActions from "./pages/Actions/AddActions";
import AddProcess from './pages/Process/AddProcess'
import AddDependentElements from './pages/DependentElements/AddDependentElements'
import AddNotificationTemplates from './pages/NotificationTemplates/AddNotificationTemplates'
import AddNotificationRules from './pages/NotificationRules/AddNotificationRules'
import AddDataFields from './pages/DataFields/AddDataFields'
import AddMandatoryFields from './pages/MandatoryFields/AddMandatoryFields'
import AddConditionallyMandatory from './pages/ConditionallyMandatory/AddConditionallyMandatory'
import AddConditionallyView from './pages/ConditionallyView/AddConditionallyView'
import AddChildDateAutomation from './pages/ChildDateAutomation/AddChildDateAutomation'
import AddDateUpdateAutomation from './pages/DateUpdateAutomation/AddDateUpdateAutomation'
import AddChildAutoCreationAutomation from './pages/ChildAutoCreationAutomation/AddChildAutoCreationAutomation'
import AddChildRestrictionsAutomations from './pages/ChildRestrictionsAutomations/AddChildRestrictionsAutomations'
import TemplateDesignerForm from './pages/TemplateManagementDes/TemplateDesignerForm'
import ReportManagerForm from './pages/ReportManagerForm/ReportManagerForm'

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/otpverification' element={<OtpVerification />} />
          <Route path='/allreport' element={<AllReport />} />

          <Route path='' element={<MainPanel />}>

            <Route path='/add-role-manager' element={<AddRoleManager />} />
            <Route path='/edit-role-manager' element={<EditRoleManager />} />
            <Route path='/person/manage' element={<PersonManagement />} />
            <Route path='/login-accounts/manage' element={<LoginAccountManagement />} />
            <Route path='/role-manager/manage' element={<RoleManager />} />
            <Route path='/desktop-manager/manage' element={<DesktopManager />} />

            <Route path='/clusters/manage' element={<Clusters />} />
            <Route path='/process-sets/manage' element={<ProcessSets />} />
            <Route path='/process/manage' element={<Process />} />
            <Route path='/add-process/manage' element={<AddProcess />} />
            <Route path='/user-clusters/manage' element={<UserClusters />} />
            <Route path='/audience/manage' element={<Audience />} />
            <Route path='/record-stages/manage' element={<RecordStages />} />
            <Route path='/actions/manage' element={<Actions />} />
            <Route path='/multi-actions/manage' element={<MultiActions />} />
            <Route path='/ancestors/manage' element={<Ancestors />} />
            <Route path='/site-location/manage' element={<Divisions />} />
            <Route path="/" element={<Login />} />
            <Route path="/otpverification" element={<OtpVerification />} />
            <Route path="/allreport" element={<AllReport />} />

            <Route path="/add-role-manager" element={<AddRoleManager />} />
            <Route path="/edit-role-manager" element={<EditRoleManager />} />
            <Route path="/person/manage" element={<PersonManagement />} />
            <Route
              path="/login-accounts/manage"
              element={<LoginAccountManagement />}
            />
            <Route path="/role-manager/manage" element={<RoleManager />} />
            <Route
              path="/desktop-manager/manage"
              element={<DesktopManager />}
            />

            <Route path="/clusters/manage" element={<Clusters />} />
            <Route path="/add-clusters" element={<AddClusters />} />
            <Route path="/process-sets/manage" element={<ProcessSets />} />
            <Route path="/process/manage" element={<Process />} />
            <Route path="/user-clusters/manage" element={<UserClusters />} />
            <Route path="/audience/manage" element={<Audience />} />
            <Route path="/record-stages/manage" element={<RecordStages />} />
            <Route path="/add-record-stage" element={<AddRecordStages />} />
            <Route path="/actions/manage" element={<Actions />} />
            <Route path="/add-item" element={<AddActions />} />
            <Route path="/multi-actions/manage" element={<MultiActions />} />
            <Route path="/ancestors/manage" element={<Ancestors />} />
            <Route path="/site-location/manage" element={<Divisions />} />

            <Route path="/data-fields/manage" element={<DataFields />} />
            <Route
              path="/dependent-elements/manage"
              element={<DependentElements />}
            />
             <Route
              path="/Add-dependent/manage"
              element={<AddDependentElements />}
            />
            <Route
              path="/mandatory-fields/manage"
              element={<MandatoryFields />}
            />
            <Route
              path="/conditionally-mandatory/manage"
              element={<ConditionallyMandatory />}
            />
            <Route
              path="/conditionally-view/manage"
              element={<ConditionallyView />}
            />

            <Route
              path="/template-designer/manage"
              element={<TemplateDesigner/>
              }
            />

            <Route
              path="/template-designer"
              element={<TemplateDesignerForm/>
             }
            />

            <Route path="/report-manager/manage" element={<ReportManager />} />
            <Route path="/report-manager" element={<ReportManagerForm/>} />


            <Route
              path="/notification-templates/manage"
              element={<NotificationTemplates />}
            />
              <Route
              path="/add-notification"
              element={<AddNotificationTemplates />}
            />
            <Route
              path="/notification-rules/manage"
              element={<NotificationRules />}
            />
              <Route
              path="/add-notification-rules"
              element={<AddNotificationRules />}
            />


            <Route path='/child-restrictions-automations/manage' element={<ChildRestrictionsAutomations />} />
            <Route path='/date-update-automation/manage' element={<DateUpdateAutomation />} />
            <Route path='/child-date-automation/manage' element={<ChildDateAutomation />} />
            <Route path='/child-auto-creation-automation/manage' element={<ChildAutoCreationAutomation />} />
            <Route path='/audit-trail' element={<AuditTrail />} />
            <Route path='/person-information' element={<PersonInformation />} />
            <Route path='/add-login-account-management' element={<AddLoginAccountManagement />} />
            <Route path='/add-desktop-information' element={<AddDesktopInformation />} />
            <Route path='/person-information' element={<PersonInformation />} />
            <Route path='/add-login-account-management' element={<AddLoginAccountManagement />} />
            <Route path='/add-desktop-information' element={<AddDesktopInformation />} />
            <Route path='/add-audience' element={<AddAudience />} />
            <Route path='/add-ancestor' element={<AddAncestors />} />
            <Route path='/add-process-set' element={<AddProcessSets />} />
            <Route path='/add-user-cluster' element={<AddUserCluster />} />
            <Route path='/add-division' element={<AddDivision />} />
            <Route path='/add-multi-action' element={<AddMultiActions />} />
            <Route path='/record-stages/manage' element={<RecordStages />} />
            <Route path='/add-datafield' element={<AddDataFields />} />
            <Route path='/add-mandatoryfields' element={<AddMandatoryFields />} />
            <Route path='/add-conditionally-mandatory' element={<AddConditionallyMandatory />} />
            <Route path='/add-conditionally-view' element={<AddConditionallyView />} />
            <Route path='/add-child-date' element={<AddChildDateAutomation />} />
            <Route path='/add-date-update' element={<AddDateUpdateAutomation />} />
            <Route path='/add-child-auto-creation' element={<AddChildAutoCreationAutomation />} />
            <Route path='/add-child-restrictions-automations' element={<AddChildRestrictionsAutomations />} />
          </Route>

          <Route path="/*" element={<Navigate to="/person/manage" />} />

        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
