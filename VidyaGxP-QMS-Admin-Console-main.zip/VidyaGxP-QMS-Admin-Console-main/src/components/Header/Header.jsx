import React, { useState } from "react";
import { AddIcon, DownAngle } from "../Icons";
import "./Header.css";
import { Link } from "react-router-dom";
import AboutModal from "../Modals/AddEntitiesModal/AboutModal";
import ContactSupportIcon from "@mui/icons-material/ContactSupport";
import LogoutIcon from "@mui/icons-material/Logout";
import InfoIcon from "@mui/icons-material/Info";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";

export default function Header() {
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const closeAddModal = () => setAddModal(false);
  const [addModal, setAddModal] = useState(false);

  const logout = () => {
    localStorage.removeItem("token");
    window.location.href = "/";
  };

  const toggleDropdown = () => {
    setIsDropdownOpen(!isDropdownOpen);
  };

  return (
    <>
      <header className="main-header border border-yellow-600 bg-white">
        <div className="inner-grid">
          <div className="logo">
            <img src="/headerlogo.png" alt="..." />
          </div>
          <div className="drop-container">
            <div className="drop-btn name-btn">
              <div className="profile-img">
                <img
                  id="avatarButton"
                  type="button"
                  //   onClick={}
                  className="w-11 h-11 rounded-full cursor-pointer"
                  src="/avatar.png"
                  alt="User dropdown"
                />
              </div>
            </div>
            <div className="drop-list">
              <div className="image">
                <div className="manager-name">Mr.Amit Guru</div>
              </div>
              <div
                to="#"
                className="drop-item"
                onClick={() => setAddModal(true)}
              >
                <InfoIcon /> About
              </div>
              {/* <div className="themeBtn" onClick={() => setAddModal(true)}>{AddIcon(20, '#000000')}Add Process Set</div> */}

              <Link to="#" className="drop-item">
                <ContactSupportIcon />
                Help
              </Link>
              <Link to="/" className="drop-item">
                <LogoutIcon />
                Logout
              </Link>
              <Link to="/" className="drop-item">
                <ManageAccountsIcon />
                Settings
              </Link>
            </div>
          </div>
        </div>
      </header>
      {addModal && <AboutModal closeModal={closeAddModal} />}
    </>
  );
}
