import { Each } from '../Each';
import { DownAngle } from '../Icons';
import { useState } from 'react'; // Import useState from React
import './DataFields.css';

function MultiSelectionField(_props) {
    const [selectValues, setSelectValues] = useState([]);
    const [open, setOpen] = useState(false)
    const toggleActive = (item) => {
        const index = selectValues.indexOf(item);
        if (index === -1) {
            setSelectValues([...selectValues, item]);
        } else {
            const newValues = [...selectValues];
            newValues.splice(index, 1);
            setSelectValues(newValues);
        }
    };

    return (
        <>
            <div className="group-input">
                <label>{_props.label}</label>
                <div className="multi-select-field">
                    <div className="item-bar" onClick={() => setOpen(!open)}>
                        <div>{selectValues.join(', ')}</div>
                        {DownAngle(15, '#000000')}
                    </div>
                    {open &&
                        <div className={`item-list ${_props.direction}`}>
                            <Each
                                of={_props.optionList}
                                render={(item, index) => (
                                    <div
                                        key={index}
                                        className={`item ${selectValues.includes(item) ? 'active' : ''}`}
                                        onClick={() => toggleActive(item)}
                                    >
                                        {item}
                                    </div>
                                )}
                            />
                        </div>
                    }
                </div>
            </div>
        </>
    );
}

export default MultiSelectionField;
