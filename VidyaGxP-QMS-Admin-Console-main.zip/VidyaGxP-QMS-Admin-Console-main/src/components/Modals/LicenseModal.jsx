import { CrossIcon } from "../Icons"

function LicenseModal(_props) {
    return (
        <>

            <div className="custom-modal size-lg">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            License Limitation <span className="red">!</span>
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div>All licenses are currently in use. Kindly contact the vendor for further assistance regarding license aspects.</div>
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1">Contact</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default LicenseModal
