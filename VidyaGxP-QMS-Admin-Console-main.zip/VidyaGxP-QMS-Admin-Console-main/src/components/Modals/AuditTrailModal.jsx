import { CrossIcon, DefaultColor } from '../Icons'
import './General.css'

function AuditTrailModal(_props) {
    const ModalTopStyle = {
        'background' : DefaultColor,
        'color': '#ffffff'
    }
    return (
        <>

            <div className="custom-modal" id="add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top" style={ModalTopStyle}>
                        <div className="head">
                            Audit Trail
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#ffffff')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="group-input">
                            <label>Rapid Summary</label>
                            <textarea disabled>{_props.element.rapidSummary}</textarea>
                        </div>
                        <div className="group-input">
                            <label>Date Performed</label>
                            <input type="text" value={_props.element.datePerformed} disabled />
                        </div>
                        <div className="group-input">
                            <label>Tier</label>
                            <input type="text" value={_props.element.tier} disabled />
                        </div>
                        <div className="group-input">
                            <label>Accountable</label>
                            <input type="text" value={_props.element.accountable} disabled />
                        </div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AuditTrailModal
