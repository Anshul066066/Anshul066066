import { useState } from 'react';
import { CrossIcon, DefaultColor, RoundedLeftIcon, RoundedRightIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'

function AddDependentElementValuesModal(_props) {
    const availableValues = ["Item 1", "Item 2", "Item 3", "Item 4", "Item 5", "Item 6", "Item 7", "Item 8", "Item 9", "Item 10"];
    const [selectedValues, setSelectedValues] = useState([]);
    const [activeIndex, setActiveIndex] = useState(null);
    const handleItemClick = (index) => {
        setActiveIndex(activeIndex === index ? null : index);
    };

    const handleRightArrowClick = () => {
        if (activeIndex !== null) {
            const selectedValue = availableValues[activeIndex];
            setSelectedValues([...selectedValues, selectedValue]);
            const updatedAvailableValues = availableValues.filter((_, i) => i !== activeIndex);
            availableValues(updatedAvailableValues);
            setActiveIndex(null);
        }
    };

    const handleLeftArrowClick = () => {
        if (activeIndex !== null) {
            const removedValue = selectedValues[activeIndex];
            setSelectedValues(selectedValues.filter((_, i) => i !== activeIndex));
            availableValues([...availableValues, removedValue]);
            setActiveIndex(null);
        }
    };
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Values Manager
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="value-manager-grid">
                            <div className="block available-values">
                                <div className="block-head">Available Values</div>
                                <div className="block-body">
                                    {availableValues.map((item, index) => (
                                        <div
                                            key={index}
                                            className={`item ${activeIndex === index ? 'active' : ''}`}
                                            onClick={() => handleItemClick(index)}
                                        >
                                            {item}
                                        </div>
                                    ))}
                                </div>
                            </div>
                            <div className="arrows">
                                <div onClick={handleLeftArrowClick}>{RoundedLeftIcon(30, DefaultColor)}</div>
                                <div onClick={handleRightArrowClick}>{RoundedRightIcon(30, DefaultColor)}</div>
                            </div>
                            <div className="block selected-values">
                                <div className="block-head">Selected Values</div>
                                <div className="block-body">
                                    {selectedValues.map((item, index) => (
                                        <div key={index} className="item">
                                            {item}
                                        </div>
                                    ))}
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddDependentElementValuesModal
