import { useEffect, useReducer, useState } from "react";
import Grid from "../../DataFields/Grid";
import { CrossIcon } from "../../Icons";
import { getCountries, getCountryCallingCode } from "libphonenumber-js";
import "../General.css";
import "./AddEntitiesModal.css";
import MultiSelectionField from "../../DataFields/MultiSelectionField";
import { useQuery } from "react-query";
import apiService from "../../../api/apiService";

function AddPersonModal(_props) {
  //   const { isPending, error, data } = useQuery({
  //     queryKey: ["repoData"],
  //     queryFn: () => fetch("https://api.github.com/repos/TanStack/query").then((res) => res.json()),
  //   });

  //   useEffect(() => {
  //     if (isPending) {
  //       console.log("Loading...");
  //     } else if (error) {
  //       console.error("An error has occurred: ", error.message);
  //     } else if (data) {
  //       console.log(data);
  //     }
  //   }, [isPending, error, data]);

  const [person, setPerson] = useReducer(
    (prev, next) => ({
      ...prev,
      ...next,
    }),
    {
      personID: "",
      profilePhoto: "",
      firstName: "",
      middleName: "",
      lastName: "",
      title: "",
      manager: "",
      gender: "",
      salutation: "",
      function: "",
      department: "",
      otherDepartment: "",
      phoneNum: "",
      mobileNum: "",
      personEmail: "",
      managerEmail: "",
      status: "",
      fax: "",

      address: "",
      postalCode: "",
      country: "",
      city: "",
      detailedAddress: "",

      comments: "",
      references: "",
    }
  );

  const handleSubmit = async () => {
    try {
      const response = await apiService.addPerson(person);
      console.log("Person Created :", response);
    } catch (error) {
      console.error("Error Creating Person :", error);
    }
  };
  //   useEffect(() => {
  //     console.log("person", person);
  //   }, [person]);
  const [countryCodes, setCountryCodes] = useState([]);
  const divisions = ["Egypt", "Estonia", "EHS-North America", "KSA"];
  useEffect(() => {
    const allCountries = getCountries();
    const codes = allCountries.map((country) => getCountryCallingCode(country));
    setCountryCodes(codes);
  }, []);
  const references = {
    id: 1,
    label: "References",
    isRequired: "false",
    instruction: "",
    columnList: [
      { id: 1.1, name: "Title of Document", type: "text" },
      { id: 1.2, name: "Attachment", type: "file" },
      { id: 1.3, name: "Remarks", type: "text" },
    ],
  };
  return (
    <>
      <div className="custom-modal add-entities-modal">
        <div className="modal-container">
          <div className="modal-top">
            <div className="head">Person Information</div>
            <div className="close-modal" onClick={_props.closeModal}>
              {CrossIcon(20, "#000000")}
            </div>
          </div>

          <div className="modal-middle">
            <div className="form-section">
              <div className="section-head">Person Details</div>
              <div className="section-body">
                <div className="dual-group-input">
                  <div className="group-input">
                    <label>Person ID</label>
                    <input value={person.personID} type="text" disabled />
                  </div>
                  <div className="group-input">
                    <label>Profile Photo</label>
                    <input
                      value={person.profilePhoto}
                      onChange={(e) =>
                        setPerson({
                          profilePhoto: e.target.value,
                        })
                      }
                      type="file"
                    />
                  </div>
                </div>
                <div className="triple-group-input">
                  <div className="group-input">
                    <label>
                      <div className="required"></div>First Name
                    </label>
                    <input
                      value={person.firstName}
                      onChange={(e) =>
                        setPerson({
                          firstName: e.target.value,
                        })
                      }
                      type="text"
                      required
                    />
                  </div>
                  <div className="group-input">
                    <label>Middle Name</label>
                    <input
                      value={person.middleName}
                      onChange={(e) =>
                        setPerson({
                          middleName: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Last Name
                    </label>
                    <input
                      value={person.lastName}
                      onChange={(e) =>
                        setPerson({
                          lastName: e.target.value,
                        })
                      }
                      type="text"
                      required
                    />
                  </div>
                </div>
                <MultiSelectionField label="Division" optionList={divisions} />
                <div className="dual-group-input">
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Title
                    </label>
                    <input
                      value={person.title}
                      onChange={(e) =>
                        setPerson({
                          title: e.target.value,
                        })
                      }
                      type="text"
                      required
                    />
                  </div>
                  <div className="group-input">
                    <label>Manager</label>
                    <select
                      value={person.manager}
                      onChange={(e) =>
                        setPerson({
                          manager: e.target.value,
                        })
                      }
                    >
                      <option value="">-- Select --</option>
                      <option value="amit_guru">Amit Guru</option>
                      <option value="shaleen_mishra">Shaleen Mishra</option>
                    </select>
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Salutation
                    </label>
                    <select
                      required
                      value={person.salutation}
                      onChange={(e) =>
                        setPerson({
                          salutation: e.target.value,
                        })
                      }
                    >
                      <option value="">-- Select --</option>
                      <option value="Ms.">Ms.</option>
                      <option value="Mr.">Mr.</option>
                      <option value="Mrs.">Mrs.</option>
                      <option value="Miss">Miss</option>
                      <option value="Dr.">Dr.</option>
                      <option value="Br.">Br.</option>
                      <option value="Sr.">Sr.</option>
                    </select>
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Gender
                    </label>
                    <select
                      required
                      value={person.gender}
                      onChange={(e) =>
                        setPerson({
                          gender: e.target.value,
                        })
                      }
                    >
                      <option value="">-- Select --</option>
                      <option value="Male">Male</option>
                      <option value="Female">Female</option>
                      <option value="Others">Others</option>
                    </select>
                  </div>
                  <div className="group-input">
                    <label>Function</label>
                    <select
                      value={person.function}
                      onChange={(e) =>
                        setPerson({
                          function: e.target.value,
                        })
                      }
                    >
                      <option value="">-- Select --</option>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Department
                    </label>
                    <select
                      value={person.department}
                      onChange={(e) => setPerson({ department: e.target.value })}
                    >
                      <option value="">-- Select --</option>
                      <option value="CQA">Corporate Quality Assurance</option>
                      <option value="QAB">Quality Assurance BioPharma</option>
                      <option value="CQC">Central Quality Control</option>
                      <option value="Manu">Manufacturing</option>
                      <option value="PSG">Plasma Sourcing Group</option>
                      <option value="CS">Central Stores</option>
                      <option value="ITG">Information Technology Group</option>
                      <option value="MM">Molecular Medicine</option>
                      <option value="CL">Central Laboratory</option>
                      <option value="TT">Tech Team</option>
                      <option value="QA">Quality Assurance</option>
                      <option value="QM">Quality Management</option>
                      <option value="IA">IT Administration</option>
                      <option value="Acc">Accounting</option>
                      <option value="Log">Logistics</option>
                      <option value="SM">Senior Management</option>
                      <option value="BA">Business Administration</option>
                      <option value="Others">Others</option>
                    </select>
                  </div>
                </div>
                {person.department === "Others" && (
                  <div className="group-input">
                    <label>Others</label>
                    <input
                      value={person.otherDepartment}
                      onChange={(e) =>
                        setPerson({
                          otherDepartment: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                )}
                <div className="dual-group-input">
                  <div className="group-input">
                    <label>Phone Number</label>
                    <div className="mobile-field">
                      <select>
                        {countryCodes.map((code, index) => (
                          //   <option key={index} value={code} selected={code === "91"}>
                          <option key={index} value={code} defaultValue={code === "91"}>
                            +{code}
                          </option>
                        ))}
                      </select>
                      <input
                        type="number"
                        value={person.phoneNum}
                        onChange={(e) =>
                          setPerson({
                            phoneNum: e.target.value,
                          })
                        }
                      />
                    </div>
                  </div>
                  <div className="group-input">
                    <label>Mobile Number</label>
                    <div className="mobile-field">
                      <select>
                        {countryCodes.map((code, index) => (
                          <option key={index} value={code} defaultValue={code === "91"}>
                            +{code}
                          </option>
                        ))}
                      </select>
                      <input
                        value={person.mobileNum}
                        onChange={(e) =>
                          setPerson({
                            mobileNum: e.target.value,
                          })
                        }
                        type="number"
                      />
                    </div>
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Person E-Mail
                    </label>
                    <input
                      value={person.personEmail}
                      onChange={(e) =>
                        setPerson({
                          personEmail: e.target.value,
                        })
                      }
                      type="email"
                      required
                    />
                  </div>
                  <div className="group-input">
                    <label>Manager E-Mail</label>
                    <input
                      value={person.managerEmail}
                      onChange={(e) =>
                        setPerson({
                          managerEmail: e.target.value,
                        })
                      }
                      type="email"
                      disabled
                    />
                  </div>
                  <div className="group-input">
                    <label>Fax</label>
                    <input
                      value={person.fax}
                      onChange={(e) =>
                        setPerson({
                          fax: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Status
                    </label>
                    <select
                      required
                      value={person.status}
                      onChange={(e) =>
                        setPerson({
                          status: e.target.value,
                        })
                      }
                    >
                      <option value="">-- Select --</option>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>
              </div>
            </div>
            <div className="form-section">
              <div className="section-head">Geographic Information</div>
              <div className="section-body">
                <div className="dual-group-input">
                  <div className="group-input">
                    <label>Address</label>
                    <input
                      value={person.address}
                      onChange={(e) =>
                        setPerson({
                          address: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                  <div className="group-input">
                    <label>Postal Code</label>
                    <input
                      value={person.postalCode}
                      onChange={(e) =>
                        setPerson({
                          postalCode: e.target.value,
                        })
                      }
                      type="number"
                    />
                  </div>
                  <div className="group-input">
                    <label>Country</label>
                    <input
                      value={person.country}
                      onChange={(e) =>
                        setPerson({
                          country: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                  <div className="group-input">
                    <label>City</label>
                    <input
                      value={person.city}
                      onChange={(e) =>
                        setPerson({
                          city: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                </div>
                <div className="group-input mb-0">
                  <label>Detailed Address</label>
                  <input
                    value={person.detailedAddress}
                    onChange={(e) =>
                      setPerson({
                        detailedAddress: e.target.value,
                      })
                    }
                    type="text"
                  />
                </div>
              </div>
            </div>
            <div className="form-section">
              <div className="section-head">Additional Details</div>
              <div className="section-body">
                <div className="group-input">
                  <label>Comments</label>
                  <textarea
                    value={person.comments}
                    onChange={(e) =>
                      setPerson({
                        comments: e.target.value,
                      })
                    }
                  ></textarea>
                </div>
                <Grid
                  label={references.label}
                  isRequired={references.isRequired}
                  instruction={references.instruction}
                  columnList={references.columnList}
                  onChange={(data) => setPerson({ references: data })}
                  //   onChange={(data) => console.log(data)}
                />
              </div>
            </div>
          </div>

          <div className="modal-bottom">
            <div className="modal-btn btn-1" onClick={handleSubmit}>
              Submit
            </div>
            <div className="modal-btn btn-2" onClick={_props.closeModal}>
              Cancel
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

export default AddPersonModal;
