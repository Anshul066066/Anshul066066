import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'

function AddActionsModal(_props) {
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Actions Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-section">
                            <div className="section-head">Details</div>
                            <div className="section-body"></div>
                        </div>
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddActionsModal
