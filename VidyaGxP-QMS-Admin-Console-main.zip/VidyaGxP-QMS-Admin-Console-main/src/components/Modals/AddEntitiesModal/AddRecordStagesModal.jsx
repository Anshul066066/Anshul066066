import { useReducer } from 'react';
import { CrossIcon } from '../../Icons';
import '../General.css';
import './AddEntitiesModal.css';

function AddRecordStagesModal(_props) {
    const [record, setRecord] = useReducer(
        (prev, next) => ({
            ...prev,
            ...next
        }),
        {
            name: "",
            description: "",
            IsRecordClosed: false,
            LockAllFields: false,
            CanCreateChildren: false
        }
    );

    const handleSubmit = () => {
        console.log(record);
        setRecord({
            name: "",
            description: "",
            IsRecordClosed: false,
            LockAllFields: false,
            CanCreateChildren: false
        })
    };

    const handleInputChange = (field) => {
        setRecord({ [field]: !record[field] }); 
       
    };

    return (
        <>
            <div className="custom-modal add-entities-modal">
                <div className="modal-container">
                    <div className="modal-top">
                        <div className="head">
                            Record Stages Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>
                    <div className="modal-middle">
                        <div className="form-section">
                            <div className="section-head">Details</div>
                            <div className="section-body">
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Name
                                    </label>
                                    <input value={record.name} onChange={(e) => setRecord({ name: e.target.value })} type="text" required />
                                </div>
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Description
                                    </label>
                                    <input value={record.description} onChange={(e) => setRecord({ description: e.target.value })} type="text" />
                                </div>
                                <div className="triple-group-input">
                                    <div className="group-input-2">
                                        <label>Is Record Closed</label>
                                        <input checked={record.IsRecordClosed} onChange={() => handleInputChange('IsRecordClosed')} type="checkbox" />
                                    </div>
                                    <div className="group-input-2">
                                        <label>Lock All Fields</label>
                                        <input checked={record.LockAllFields} onChange={() => handleInputChange('LockAllFields')} type="checkbox" />
                                    </div>
                                    <div className="group-input-2">
                                        <label>Can Create Children</label>
                                        <input checked={record.CanCreateChildren} onChange={() => handleInputChange('CanCreateChildren')} type="checkbox" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className="modal-bottom">
                        <div onClick={handleSubmit} className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>
                </div>
            </div>
        </>
    );
}

export default AddRecordStagesModal;
