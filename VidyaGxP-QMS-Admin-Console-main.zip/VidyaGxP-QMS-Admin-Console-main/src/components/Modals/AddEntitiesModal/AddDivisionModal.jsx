import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'

function AddDivisionModal(_props) {
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Site/Location Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-section">
                            <div className="section-body">
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Name
                                    </label>
                                    <input type="text" required />
                                </div>
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Description
                                    </label>
                                    <input type="text" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddDivisionModal
