import { useReducer } from 'react'
import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'

function AddProcessSetsModal(_props) {
    const [process, setProcess]=useReducer(
        (prev,next)=>({
            ...prev,...next
        }),
        {
            name:"",
            description:""
        }
    )

    const handleSubmit=()=>{
        console.log(process);
        
        setProcess({name:"",description:""})
        
    }
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Process Sets Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-section">
                            <div className="section-head">Details</div>
                            <div className="section-body">
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Name
                                    </label>
                                    <input value={process.name} onChange={(e)=>setProcess({name:e.target.value})} type="text" required />
                                </div>
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Description
                                    </label>
                                    <input value={process.description} onChange={(e)=>setProcess({description:e.target.value})}  type="text" />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal-bottom">
                        <div onClick={handleSubmit} className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddProcessSetsModal
