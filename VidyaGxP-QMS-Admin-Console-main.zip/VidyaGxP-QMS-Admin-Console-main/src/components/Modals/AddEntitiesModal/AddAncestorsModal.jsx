import { useState } from 'react'
import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'
import { Each } from '../../Each'
import Grid from '../../DataFields/Grid'

function AddAncestorsModal(_props) {
    const tabData = ["Details", "Ancestors Manager"]
    const [tab, setTab] = useState(tabData[0])
    const ancestorMatrix = {
        label: 'Ancestor Matrix',
        required: true,
        columnList: [
            { id: 1, name: 'Process Set', type: 'singleSelection', selectionValues: ["Extension", "Action Item"] },
            { id: 2, name: 'Record Stage', type: 'singleSelection', selectionValues: ["HOD Review", "Pending Change Implementation"] }
        ]
    }
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Ancestors Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-tabs">
                            <Each of={tabData} render={(item) =>
                                <div onClick={() => setTab(item)} className={tab === item ? 'active' : ''}>{item}</div>
                            } />
                        </div>
                        {tab === tabData[0] &&
                            <div className="form-section">
                                <div className="section-body">
                                    <div className="group-input">
                                        <label>
                                            <div className="required"></div>
                                            Name
                                        </label>
                                        <input type="text" required />
                                    </div>
                                    <div className="group-input">
                                        <label>
                                            <div className="required"></div>
                                            Description
                                        </label>
                                        <input type="text" />
                                    </div>
                                </div>
                            </div>
                        }
                        {tab === tabData[1] &&
                            <div className="form-section">
                                <div className="section-body">
                                    <Grid
                                        label={ancestorMatrix.label}
                                        isRequired={ancestorMatrix.required}
                                        columnList={ancestorMatrix.columnList}
                                    />
                                </div>
                            </div>
                        }
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddAncestorsModal
