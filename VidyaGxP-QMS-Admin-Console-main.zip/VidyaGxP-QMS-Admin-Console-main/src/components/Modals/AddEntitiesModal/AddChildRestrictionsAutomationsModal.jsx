import { useState } from 'react'
import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'
import { Each } from '../../Each'

function AddChildRestrictionsAutomationsModal(_props) {
    const tabData = ["Details", "Manager"]
    const [tab, setTab] = useState(tabData[0])
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Child Restrictions Automation
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-tabs">
                            <Each of={tabData} render={(item) =>
                                <div onClick={() => setTab(item)} className={tab === item ? 'active' : ''}>{item}</div>
                            } />
                        </div>
                        {tab === tabData[0] &&
                            <div className="form-section">
                                <div className="section-head"></div>
                                <div className="section-body"></div>
                            </div>
                        }
                        {tab === tabData[1] &&
                            <div className="form-section">
                                <div className="section-head"></div>
                                <div className="section-body"></div>
                            </div>
                        }
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddChildRestrictionsAutomationsModal
