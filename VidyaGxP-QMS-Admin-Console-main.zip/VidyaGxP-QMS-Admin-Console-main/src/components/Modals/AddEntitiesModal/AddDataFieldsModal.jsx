import { useReducer, useState } from 'react'
import { Each } from '../../Each'
import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'

function AddDataFieldsModal(_props) {
    const tabData = ["Details"]
    const [tab, setTab] = useState(tabData[0])
    const [data, setData] = useReducer(
        (prev, next) => ({
            ...prev, ...next
        }),
        {
            FieldName: "",
            FieldType: "",
            TriggerAPI: false,
            ApiUrl: ""
        }
    )
    const handleInputChange = (field) => {
        setData({ [field]: !data[field] });
    }

    const handleSubmit=()=>{
        console.log(data);
        
    }
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Data Fields Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-tabs">
                            <Each of={tabData} render={(item) =>
                                <div onClick={() => setTab(item)} className={tab === item ? 'active' : ''}>{item}</div>
                            } />
                        </div>
                        <div className="form-section">
                            <div className="section-body">
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Field Name
                                    </label>
                                    <input value={data.FieldName} onChange={(e)=>setData({FieldName:e.target.value})} type="text" required />
                                </div>
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Field Type
                                    </label>
                                    <select onChange={(e)=>setData({FieldType:e.target.value})}>
                                        <option value="">-- Select --</option>
                                        <option value="String" >String</option>
                                        <option value="Data" >Date</option>
                                        <option value="Number">Number</option>
                                        <option value="File">File</option>
                                        <option value="single Selection">Single Selection</option>
                                    </select>
                                </div>
                                <div className="dual-group-input">
                                    <div className="group-input-2">
                                        <label>Trigger API</label>
                                        <input checked={data.TriggerApi} onChange={() => handleInputChange('TriggerAPI')} type="checkbox" />
                                    </div>
                                    <div className="group-input">
                                        <label>API URL</label>
                                        <input value={data.ApiUrl} onChange={(e)=>setData({ApiUrl:e.target.value})} type="url" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1" onClick={handleSubmit}>Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddDataFieldsModal
