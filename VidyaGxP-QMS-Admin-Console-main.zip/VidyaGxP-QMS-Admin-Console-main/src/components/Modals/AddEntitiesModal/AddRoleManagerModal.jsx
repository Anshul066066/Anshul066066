import { useEffect, useReducer, useState } from "react";
import { Each } from '../../Each'
import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'

export default function AddRoleManagerModal(_props)  { 
    const person = ["Amit Guru", "Shaleen Mishra", "Madhulika Mishra ", "Amit Patel", "Harsh Mishra", "Anshul Jain", "Gopal Sen"]
    const [tab, setTab] = useState('General')
    const handlesubmit=()=>{
        console.log( info)
    }
    const [info, setInfo] = useReducer(
        (prev, next) => ({
          ...prev,
          ...next,
        }),
        {
           ProcessName: " ",
           Description: " "
        }
    );
    
    const [roleMatrix, setRoleMatrix] = useState({});

    const handleCheckboxChange = (personName, role) => {
        setRoleMatrix(prevState => ({
            ...prevState,
            [personName]: {
                ...prevState[personName],
                [role]: !prevState[personName]?.[role] 
            }
        }));
    };

    useEffect(() => {
        console.log(roleMatrix);
    }, [roleMatrix]);

    return (
        <>
            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Role Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-tabs">
                            <div onClick={() => setTab('General')} className={tab === 'General' ? 'active' : ''}>General Information</div>
                            <div onClick={() => setTab('roleMatrix')} className={tab === 'roleMatrix' ? 'active' : ''}>Role Matrix</div>
                        </div>
                        {tab === "General" &&
                            <div className="form-section">
                                <div className="section-head">General Information</div>
                                <div className="section-body">
                                    <div className="group-input">
                                        <label><div className="required"></div>Process Name</label>
                                        <input value={info.ProcessName} onChange={(e)=>setInfo({ProcessName:e.target.value})} type="text" required />
                                    </div>
                                    <div className="group-input">
                                        <label><div className="required"></div>Description</label>
                                        <textarea value={info.Description} onChange={(e)=>setInfo({Description:e.target.value})} required></textarea>
                                    </div>
                                </div>
                            </div>
                        }
                        {tab === "roleMatrix" &&
                            <div className="form-section">
                                <div className="section-head">Role Matrix</div>
                                <div className="section-body">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>&nbsp;</th>
                                                <th>Initiator</th>
                                                <th>HOD</th>
                                                <th>QA</th>
                                                <th>Can Create Children</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <Each of={person} render={(item, index) => (
                                                <tr key={index}>
                                                    <td>{item}</td>
                                                    <td><input type="checkbox" checked={roleMatrix[item]?.Initiator} onChange={() => handleCheckboxChange(item, 'Initiator')} /></td>
                                                    <td><input type="checkbox" checked={roleMatrix[item]?.HOD} onChange={() => handleCheckboxChange(item, 'HOD')} /></td>
                                                    <td><input type="checkbox" checked={roleMatrix[item]?.QA} onChange={() => handleCheckboxChange(item, 'QA')} /></td>
                                                    <td><input type="checkbox" checked={roleMatrix[item]?.CreateChildren} onChange={() => handleCheckboxChange(item, 'CreateChildren')} /></td>
                                                </tr>
                                            )} />
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        }

                    </div>

                    <div className="modal-bottom">
                        <div onClick={handlesubmit} className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}
