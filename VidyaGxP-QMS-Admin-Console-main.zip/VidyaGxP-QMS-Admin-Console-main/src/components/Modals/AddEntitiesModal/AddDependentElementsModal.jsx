import { useReducer, useState } from 'react'
import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'
import { Each } from '../../Each'
import AddDependentElementValuesModal from './AddDependentElementValuesModal'

function AddDependentElementsModal(_props) {
    const [DependentElements,setDependentElements]=useReducer(
        (prev,next)=>({
            ...prev,...next
        }),
        {
            name:"",
            description:"",
            ParentFieldName:"",
            ParentFieldValue:"",
            ChildFieldName:""

        }
    )
    const handleSubmit=()=>{
        console.log(DependentElements)
    }
    const tabData = ["Details", "Dependent Entities Manager"]
    const [tab, setTab] = useState(tabData[0])
    const [openModal, setOpenModal] = useState(false)
    const closeModal = () => setOpenModal(false)
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Dependent Element Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-tabs">
                            <Each of={tabData} render={(item) =>
                                <div onClick={() => setTab(item)} className={tab === item ? 'active' : ''}>{item}</div>
                            } />
                        </div>
                        {tab === tabData[0] &&
                            <div className="form-section">
                                <div className="section-body">
                                    <div className="group-input">
                                        <label> 
                                            <div className="required"></div>
                                            Name
                                        </label>
                                        <input type="text" value={DependentElements.name} onChange={(e)=>setDependentElements({name:e.target.value})} required />
                                    </div>
                                    <div className="group-input">
                                        <label>
                                            <div className="required"></div>
                                            Description
                                        </label>
                                        <input value={DependentElements.description} onChange={(e)=>setDependentElements({description:e.target.value})} type="text" required />
                                    </div>
                                </div>
                            </div>
                        }
                        {tab === tabData[1] &&
                            <div className="form-section">
                                <div className="section-body">
                                    <div className="group-input">
                                        <label>
                                            <div className="required"></div>
                                            Parent Field Name
                                        </label>
                                        <select required onChange={(e)=>setDependentElements({ParentFieldName:e.target.value})}>
                                            <option value="">-- Select --</option>
                                            <option value="test_1">Test 1</option>
                                            <option value="test_2">Test 2</option>
                                            <option value="test_3">Test 3</option>
                                            <option value="test_4">Test 4</option>
                                            <option value="test_5">Test 5</option>
                                        </select>
                                    </div>
                                    <div className="group-input">
                                        <label>
                                            <div className="required"></div>
                                            Parent Field Value
                                        </label>
                                        <select required onChange={(e)=>setDependentElements({ParentFieldValue:e.target.value})}>
                                            <option value="">-- Select --</option>
                                            <option value="test_1">Test 1</option>
                                            <option value="test_2">Test 2</option>
                                            <option value="test_3">Test 3</option>
                                            <option value="test_4">Test 4</option>
                                            <option value="test_5">Test 5</option>
                                        </select>
                                    </div>
                                    <div className="child-button-grid-field">
                                        <div className="group-input mb-0">
                                            <label>
                                                <div className="required"></div>
                                                Child Field Name
                                            </label>
                                            <select required onChange={(e)=>setDependentElements({ChildFieldName:e.target.value})}>
                                                <option value="">-- Select --</option>
                                                <option value="test_1">Test 1</option>
                                                <option value="test_2">Test 2</option>
                                                <option value="test_3">Test 3</option>
                                                <option value="test_4">Test 4</option>
                                                <option value="test_5">Test 5</option>
                                            </select>
                                        </div>
                                        <div className="launch-btn" onClick={() => setOpenModal(true)}>Launch Values</div>
                                    </div>
                                </div>
                            </div>
                        }
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1" onClick={handleSubmit}>Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

            {openModal && <AddDependentElementValuesModal closeModal={closeModal} />}

        </>
    )
}

export default AddDependentElementsModal
