import { useState } from 'react'
import { CrossIcon, EyeIcon, EyeSlashIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'
import MultiSelectionField from '../../DataFields/MultiSelectionField'

function AddDesktopManagerModal(_props) {
    const [passwordType, setPasswordType] = useState('password')
    const [tab, setTab] = useState('Desktop')
    const optionList = ["Change Control", "CAPA", "Internal Audit", "External Audit"]
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Desktop Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-tabs">
                            <div onClick={() => setTab('Desktop')} className={tab === 'Desktop' ? 'active' : ''}>Desktop Information</div>
                            <div onClick={() => setTab('Access Management')} className={tab === 'Access Management' ? 'active' : ''}>Access Management</div>
                        </div>
                        {tab === 'Desktop' &&
                            <div className="form-section">
                                <div className="section-head">Desktop Details</div>
                                <div className="section-body">
                                    <div className="dual-group-input">
                                        <div className="group-input">
                                            <label>UID</label>
                                            <input type="text" disabled />
                                        </div>
                                        <div className="group-input">
                                            <label><div className="required"></div>Login Name</label>
                                            <input type="text" required />
                                        </div>
                                        <div className="group-input">
                                            <label><div className="required"></div>Person Name</label>
                                            <select required>
                                                <option value="">-- Select --</option>
                                                <option value="amit_guru">Amit Guru</option>
                                                <option value="shaleen_mishra">Shaleen Mishra</option>
                                            </select>
                                        </div>
                                        <div className="group-input">
                                            <label><div className="required"></div>Password</label>
                                            <div className="password-field">
                                                <input type={passwordType} required />
                                                {passwordType === 'password' ?
                                                    <div onClick={() => setPasswordType('text')}>{EyeIcon(20, '#808080')}</div>
                                                    :
                                                    <div onClick={() => setPasswordType('password')}>{EyeSlashIcon(20, '#808080')}</div>
                                                }
                                            </div>
                                        </div>
                                        <div className="group-input">
                                            <label>Person E-Mail</label>
                                            <input type="email" disabled />
                                        </div>
                                        <div className="group-input">
                                            <label><div className="required"></div>Status</label>
                                            <select required>
                                                <option value="">-- Select --</option>
                                                <option value="Active">Active</option>
                                                <option value="Inactive">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                    {/* Only When Desktop is Edit */}
                                    <div className="group-input">
                                        <label>Comments</label>
                                        <textarea></textarea>
                                    </div>
                                </div>
                            </div>
                        }
                        {tab === 'Access Management' &&
                            <div className="form-section">
                                <div className="section-body">
                                    <div className="dual-group-input">
                                        <MultiSelectionField
                                            label={<div>User Interface<span className="text-themeColor">(View Only)</span></div>}
                                            optionList={optionList}
                                        />
                                        <MultiSelectionField
                                            label={<div>User Interface<span className="text-themeColor">(Supreme Administrator)</span></div>}
                                            optionList={optionList}
                                            direction="right"
                                        />
                                        <div className="group-input-2">
                                            <label>Admin Console<span className="text-themeColor">(View Only)</span></label>
                                            <input type="checkbox" />
                                        </div>
                                        <div className="group-input-2">
                                            <label>Admin Console<span className="text-themeColor">(Supreme Administrator)</span></label>
                                            <input type="checkbox" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        }
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddDesktopManagerModal
