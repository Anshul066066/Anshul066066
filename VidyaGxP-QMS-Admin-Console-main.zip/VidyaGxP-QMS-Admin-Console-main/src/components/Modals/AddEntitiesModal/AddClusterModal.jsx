import { useState, useReducer, useEffect } from 'react'
import { Each } from '../../Each'
import { CrossIcon } from '../../Icons'
import '../General.css'
import './AddEntitiesModal.css'
import Grid from '../../DataFields/Grid'

function AddClusterModal(_props) {
    const tabData = ["General Information", "Authorizations", "Tasks Progressions"]
    const [tab, setTab] = useState(tabData[0])
    const [privileges, setPrivileges] = useState({})
    const workFlow = {
        label: 'WorkFlow',
        isRequired: true,
        columnList: [
            { id: 1.1, name: "Initial Stage", type: "singleSelection", selectionValues: ["Opened", "HOD Review", "Closed-Cancelled"] },
            { id: 1.2, name: "Action", type: "singleSelection", selectionValues: ["Submit", "Cancel"] },
            { id: 1.3, name: "Destination Stage", type: "singleSelection", selectionValues: ["Opened", "HOD Review", "Closed-Cancelled"] },
        ]
    }

    const [cluster, setCluster] = useReducer(
        (prev, next) => ({
            ...prev,
            ...next,
        }),
        {
            name: "",
            configForm: "",
            description: ""

        }

    );
   
    const handlePrivilegesChange = (privilegeName, isChecked) => {
        setPrivileges(prevPrivileges => {
          
            if (!Array.isArray(prevPrivileges)) {
                prevPrivileges = [];
            }
    
          
            if (isChecked) {
            
                if (!prevPrivileges.includes(privilegeName)) {
                    return [...prevPrivileges, privilegeName];
                }
            } else {
              
                return prevPrivileges.filter(item => item !== privilegeName);
            }
            return prevPrivileges; 
        });
    };
    
    
    
    useEffect(() => {
        console.log('Privileges Checked:', privileges);
    }, [privileges]);
    return (
        <>

            <div className="custom-modal add-entities-modal">
                <div className="modal-container">

                    <div className="modal-top">
                        <div className="head">
                            Cluster Information
                        </div>
                        <div className="close-modal" onClick={_props.closeModal}>
                            {CrossIcon(20, '#000000')}
                        </div>
                    </div>

                    <div className="modal-middle">
                        <div className="form-tabs">
                            <Each of={tabData} render={(item) =>
                                <div onClick={() => setTab(item)} className={tab === item ? 'active' : ''}>{item}</div>
                            } />
                        </div>
                        {tab === tabData[0] &&
                            <div className="form-section">
                                <div className="section-body">
                                    <div className="dual-group-input">
                                        <div className="group-input">
                                            <label>
                                                <div className="required"></div>
                                                Name
                                            </label>
                                            <input value={cluster.name} onChange={(e) => setCluster({ name: e.target.value })} type="text" required />
                                        </div>
                                        <div className="group-input">
                                            <label>Config Form</label>
                                            <input value={cluster.configForm} onChange={(e) => setCluster({ configForm: e.target.value })} type="text" />
                                        </div>
                                    </div>
                                    <div className="group-input">
                                        <label>
                                            <div className="required"></div>
                                            Description
                                        </label>
                                        <input value={cluster.description} onChange={(e) => setCluster({ description: e.target.value })} type="text" required />
                                    </div>
                                </div>
                            </div>
                        }
                        {tab === tabData[1] &&
                            <>
                                <div className="form-section">
                                    <div className="section-head">Privileges</div>
                                    <div className="section-body">
                                        <div className="dual-group-input">
                                            <div className="group-input-2">
                                                <label>Can Open</label>
                                                <input onChange={(e) => handlePrivilegesChange('Can Open', e.target.checked)} type="checkbox" />
                                            </div>
                                            <div className="group-input-2">
                                                <label>Can Re-Open</label>
                                                <input onChange={(e) => handlePrivilegesChange('Can Re-Open', e.target.checked)} type="checkbox" />
                                            </div>
                                            <div className="group-input-2">
                                                <label>Can Create Children</label>
                                                <input onChange={(e) => handlePrivilegesChange('Can Create Children', e.target.checked)} type="checkbox" />
                                            </div>
                                            <div className="group-input-2">
                                                <label>Can Create as Child Only</label>
                                                <input onChange={(e) => handlePrivilegesChange('Can Create as Child Only', e.target.checked)} type="checkbox" />
                                            </div>
                                        </div>
                                        <div className="group-input-2">
                                            <label>Can Post Actions</label>
                                            <input onChange={(e) => handlePrivilegesChange('Can Post Actions', e.target.checked)} type="checkbox" />
                                        </div>
                                    </div>
                                </div>
                                <div className="form-section">
                                    <div className="section-head">Data Field Matrix</div>
                                    <div className="section-body">
                                        <table>
                                            <thead>
                                                <tr>
                                                    <th>Data Field Name</th>
                                                    <th>Field Type</th>
                                                    <th>Can View</th>
                                                    <th>Can Edit</th>
                                                    <th>Can Insert</th>
                                                    <th>Can Delete</th>
                                                </tr>
                                            </thead> 
                                            <tbody>
                                                <tr>
                                                    <td>Short Description</td>
                                                    <td>String</td>
                                                    <td><input type="checkbox" /></td>
                                                    <td><input type="checkbox" /></td>
                                                    <td><input type="checkbox" /></td>
                                                    <td><input type="checkbox" /></td>
                                                </tr>
                                                <tr>
                                                    <td>Assigned To</td>
                                                    <td>Single Selection</td>
                                                    <td><input type="checkbox" /></td>
                                                    <td><input type="checkbox" /></td>
                                                    <td><input type="checkbox" /></td>
                                                    <td><input type="checkbox" /></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </>
                        }
                        {tab === tabData[2] &&
                            <div className="form-section">
                                <div className="section-body">
                                    <Grid
                                        label={workFlow.label}
                                        isRequired={workFlow.isRequired}
                                        columnList={workFlow.columnList}
                                    />
                                </div>
                            </div>
                        }
                    </div>

                    <div className="modal-bottom">
                        <div className="modal-btn btn-1">Submit</div>
                        <div className="modal-btn btn-1">Duplicate</div>
                        <div className="modal-btn btn-2" onClick={_props.closeModal}>Cancel</div>
                    </div>

                </div>

            </div>

        </>
    )
}

export default AddClusterModal
