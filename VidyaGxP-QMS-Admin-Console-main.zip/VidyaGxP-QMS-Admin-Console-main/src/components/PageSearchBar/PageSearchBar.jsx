import { Search } from "../Icons";
import "./PageSearchBar.css";

function PageSearchBar(_props) {
  return (
    <>
      <div id="search-bar">
        {Search(20, "#848484")}
        <input
          type="text"
          value={_props.search}
          onChange={(e) => _props.setValue(e.target.value)}
          placeholder="Search..."
        />
        <div>
          <select className="mr-5">
            <option>All</option>
            <option>Active</option>
            <option>Inactive</option>
          </select>
        </div>
      </div>
    </>
  );
}

export default PageSearchBar;
