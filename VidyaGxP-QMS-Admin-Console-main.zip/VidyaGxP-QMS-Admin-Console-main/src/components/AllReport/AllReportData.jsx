export const tableHead = [
    {
        id: 1,
        th: 'Record No.'
    }, {
        id: 2, 
        th: 'Parent ID'
    }, {
        id: 3, 
        th: 'Division'
    },  {
        id: 4, 
        th: 'short description'
    }, {
        id: 5,
        th: 'Date'
    } , {
        id: 6, 
        th: 'Originator'
    },{
        id: 7, 
        th: 'Status'
    }
]

export const tableBody = [
    {
        id: "0001",
        personID: 'UID-0000001',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0002",
        personID: 'UID-0000002',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0003",
        personID: 'UID-0000003',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0004",
        personID: 'UID-0000004',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0005",
        personID: 'UID-0000005',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0006",
        personID: 'UID-0000006',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0007",
        personID: 'UID-0000007',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0007",
        personID: 'UID-0000007',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0008",
        personID: 'UID-0000008',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0009",
        personID: 'UID-0000009',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0010",
        personID: 'UID-00000010',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0011",
        personID: 'UID-00000011',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0012",
        personID: 'UID-00000012',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0013",
        personID: 'UID-00000013',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0014",
        personID: 'UID-00000014',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0015",
        personID: 'UID-00000015',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    }, {
        id: "0016",
        personID: 'UID-00000016',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    },{
        id: "0017",
        personID: 'UID-00000017',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    },{
        id: "0018",
        personID: 'UID-00000018',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    },{
        id: "0019",
        personID: 'UID-00000019',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    },{
        id: "0020",
        personID: 'UID-00000020',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    },{
        id: "0021",
        personID: 'UID-00000021',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    },{
        id: "0022",
        personID: 'UID-00000022',
        Division: 'Indore',
        Short_desc: 'Quality Assurance',
        Date: '22-04-2024',
        Originator: 'Admin',
        Status: 'Open'
    },
]