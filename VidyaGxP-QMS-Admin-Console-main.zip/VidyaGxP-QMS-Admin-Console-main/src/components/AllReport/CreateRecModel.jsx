import React from 'react'
import { useReducer, useState } from 'react'
import { Each } from '../Each'
import { CrossIcon } from '../Icons'

import './model.css'

const CreateRecModel = (_props) => {

  const [selectedOption, setSelectedOption] = useState('option1');
  const [activeItem, setActiveItem] = useState(null);
  const handleItemClick = (itemId) => {
    setActiveItem(itemId === activeItem ? null : itemId);
  };
  const [activeItem2, setActiveItem2] = useState(null);
  const handleItemClick2 = (itemId) => {
    setActiveItem2(itemId === activeItem2 ? null : itemId);
  };

  const handleChange = (event) => {
    setSelectedOption(event.target.value);
  };
  const tabData = ["Details"]
  const [tab, setTab] = useState(tabData[0])
  const [data, setData] = useReducer(
    (prev, next) => ({
      ...prev, ...next
    }),
    {
      FieldName: "",
      FieldType: "",
      TriggerAPI: false,
      ApiUrl: ""
    }
  )
  const handleInputChange = (field) => {
    setData({ [field]: !data[field] });
  }

  const handleSubmit = () => {
    console.log(data);

  }
  return (
    <>

      <div className="custom-modal add-entities-modal ">
        <div className="modal-container">

          <div className="modal-top">
            <div className="head">
              Create Record
            </div>
            <div className="close-modal" onClick={_props.closeModal}>
              {CrossIcon(20, '#000000')}
            </div>
          </div>

          <div className="modal-middle">

            <div style={{ display: "flex", fontWeight: "bold", marginBottom: "6px" }}>
              <div style={{ width: "50%" }}>
                <p className='pl-3 text-xl'>Site/Location</p>
              </div>
              <div>
                <p className='pl-3 text-xl'>Process</p>
              </div>
            </div>

            <div style={{ border: "2px solid gray", display: "flex", height: "50vh" }} className="bg-slate-50">
              <div className=' pl-2 pt-2' style={{ width: "50%", borderRight: "2px solid gray" , overflow:"auto"}}>
                <div style={{ display: "flex", cursor: "pointer" }}>
                  <div >
                    <input style={{ cursor: "pointer" }} type="radio" id="option1" name="option" value="option1" checked={selectedOption === 'option1'} onChange={() => setSelectedOption('option1')} />
                  </div>
                  <label style={{ cursor: "pointer" }} className='pl-3' for="option1">Dewas</label>
                </div>
                <div style={{ display: "flex", marginTop: "10px" }}>
                  <div>
                    <input style={{ cursor: "pointer" }} onChange={() => setSelectedOption('option2')} type="radio" id="option2" name="option" value="option1" />
                  </div>
                  <label style={{ cursor: "pointer" }} className='pl-3' for="option2" >Corporate/India</label>
                </div>
              </div>
              <div style={{ paddingTop: "8px", width: "280px", overflow: "auto" }} className=' pl-2'>
                <ul>
                  {
                    selectedOption === 'option1' && <>
                      <li className={`${activeItem === 'op1' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op1')} >Extension</li>
                      <li className={`${activeItem === 'op2' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op2')}>Root Cause Analysis</li>
                      <li className={`${activeItem === 'op3' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op3')}>Management Review</li>
                      <li className={`${activeItem === 'op4' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op4')}>CAPA</li>
                      <li className={`${activeItem === 'op5' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op5')}>Change Control</li>
                      <li className={`${activeItem === 'op6' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op6')}>Effective Check</li>
                      <li className={`${activeItem === 'op7' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op7')} >Deviation</li>

                      <li className={`${activeItem === 'op8' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op8')}>Effective Check</li>
                      <li className={`${activeItem === 'op9' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op9')} >Deviation</li>
                      <li className={`${activeItem === 'op10' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op10')}>Effective Check</li>
                      <li className={`${activeItem === 'op11' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op11')} >Deviation</li>
                      <li className={`${activeItem === 'op12' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op12')}>Effective Check</li>
                      <li className={`${activeItem === 'op13' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op13')} >Deviation</li>
                      <li className={`${activeItem === 'op15' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op15')}>Effective Check</li>
                      <li className={`${activeItem === 'op16' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op16')} >Deviation</li>
                      <li className={`${activeItem === 'op17' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op17')}>Effective Check</li>
                      <li className={`${activeItem === 'op18' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick('op18')} >Deviation</li>


                    </>

                  }

                  {
                    selectedOption === 'option2' && <> <li className={`${activeItem2 === 'op1' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                      onClick={() => handleItemClick2('op1')}>Root Cause Analysis</li>
                      <li className={`${activeItem2 === 'op2' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick2('op2')}>Extension</li>
                      <li className={`${activeItem2 === 'op3' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick2('op3')}>Extension</li>
                      <li className={`${activeItem2 === 'op4' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick2('op4')}>Extension</li>
                      <li className={`${activeItem2 === 'op5' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick2('op5')}>Extension</li>
                      <li className={`${activeItem2 === 'op6' ? 'text-blue-500' : ''} cursor-pointer pb-2`}
                        onClick={() => handleItemClick2('op6')}>Extension</li></>

                  }

                </ul>

              </div>
            </div>
          </div>

          <div className="modal-bottom">
            <div className="popupbtn bg-gray-300 hover:bg-gray-400 " onClick={_props.closeModal}>Cancel</div>
            <div style={{backgroundColor:"#2a7cbf"}} className="popupbtn" onClick={handleSubmit}>Proceed</div>

          </div>

        </div>

      </div>

    </>
  )
}

export default CreateRecModel