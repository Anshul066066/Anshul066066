import * as React from 'react';
import { useState } from 'react';

import Box from '@mui/material/Box';
import Drawer from '@mui/material/Drawer';
import AppBar from '@mui/material/AppBar';
import CssBaseline from '@mui/material/CssBaseline';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import Divider from '@mui/material/Divider';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import PublicIcon from '@mui/icons-material/Public';
import StarIcon from '@mui/icons-material/Star';
import PersonIcon from '@mui/icons-material/Person';
import BookmarkIcon from '@mui/icons-material/Bookmark';
import { FaBell } from 'react-icons/fa';
import './AllReports.css';
import { Link } from 'react-router-dom';
import AppsIcon from '@mui/icons-material/Apps';
import { Each } from "../Each";
import { tableBody, tableHead } from "./AllReportData";
import { Search } from "../Icons";
import CreateRecModel from './CreateRecModel';
import { FaChevronDown } from "react-icons/fa";
import { FaChevronUp } from "react-icons/fa";
import LibraryAddCheckIcon from '@mui/icons-material/LibraryAddCheck';
import ArticleIcon from '@mui/icons-material/Article';
import FileOpenIcon from '@mui/icons-material/FileOpen';
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';


const drawerWidth = 240;

const AllReport = () => {
  const [addModal, setAddModal] = useState(false)
  const closeAddModal = () => setAddModal(false);
  const [currentPage, setCurrentPage] = useState(1);
  const RecordsPerPage = 13
  const lastIndex = currentPage * RecordsPerPage
  const firstIndex = lastIndex - RecordsPerPage
  const records = tableBody.slice(firstIndex, lastIndex)
  const nPage = Math.ceil(tableBody.length / RecordsPerPage)
  const numbers = [...Array(nPage + 1).keys()].slice(1)

  const prePage = () => {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1)
    }
  }
  const [showMenu, setShowMenu] = useState(false);

  const changePage = (id) => {
    setCurrentPage(id)
  }

  const nextPage = () => {
    if (currentPage !== nPage) {
      setCurrentPage(currentPage + 1)
    }
  }


  const iconMapping = {
    'Favourite Views': <StarIcon />,
    'My Task': <PersonIcon />,
    'Public Views': <PublicIcon />,
    'Active Records': <BookmarkIcon />
  };

  const iconMapping2 = {
    'All Closed Records': <LibraryAddCheckIcon />,
    'All Record': <ArticleIcon />,
    'Open Record Created By Me': <FileOpenIcon />,
    'Assigned To Me': <AssignmentIndIcon />
  };


  const [showTabs, setShowTabs] = useState(true);
  const [filtershowTabs, setFilterShowTabs] = useState(false);

  const toggleTabs = () => {
    setShowTabs(!showTabs);
  }

  const filtertoggleTabs = () => {
    setFilterShowTabs(!filtershowTabs);
  }

  const [activeItem, setActiveItem] = useState('Home');
  const handleItemClick = (itemId) => {
    setActiveItem(itemId === activeItem ? null : itemId);
  };



  return (
    <>
      <Box sx={{ display: 'flex' }}>
        <CssBaseline />
        <AppBar style={{ padding: "0px", backgroundColor: "white", boxShadow: "none", color: "black", height: "62px" }} position="fixed" sx={{ zIndex: "3" }}>
          <Toolbar style={{ padding: "7px" }}>
            <div className='grid grid-cols-12   w-full'>
              <div className='col-span-4'>
                <img style={{ width: "170px", marginLeft: "10px" }} src='headerlogo.png' />

              </div>
              <div className='col-span-7' style={{ marginTop: "4px" }}>

                <div id="search-bar">
                  {Search(20, "#848484")}
                  <input
                    type="text"
                    placeholder="Search..."
                  />
                  <div className='hhhh' >
                    <select className="mr-5">
                      <option>Short Description</option>
                      <option>All Opened Record</option>
                      <option>Assigned to me</option>
                      <option>Date Opened</option>
                      <option>Due Date</option>
                      <option>Initiator</option>
                      <option>Inactive</option>

                    </select>
                  </div>
                </div>

              </div>
              <div className='col-span-1 '>
                <div style={{ float: "right", display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "2px", width: "100px" }}>
                  <div style={{}}>
                    <FaBell size={25} />

                  </div>
                  <div style={{ marginLeft: "17px" }}>
                    <div className="drop-container">
                      <div className="drop-btn name-btn">
                        <div className="profile-img">
                          <img
                            id="avatarButton"
                            type="button"
                            //   onClick={}
                            className="w-11 h-11 rounded-full cursor-pointer"
                            src="/avatar.png"
                            alt="User dropdown"
                          />
                        </div>
                      </div>
                      <div className="drop-list">
                        <div className="image">
                          <div className="manager-name">Mr.Amit Guru</div>
                        </div>

                        <Link to="#" className="drop-item">
                          <i className="ri-global-line"></i>About
                        </Link>
                        <Link to="#" className="drop-item">
                          <i className="ri-hand-heart-line"></i>Help
                        </Link>
                        <Link to="/" className="drop-item">
                          <i className="ri-logout-circle-line"></i>Logout
                        </Link>
                        <Link to="/" className="drop-item">
                          <i className="ri-logout-circle-line"></i>Settings
                        </Link>
                      </div>
                    </div>

                  </div>

                </div>
              </div>
            </div>
          </Toolbar>
        </AppBar>
        <AppBar style={{ height: "55px", padding: "0px", marginTop: "61px", backgroundColor: "whitesmoke", boxShadow: "none", borderBottom: "1px solid #efa035", width: "full", borderTop: "2px solid #efa035" }} position="fixed" sx={{ zIndex: "2" }}>
          <div style={{ height: "55px" }} className='grid sm:grid-cols-2 grid-cols-2'>

            <div id='div1' className='pl-4  flex items-center  sm:gap-x-8'>
              <li className='hidden md:block' style={{ fontSize: "1vw" }}>
                <AppsIcon style={{ color: "black" }} />
              </li>
              <div className="  md:hidden">

                <svg className="w-6 h-6 text-gray-500 cursor-pointer" viewBox="0 0 20 20" fill="currentColor" onClick={() => setShowMenu(!showMenu)}>
                  <path fillRule="evenodd" d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
                </svg>
              </div>

              <li className={`${activeItem === 'Home' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer list-none hidden md:inline`} onClick={() => handleItemClick('Home')}>Home</li>
              <li className={`${activeItem === 'dashboard' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer list-none hidden md:inline`} onClick={() => handleItemClick('dashboard')}>Dashboard</li>
              <li className={`${activeItem === 'Report' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer list-none hidden md:inline`} onClick={() => handleItemClick('Report')}>Report</li>
              <li className={`${activeItem === 'My Task' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer list-none hidden md:inline`} onClick={() => handleItemClick('My Task')}>My&nbsp;Task</li>
              <li className={`${activeItem === 'Analyse' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer list-none hidden md:inline`} onClick={() => handleItemClick('Analyse')}>Analyse</li>
            </div>

            <div id='div2' style={{ paddingRight: "30px" }} className=' p-2   '>
              <button onClick={() => setAddModal(true)} className='createbtn  float-right' style={{ border: "none", width: "150px", color: "white", height: "40px", borderRadius: "5px", marginBottom: "0px", marginLeft: "", backgroundColor: "#2a7cbf", fontWeight: "bolder" }}>
                <span style={{ fontWeight: "700", fontSize: "20px" }}>+</span> Create Record
              </button>
            </div>
          </div>





          <div className={`md:hidden ${showMenu ? 'block' : 'hidden'}   p-3`}>
            <ul className="px-4 py-1 bg-slate-400 w-32 rounded-xl  ">
              <li className={`${activeItem === 'Home' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`} onClick={() => handleItemClick('Home')}>Home</li>
              <li className={`${activeItem === 'dashboard' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`} onClick={() => handleItemClick('dashboard')}>Dashboard</li>
              <li className={`${activeItem === 'Report' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`} onClick={() => handleItemClick('Report')}>Report</li>
              <li className={`${activeItem === 'My Task' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`} onClick={() => handleItemClick('My Task')}>My Task</li>
              <li className={`${activeItem === 'Analyse' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`} onClick={() => handleItemClick('Analyse')}>Analyse</li>
            </ul>
          </div>


        </AppBar>

        {/* <AppBar style={{ display:"flex", height: "55px", paddingLeft: "0px", marginTop: "61px", backgroundColor: "whitesmoke", boxShadow: "none", borderBottom: "1px solid #efa035", width: "full", borderTop: "2px solid #efa035" }} position="fixed" sx={{ zIndex: "2" }}>

          <div style={{ marginRight: "20px", marginBottom: "12px" }}>
            <AppsIcon style={{ color: "black" }} />
          </div>
          <div style={{ marginBottom: "12px" }}>
            <h1 className={`${activeItem === 'Home' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`}
              onClick={() => handleItemClick('Home')} >Home</h1>
          </div>
          <div className='font-medium' style={{ display: "flex", color: "black", marginLeft: "2.5rem", width: "100vw", marginBottom: "12px", fontSize: "16px" }}>
            <div style={{ marginRight: "35px", fontWeight: "", cursor: "pointer" }} className="btn-bar">
              <div className={`${activeItem === 'dashboard' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`}
                onClick={() => handleItemClick('dashboard')} >
                Dashboard
              </div>
            </div>
            <div style={{ marginRight: "35px", fontWeight: "", cursor: "pointer" }} className="btn-bar">
              <div className={`${activeItem === 'Report' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`}
                onClick={() => handleItemClick('Report')} >
                Report
              </div>
            </div>
            <div style={{ marginRight: "35px", fontWeight: "", cursor: "pointer" }}>
              <div className={`${activeItem === 'My Task' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`}
                onClick={() => handleItemClick('My Task')} >
                My Task
              </div>
            </div>
            <div>
              <div className={`${activeItem === 'Analyse' ? 'text-blue-500' : 'text-gray-700'} cursor-pointer`}
                onClick={() => handleItemClick('Analyse')}>
                Analyse
              </div>
            </div>
          </div>
          <div>
            <button onClick={() => setAddModal(true)} className='createbtn ' style={{ border: "none", width: "150px", color: "white", height: "40px", borderRadius: "5px", marginBottom: "15px", marginLeft: "90px", backgroundColor: "#2a7cbf", fontWeight: "bolder" }}>
              <span style={{ fontWeight: "700", fontSize: "20px" }}>+</span> Create Record
            </button>

          </div>

        </AppBar> */}
        <Drawer
          variant="permanent"
          sx={{
            zIndex: "1",
            width: drawerWidth,
            flexShrink: 0,
            [`& .MuiDrawer-paper`]: { width: drawerWidth, boxSizing: 'border-box' },
          }}
        >
          <Toolbar />
          <Box style={{ marginTop: "40px" }} sx={{ overflow: 'auto' }}>
            <div className='pt-6 pb-3 w-full flex justify-between items-center px-4 font-bold text-[14px]' onClick={toggleTabs}>VIEWS {showTabs ? <FaChevronUp /> : <FaChevronDown />}</div>
            {showTabs && (<List style={{ color: "#2a7cbf", fontSize: "10px" }} className='!text-[10px]'>
              {['Favourite Views', 'My Task', 'Public Views', 'Active Records'].map((text, index,) => (
                <ListItem className='text-[7px]' key={text} disablePadding>
                  <ListItemButton>
                    <ListItemIcon>
                      {iconMapping[text]}
                    </ListItemIcon>
                    <ListItemText primary={text} />
                  </ListItemButton>
                </ListItem>
              ))}
            </List>)}

            <Divider />
            <div className='pt-5 w-full flex justify-between items-center px-4 font-bold text-[14px]' onClick={filtertoggleTabs}>FILTER {filtershowTabs ? <FaChevronUp /> : <FaChevronDown />}</div>
            {filtershowTabs && (<List style={{ color: "#2a7cbf", fontSize: "10px" }}>
              {['All Closed Records', 'All Record', 'Open Record Created By Me', 'Assigned To Me'].map((text, index) => (
                <ListItem key={text} disablePadding>
                  <ListItemButton>
                    <ListItemIcon>
                      {iconMapping2[text]}
                    </ListItemIcon>
                    <ListItemText primary={text} />
                  </ListItemButton>
                </ListItem>
              ))}
            </List>)}
          </Box>
        </Drawer>
        <div style={{ overflow: "auto", marginTop: "7%", position: "relative", height: "78vh", width: "100%", paddingTop: "1%" }} component="main">

          <div style={{ height: "100%", width: "100%", }} className="table_layout table-block px-2 relative">
            <table className='table_' >
              <thead style={{ border: "none" }} className="thead-colour">
                <tr>
                  <Each of={tableHead} render={(item) => <th className='table_th' >{item.th}</th>} />
                </tr>

              </thead>
              <tbody>
                <Each
                  of={records}
                  render={(item, index) => (
                    <tr className='table_tr'>
                      <td style={{ cursor: "pointer", color: "#2A7CBF" }} className="serial table_td ">{item.id}</td>
                      <td className="serial table_td ">{item.personID}</td>
                      <td className="serial table_td ">{item.Division}</td>
                      <td className="serial table_td ">{item.Short_desc}</td>
                      <td className="serial table_td">{item.Date}</td>
                      <td className="serial table_td">{item.Originator}</td>
                      <td className="serial table_td">{item.Status}</td>
                    </tr>
                  )}
                />
              </tbody>
            </table>
          </div>

        </div>

        <div className='pagination' style={{ width: "98vw", float: "right" }}>
          <nav style={{ marginTop: "15px", float: "right" }} >
            <ul class="inline-flex -space-x-px text-sm">
              <li>
                <a style={{ backgroundColor: "whitesmoke" }} onClick={prePage} href="#" class="flex items-center justify-center px-3 h-6 ms-0 leading-tight text-gray-500 bg-white border border-e-0 border-gray-300 rounded-s-lg hover:bg-black-700 hover:text-gray-700 ">Previous</a>
              </li>
              {
                numbers.map((n, i) => (

                  <li key={i}>
                    <a style={{ backgroundColor: "whitesmoke" }} onClick={() => changePage(n)} href="#" class="flex items-center justify-center px-3 h-6 leading-tight text-gray-500 bg-white border border-gray-300 hover:bg-gray-700 hover:text-black-700 ">{n}</a>
                  </li>
                ))
              }

              <li>
                <a style={{ backgroundColor: "whitesmoke" }} onClick={nextPage} href="#" class="flex items-center justify-center px-3 h-6 leading-tight text-gray-500 bg-white border border-gray-300 rounded-e-lg hover:bg-gray-700 hover:text-black-700 ">Next</a>
              </li>
            </ul>
          </nav>
        </div>
      </Box>


      {addModal && <CreateRecModel closeModal={closeAddModal} />}

    </>
  )
}

export default AllReport