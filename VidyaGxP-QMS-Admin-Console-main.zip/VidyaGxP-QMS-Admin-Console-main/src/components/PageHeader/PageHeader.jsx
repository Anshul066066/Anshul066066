import './PageHeader.css'

function PageHeader(_props) {
    return (
        <>

            <div id="page-header">
                {_props.title}
            </div>

        </>
    )
}

export default PageHeader
