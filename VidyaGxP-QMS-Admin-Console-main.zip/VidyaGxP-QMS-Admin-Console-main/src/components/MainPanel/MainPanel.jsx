import { Outlet } from 'react-router-dom'
import Header from '../Header/Header'
import Sidebar from '../Sidebar/Sidebar'
import '../../Default.css'
import './MainPanel.css'

function MainPanel() {
    return (
        <>

            <div id="main-panel-grid-block">
                <div className="header-block">
                    <Header />
                </div>
                <div className="panel-inner-grid-block">
                    <div className="sidebar-block">
                        <Sidebar />
                    </div>
                    <div className="component-outlet-block">
                        <Outlet />
                    </div>
                </div>
            </div>

        </>
    )
}

export default MainPanel
