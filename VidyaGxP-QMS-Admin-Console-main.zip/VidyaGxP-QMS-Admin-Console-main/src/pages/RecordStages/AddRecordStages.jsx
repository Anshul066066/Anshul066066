import React, { useReducer, useState } from "react";
import "./RecordStages.css";
import PageHeader from "../../components/PageHeader/PageHeader";

const AddRecordStages = () => {
  const [tab, setTab] = useState("");
  const [record, setRecord] = useReducer(
    (prev, next) => ({
      ...prev,
      ...next,
    }),
    {
      name: "",
      description: "",
      IsRecordClosed: false,
      LockAllFields: false,
      CanCreateChildren: false,
    }
  );

  const handleInputChange = (field) => {
    setRecord({ [field]: !record[field] });
  };

  return (
    <>
      <PageHeader title={<div className="text-[17px]">Record Stages</div>} />
      <div className="document-block">
        <div className="flex justify-between items-center">
          <div className="form-tabs">
            {/* <div
              onClick={() => setTab("General")}
              className={tab === "General" ? "active" : ""}
            >
              General Information
            </div> */}

            {/* <div
              onClick={() => setTab("Authorizations")}
              className={tab === "Authorizations" ? "active" : ""}
            >
              Authorizations
            </div> */}
            {/* <div
              onClick={() => setTab("Tasks Progressions")}
              className={tab === "Tasks Progressions" ? "active" : ""}
            >
              Tasks Progressions
            </div> */}
          </div>
          <div className="button-block">
            <button
              className="themeBtn"
              onClick={() => navigate("/clusters/manage")}
            >
              Save
            </button>
            <button
              className="themeBtn"
              onClick={() => navigate("/clusters/manage")}
            >
              Duplicate
            </button>
            <button
              className="themeBtn"
              onClick={() => navigate("/record-stages/manage")}
            >
              Cancel
            </button>
          </div>
        </div>

        <div className="document-form">
          <div className="sub-head">Details</div>
          <div className="section-body">
            <div className="group-input">
              <label>
                <div className="required"></div>
                Name
              </label>
              <input
                value={record.name}
                onChange={(e) => setRecord({ name: e.target.value })}
                type="text"
                required
              />
            </div>
            <div className="group-input">
              <label>
                <div className="required"></div>
                Description
              </label>
              <input
                value={record.description}
                onChange={(e) => setRecord({ description: e.target.value })}
                type="text"
              />
            </div>
            <div className="triple-group-input">
              <div className="group-input-2">
                <label>Is Record Closed</label>
                <input
                  checked={record.IsRecordClosed}
                  onChange={() => handleInputChange("IsRecordClosed")}
                  type="checkbox"
                />
              </div>
              <div className="group-input-2">
                <label>Lock All Fields</label>
                <input
                  checked={record.LockAllFields}
                  onChange={() => handleInputChange("LockAllFields")}
                  type="checkbox"
                />
              </div>
              <div className="group-input-2">
                <label>Can Create Children</label>
                <input
                  checked={record.CanCreateChildren}
                  onChange={() => handleInputChange("CanCreateChildren")}
                  type="checkbox"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddRecordStages;
