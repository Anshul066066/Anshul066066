import React, { useState } from 'react'
import PageHeader from '../../components/PageHeader/PageHeader'
import DoubleArrowIcon from '@mui/icons-material/DoubleArrow';
import { useNavigate } from 'react-router-dom';
import { Download } from '../../components/Icons';
import { Grid } from '@mui/material';
import Divider from '@mui/material/Divider';


const AddProcess = () => {
    const [tabProcess, setTabProcess] = useState("Details");
    const navigate = useNavigate();

    return (
        <>
            <PageHeader title={<div>Process</div>} />

            <div id="PersonalInformation">
                <div className="document-block">
                    <div className="flex justify-between items-center">
                        <div className="form-tabs">
                            <div
                                onClick={() => setTabProcess("Details")}
                                className={tabProcess === "Details" ? "active" : ""}
                            >
                                Details
                            </div>

                            <div
                                onClick={() => setTabProcess("User Group")}
                                className={tabProcess === "User Group" ? "active" : ""}
                            >
                                User Group
                            </div>
                            <div
                                onClick={() => setTabProcess("Membership")}
                                className={tabProcess === "Membership" ? "active" : ""}
                            >
                                Membership
                            </div>

                            <div
                                onClick={() => setTabProcess("Versions")}
                                className={tabProcess === "Versions" ? "active" : ""}
                            >
                                Versions
                            </div>
                        </div>
                        <div className="button-block">
                            <button className="themeBtn" onClick={() => navigate()}>
                                Save
                            </button>
                            <button
                                className="themeBtn"
                                onClick={() => navigate("/process/manage")}
                            >
                                Cancel
                            </button>
                            <button
                                className="themeBtn"
                            // onClick={() => navigate("/login-accounts/manage")}
                            >
                                Duplicate
                            </button>
                            <div className="themeBtn">{Download(20, "#000000")}Report</div>

                        </div>

                    </div>
                </div>

                <div className="modal-middle">
                    {tabProcess === "Details" && (
                        <div className='p-4 ' style={{marginTop:"-2%"}}>
                            <div className='p-5 document-form '>
                                <div className="sub-head" style={{ display: "flex", justifyContent: "space-between" }}>
                                    <div>
                                        Details
                                    </div>

                                </div>
                                <div>
                                    <Grid container spacing={1}>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }}>
                                            <div className='block'>
                                                <p>Name</p>
                                                <Divider />
                                                <p>Site/Division</p> <Divider />
                                                <p>Record Type</p> <Divider />
                                                <p>Process Category</p> <Divider />
                                                <p>Required Field Class</p> <Divider />
                                                <p>Notification Template</p> <Divider />
                                                <p>Notification Class</p> <Divider />
                                                <p> default value Class</p> <Divider />
                                                <p>Report Class</p> <Divider />
                                                <p>Clear Value Class</p> <Divider />
                                                <p>Auto Number Class</p> <Divider />
                                                <p>Lock  Field Class</p> <Divider />
                                                <p>Conditionally Required Field Class</p> <Divider />
                                            </div>
                                        </Grid>

                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                            <div style={{ display: "block" }}>
                                                <div >
                                                    <input style={{ border: " 1px  solid black", width: "11vw" }} />
                                                </div> <Divider />

                                                <div style={{ paddingTop: "3px" }}>
                                                    <select style={{ width: "11vw", border: " 1px  solid black", }} >
                                                        <option value="volvo">Select</option>
                                                    </select>
                                                </div> <Divider />

                                                <div style={{ paddingTop: "3px" }}>
                                                    <select style={{ width: "11vw", border: " 1px  solid black", }} >
                                                        <option value="volvo">Select</option>
                                                    </select>
                                                </div> <Divider />

                                                <div style={{ paddingTop: "3px" }}>
                                                    <select style={{ width: "11vw", border: " 1px  solid black", }} >
                                                        <option value="volvo">Select</option>
                                                    </select>
                                                </div> <Divider />

                                                <div style={{ paddingTop: "3px" }}>
                                                    <select style={{ width: "11vw", border: " 1px  solid black", }} >
                                                        <option value="volvo"></option>
                                                    </select>
                                                </div> <Divider />

                                                <div style={{ paddingTop: "3px" }}>
                                                    <select style={{ width: "11vw", border: " 1px  solid black", }} >
                                                        <option value="volvo">Default Template For Last</option>
                                                    </select>
                                                </div> <Divider />

                                                <div> &lt; No Options Found &gt;</div> <Divider />

                                                <div> &lt; No Options Found &gt;</div> <Divider />

                                                <div> &lt; No Options Found &gt;</div> <Divider />

                                                <div> &lt; No Options Found &gt;</div> <Divider />

                                                <div style={{ paddingTop: "3px" }}>
                                                    <select style={{ width: "11vw", border: " 1px  solid black", }} >
                                                        <option value="volvo"></option>
                                                    </select>
                                                </div> <Divider />

                                                <div> &lt; No Options Found &gt;</div> <Divider />







                                            </div>
                                        </Grid>

                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }} >
                                            <div className='block'>
                                                <p>Task Set</p> <Divider />
                                                <p>Depndent Date Field Class</p> <Divider />
                                                <p>Create Clildren Class</p> <Divider />
                                                <p>Concatenated Feild Class</p> <Divider />
                                                <p>Calculated Date Class</p> <Divider />
                                                <p>Calculated Number Class</p> <Divider />
                                                <p>Child Tree Display Class</p> <Divider />
                                                <p>Requre E-Signature</p> <Divider />
                                                <p>Business Days Rule</p> <Divider />
                                                <p>Date Due is Date/Time (Otherwise Date)</p> <Divider />
                                                <p>Can Close PR With Open Clildren</p> <Divider />
                                                <p>PRsCan Be Assigned To Anyone</p> <Divider />
                                                <p>Show Required Fields Tab</p> <Divider />



                                            </div>
                                        </Grid>

                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                            <div className='block'>
                                                <div> &lt; No Options Found 	&gt;</div> <Divider />
                                                <div> &lt; No Options Found 	&gt;</div> <Divider />
                                                <div> &lt; No Options Found 	&gt;</div> <Divider />
                                                <div> &lt; No Options Found 	&gt;</div> <Divider />
                                                <div> &lt; No Options Found 	&gt;</div> <Divider />
                                                <div> &lt; No Options Found 	&gt;</div> <Divider />
                                                <div> &lt; No Options Found 	&gt;</div> <Divider />
                                                <div style={{ marginLeft: "-90%" }}><input type="checkbox" /></div> <Divider />
                                                <div style={{ paddingTop: "3px" }}> <Divider />
                                                    <select style={{ width: "11vw", border: " 1px  solid black", }} >
                                                        <option value="volvo"></option>
                                                    </select>
                                                </div> <Divider />

                                                <div style={{ marginLeft: "-90%" }}><input type="checkbox" /></div> <Divider />
                                                <div style={{ marginLeft: "-90%" }}><input type="checkbox" /></div> <Divider />
                                                <div style={{ marginLeft: "-90%" }}><input type="checkbox" /></div> <Divider />
                                                <div style={{ marginLeft: "-90%" }}><input type="checkbox" /></div> <Divider />
                                                <div style={{ marginLeft: "-90%" }}><input type="checkbox" /></div> <Divider />

                                            </div>
                                        </Grid>
                                    </Grid>

                                </div>
                                <div style={{ backgroundColor: "#efa035", marginLeft: "-0.6%" }}>
                                    <p>File Store Setting</p>
                                </div>

                                <div style={{ paddingTop: "8px" }}>
                                    <Grid container spacing={1}>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }}>
                                            <div className='block'>
                                                <p>Store in File Store?</p>
                                                <Divider />

                                            </div>
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                            <div style={{ marginLeft: "-90%" }}><input type="checkbox" /></div> <Divider />

                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }} >

                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >

                                        </Grid>
                                    </Grid>

                                </div>

                                <div style={{ backgroundColor: "#efa035", marginLeft: "-0.6%" }}>
                                    <p>LiveLink Setting</p>
                                </div>

                                <div style={{ paddingTop: "8px" ,}}>
                                    <Grid container spacing={1}>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }}>
                                            <div className='block'>
                                                <p>Create Paths Class</p> <Divider />
                                                <p>Set Categories Class</p> <Divider />
                                            </div>
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                            <div> &lt; No Options Found &gt;</div> <Divider />
                                            <div> &lt; No Options Found &gt;</div> <Divider />

                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }} >
                                            <div className='block'>
                                                <p>Browse Paths Class</p>
                                            </div>
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                            <div> &lt; No Options Found 	&gt;</div> <Divider />
                                        </Grid>
                                    </Grid>

                                </div>
                                <div style={{ backgroundColor: "#efa035", marginLeft: "-0.6%" }}>
                                    <p>Documentum Settings</p>
                                </div>
                                <div style={{ paddingTop: "8px" }}>
                                    <Grid container spacing={1}>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }}>
                                            <div className='block'>
                                                <p>Lifecycle Class</p> <Divider />

                                            </div>
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                            <div> &lt; No Options Found 	&gt;</div> <Divider />

                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }} >
                                            <div className='block'>
                                            </div>
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                        </Grid>
                                    </Grid>

                                </div>
                                <div style={{ backgroundColor: "#efa035", marginLeft: "-0.6%" }}>
                                    <p>SharePoint Settings</p>
                                </div>

                                <div style={{ paddingTop: "8px" }}>
                                    <Grid container spacing={1}>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }}>
                                            <div className='block'>
                                                <p>SharePoint Site Class</p> <Divider />

                                            </div>
                                            <Divider />
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                            <div> &lt; No Options Found 	&gt;</div> <Divider />

                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }} >
                                            <div className='block'>

                                                
                                            </div>
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                        </Grid>
                                    </Grid>

                                </div>
                                <div style={{ backgroundColor: "#efa035", marginLeft: "-0.6%" }}>
                                    <p>Virtual Group Category Settings</p>
                                </div>
                                <div style={{ paddingTop: "8px" }}>
                                    <Grid container spacing={1}>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }}>
                                            <div className='block'>
                                                <p>Group Category (While Creating PR)</p> <Divider />


                                            </div>
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >

                                            <div style={{ paddingTop: "3px" }}>
                                                <select style={{ width: "11vw", border: " 1px  solid black", }} >
                                                    <option value="volvo"></option>
                                                </select>
                                            </div> <Divider />
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcd6a1" }} >
                                            <div className='block'>
                                                <p>Person Field VGC Class (while Editing PR)</p>
                                            </div>
                                        </Grid>
                                        <Grid item xs={3} sx={{ backgroundColor: "#fcf1e1" }} >
                                            <div> &lt; No Options Found &gt;</div> <Divider />
                                        </Grid>
                                    </Grid>

                                </div>



                            </div>
                        </div>
                    )}

                    {tabProcess === "User Group" && (
                        <div className='p-4 ' style={{marginTop:"-2%"}}>
                            <div className="document-form " >
                                <div className="sub-head" style={{ display: "flex", justifyContent: "space-between" }}>
                                    <div>
                                        User Group
                                    </div>

                                </div>
                                <div className="table-block">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th className="serial" style={{ justifyContent: "space-between", }}>Date <input type="checkbox" className="w-3 mr-3 " /></th>
                                                <th>Name</th>
                                                <th>Abbrv Name</th>
                                                <th>Group Category</th>
                                                <th>User Role Priority. [Clear All]</th>


                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    )}

                    {tabProcess === "Membership" && (
                        <div className='p-4 ' style={{marginTop:"-2%"}}>
                            <div className="document-form">
                                <div className="sub-head" style={{ display: "flex", justifyContent: "space-between" }}>
                                    <div>
                                        Membership
                                    </div>

                                </div>
                                <div className="table-block">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th>Process</th>
                                                <th>Person </th>
                                                <th>User Group/Group Category</th>
                                                <th>Is Member</th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    )}

                    {tabProcess === "Versions" && (
                        <div className='p-4 ' style={{marginTop:"-2%"}}>
                            <div className="document-form">
                                <div className="sub-head" style={{ display: "flex", justifyContent: "space-between" }}>
                                    <div>
                                        Versions
                                    </div>

                                </div>
                                <div className="table-block">
                                    <table>
                                        <thead>
                                            <tr>
                                                <th className="serial" style={{ justifyContent: "space-between", }}>Date <input type="checkbox" className="w-3 mr-3 " /></th>
                                                <th>Name</th>
                                                <th>Is Current</th>
                                                <th>Version Category</th>
                                                <th>Date Alpha</th>
                                                <th>Date Beta</th>
                                                <th>Date Released </th>
                                                <th>Summary </th>

                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr></tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>

        </>
    )
}

export default AddProcess