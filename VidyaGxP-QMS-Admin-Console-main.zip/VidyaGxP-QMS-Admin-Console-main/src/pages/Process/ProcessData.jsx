export const tableHead = [
    {
        th: 'Row #'
    }, {
        th: 'Name'
    }, {
        th: 'Site/Division'
    }, {
        th: ' Record Type'
    },
    {
        th: ' Process Categry'
    },
]

export const tableBody = [
    {
        id: 1,
        name:'Audit Program',
        Division: 'Global ',
        Record: 'Audit Program',
        Process:'Audit Program'
    },
    {
        id: 1,
        name:'ga',
        Division: 'ESH - North America ',
        Record: 'Audit Item',
        Process:'Addendum'
    },
]