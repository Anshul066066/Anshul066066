import { useState } from 'react';
import PageHeader from '../../components/PageHeader/PageHeader';
import { AddIcon, DefaultColor, Download, Edit,} from '../../components/Icons';
import PageSearchBar from '../../components/PageSearchBar/PageSearchBar';
import { Each } from '../../components/Each';
import './ReportManager.css'
import { tableBody, tableHead } from './ReportManagerData';
import SummarizeIcon from '@mui/icons-material/Summarize';
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import { useNavigate } from 'react-router-dom';


function ReportManager() {
    const [addModal, setAddModal] = useState(false)
    const closeAddModal = () => setAddModal(false);
    const [search, setSearch] = useState("");
    const [filterData, setFilterData] = useState(tableBody);
    const SearchValue = (value) => {
      setSearch(value);
      const filteredData = tableBody.filter((item) => {
        const lowerCaseValue = value.toLowerCase();
        const lowerCaseName = item.name.toLowerCase();
        const lowerCasePersonID = item.description.toLowerCase();
        return (
          lowerCaseName.includes(lowerCaseValue) ||
          lowerCasePersonID.includes(lowerCaseValue)
        );
      });
      setFilterData(filteredData);
    };
    const navigate=useNavigate()
    const [personactive, setPersonactive] = useState("Active");
    return (
        <>

            <PageHeader title={<div><SummarizeIcon/>Report Manager</div>} />

            <div id="report-manager-page">

                <div className="top-block">
                    <PageSearchBar  value={search} setValue={SearchValue} />
                   
                  
                   
                    <div className="btn-bar">
                        <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
                        {personactive === "Active" ? (
                            <div
                                onClick={() => setPersonactive("Inactive")}
                                className="themeBtn w-[110px]"
                            >
                                {<ToggleOffIcon />}Inactivate
                            </div>
                        ) : (
                            <div
                                className="themeBtn w-[110px]"
                                onClick={() => setPersonactive("Active")}
                            >
                                {<ToggleOnIcon />}Activate
                            </div>
                        )}
                        <div className="themeBtn">{Download(20, "#000000")}Report</div>
                        <div
                            className="themeBtn"
                            onClick={() => navigate("/report-manager")}
                        >
                            {AddIcon(20, "#000000")}Add
                        </div>
                    </div>
                </div>

                <div className="table-block">
                    <table>
                        <thead>
                            <tr>
                                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
                            </tr>
                        </thead>
                        <tbody>
                            <Each of={filterData} render={(item, index) =>
                                <tr>
                                    <td className='serial'>{index + 1}</td>
                                    <td>{item.name}</td>
                                    <td>{item.description}</td>
                                    <td>
                                        <div className="action">
                                            <div onClick={() => setAddModal(true)}>{Edit(20, DefaultColor)}</div>
                                            <div>{Download(20, '#000000')}</div>
                                        </div>
                                    </td>
                                </tr>
                            } />
                        </tbody>
                    </table>
                </div>

            </div>


        </>
    )
}

export default ReportManager
