import React, { useState, useEffect } from "react";
import "./AddDesktopInformation.css";
import PageHeader from "../../components/PageHeader/PageHeader";
import {
  Download,
  EyeIcon,
  EyeSlashIcon,
} from "../../components/Icons";
import { useNavigate } from "react-router-dom";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { TbArrowBigUpFilled } from "react-icons/tb";
import { TbArrowBigDownFilled } from "react-icons/tb";
import { TiArrowRightThick } from "react-icons/ti";
import { TiArrowLeftThick } from "react-icons/ti";
import ErrorIcon from "@mui/icons-material/Error";

const AddDesktopInformation = () => {
  const navigate = useNavigate();
  const formList = ["Information", "Layout", "Dashboard Graph"];
  const [form, setForm] = useState(formList[0]);
  const [passwordType, setPasswordType] = useState("password");
  const [leftArray, setLeftArray] = useState([
    "Change Control",
    "CAPA",
    "Internal Audit",
    "External Audit",
    "Initiator",
    "SQM",
    "CTMS",,
    "Calendar",
    "EHS",
    "Environment",
    "Documents",
    "Deviation",
    
  ]);
  
  const [rightArray, setRightArray] = useState([
    "Inspections",
    "Audit",
    "Refference",
    "CCTT",
    
  ]);

  const moveRight = () => {
    let leftElement = document.getElementsByClassName('check-left');
    for (let index = 0; index < leftElement.length; index++) {
      if (leftElement[index].checked) {
        let data = leftElement[index].value;
        let left = leftArray.filter((value) => value !== data);
        setLeftArray(left);
        rightArray.push(data);
        setRightArray(rightArray);
        break  // Important
      }
    }
  }

  const moveLeft = () => {
    let rightElement = document.getElementsByClassName('check-right');
    for (let index = 0; index < rightElement.length; index++) {
      if (rightElement[index].checked) {
        let data = rightElement[index].value;
        let right = rightArray.filter((value) => value !== data);
        setRightArray(right);
        leftArray.push(data);
        setLeftArray(leftArray);
        break         // Important
      }
    }
  }

  const clicked = () => {
    let checkboxes = document.querySelectorAll('.check-left, .check-right');
    checkboxes.forEach((checkbox) => {
      checkbox.checked = false;
    });
    let allLabels = document.querySelectorAll('.labels');
    allLabels.forEach((label) => {
      label.classList.remove('clicked');
    });
    
    let label = event.target;
    label.classList.add('clicked');
    label.checked = true;
  };

  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">Desktop Information</div>}
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
              <button
                className="themeBtn"
                onClick={() => {
                  handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/desktop-manager/manage")}
              >
                Cancel
              </button>
              <div className="themeBtn">{Download(20, "#000000")}Report</div>
            </div>
          </div>
        </div>

        {form === formList[0] ? (
          <div className="document-form">
            <div className="sub-head">Desktop Details</div>
            <div className="personal-info">
              <div className="section-body">
                <div className="">
                  <div className="group-input">
                    <label>Name</label>
                    <input type="text" />
                  </div>
                
                </div>
                {/* Only When Desktop is Edit */}
                <div className="group-input">
                  <label>Description</label>
                  <textarea></textarea>
                </div>
              </div>
            </div>
          </div>
        ) : form === formList[1] ? (
          <div className="document-form">
            <div className="sub-head">Layout</div>
            <div className="btn-bar flex gap-2 float-right mb-2">
              <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
              <div className="themeBtn">{<ContentCopyIcon />}Duplicate</div>
              <div className="themeBtn">{Download(20, "#000000")}Report</div>
            </div>
            <div className="personal-info">
              <div className="section-body">
                <div className="table-block px-2">
                  <table>
                    <thead className="thead-colour">
                      <tr>
                        <th>Row</th>
                        <th>Column Position</th>
                        <th>Data Field</th>
                        <th>Source</th>
                        <th>Displayed Column Name</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          1<TbArrowBigDownFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="cars" id="cars">
                                <option value="volvo">Parent Id</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          2<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="cars" id="cars">
                                <option value="volvo">Site/Division</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          3<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Process</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          4<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Short Discription</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          5<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Date Opened</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          6<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Date Due</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          7<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Assigned To</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          8<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">State</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          9
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Originator</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="pt-5">
              <div className="sub-head mt-2">Desktop Table Preview</div>
              <table className="">
                <thead style={{ backgroundColor: "#fcd6a1 !important" }}>
                  <tr>
                    <th style={{ backgroundColor: "#fcd6a1" }}>1</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>2</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>3</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>4</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>5</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>6</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>7</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>8</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>9</th>
                  </tr>
                  <tr>
                    <th>Row</th>
                    <th>Parent ID</th>
                    <th>Division</th>
                    <th>Process</th>
                    <th>Short Description</th>
                    <th>Date Opened</th>
                    <th>Date Due</th>
                    <th>Assigned To</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : form === formList[2] ? (
          <div className="document-form">
            <div className="sub-head">Dashboard Graph</div>
            <div className="container">
              <div className="sub-container">
                <h3 style={{fontWeight: "bold"}}>Available Dashboards</h3>
                <div className="list-container">
                  <ul>
                    {leftArray.map((data) =>
                      <li key={data}><input type="checkbox" value={data} id={data} className="check-left"/><label className="labels" htmlFor={data} onClick={clicked}>{data}</label></li>
                    )}
                  </ul>
                </div>
              </div>
              <div className="mid-container">
                <button className="arrow-button" onClick={moveRight}><TiArrowRightThick /></button>
                <button className="arrow-button" onClick={moveLeft}><TiArrowLeftThick /></button>
              </div>
              <div className="sub-container">
                <h3 style={{fontWeight: "bold"}}>Dashboards In Class</h3>
                <div className="list-container">
                  <ul>
                    {rightArray.map((data) =>
                      <li key={data}><input type="checkbox" value={data} id={data} className="check-right"/><label className="labels" htmlFor={data} onClick={clicked}>{data}</label></li>
                    )}                
                  </ul>
                </div>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
};

export default AddDesktopInformation;
