export const tableHead = [
    {
        id: 1,
        th: 'Row #'
    }, {
        id: 2,
        th: 'Process Name'
    }, {
        id: 3,
        th: 'Description'
    }, {
        id: 6,
        th: 'Action'
    },
]

export const tableBody = [
    {
        id: 1,
        processName: 'Internal Audit',
        description: 'Test'
    }, {
        id: 2,
        processName: 'External Audit',
        description: 'Test'
    }, {
        id: 3,
        processName: 'Change Control ',
        description: 'Test'
    }, {
        id: 4,
        processName: 'CAPA',
        description: 'Test'
    }, {
        id: 5,
        processName: 'Audit Program',
        description: 'Test'
    }, {
        id: 6,
        processName: 'Lab Incident',
        description: 'Test'
    },
]