import { useState } from "react";
import { Each } from "../../components/Each";
import { tableBody, tableHead } from "./DesktopManagerData";
import { AddIcon, DefaultColor, Download, Edit } from "../../components/Icons";
import PageHeader from "../../components/PageHeader/PageHeader";
import PageSearchBar from "../../components/PageSearchBar/PageSearchBar";
import AddDesktopModal from "../../components/Modals/AddEntitiesModal/AddDesktopManagerModal";
import "./DesktopManager.css";
import { TbDeviceDesktopCog } from "react-icons/tb";
import { useNavigate } from "react-router-dom";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ConnectedTvIcon from "@mui/icons-material/ConnectedTv";

const DesktopManager = () => {
  const navigation = useNavigate();
  const [DesktopManagerModal, setDesktopManagerModal] = useState(false);
  const [activedesktop, setActivedesktop] = useState("Active");
  const closeAddAccessModal = () => setDesktopManagerModal(false);
  const [search, setSearch] = useState("");
  const [filterData, setFilterData] = useState(tableBody);
  const SearchValue = (value) => {
    setSearch(value);
    const filteredData = tableBody.filter((item) => {
      const lowerCaseValue = value.toLowerCase();
      const lowerCaseName = item.processName.toLowerCase();
      const lowerCasePersonID = item.description.toLowerCase();
      return (
        lowerCaseName.includes(lowerCaseValue) ||
        lowerCasePersonID.includes(lowerCaseValue)
      );
    });
    setFilterData(filteredData);
  };
  return (
    <>
      <PageHeader
        title={
          <div className="text-[17px]">
            <ConnectedTvIcon /> Desktop Manager
          </div>
        }
      />

      <div id="desktop-manager-page">
        <div className="top-block">
          <PageSearchBar value={search} setValue={SearchValue} />
          <div className="btn-bar">
            <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
            {activedesktop === "Active" ? (
              <div
                onClick={() => setActivedesktop("Inactive")}
                className="themeBtn w-[110px]"
              >
                {<ToggleOffIcon />}Inactivate
              </div>
            ) : (
              <div
                className="themeBtn w-[110px]"
                onClick={() => setActivedesktop("Active")}
              >
                {<ToggleOnIcon />}Activate
              </div>
            )}
            <div className="themeBtn">{Download(20, "#000000")}Report</div>

            <div
              className="themeBtn"
              onClick={() => navigation("/add-desktop-information")}
            >
              {AddIcon(20, "#000000")}Add
            </div>
          </div>
        </div>

        <div className="table-block">
          <table>
            <thead>
              <tr>
                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
              </tr>
            </thead>
            <tbody>
              <Each
                of={filterData}
                render={(item, index) => (
                  <tr>
                    {/* <td className="serial">{index + 1}</td> */}
                    <td
                      className="serial"
                      style={{ justifyContent: "space-between" }}
                    >
                      <input type="checkbox" className="w-3 mr-3" />
                      {index + 1}
                    </td>
                    <td>{item.processName}</td>
                    <td>{item.description}</td>
                    <td>
                      <div className="action">
                        <div onClick={() => setDesktopManagerModal(true)}>
                          {Edit(20, DefaultColor)}
                        </div>
                        <div>{Download(20, "#000000")}</div>
                      </div>
                    </td>
                  </tr>
                )}
              />
            </tbody>
          </table>
        </div>
      </div>

      {DesktopManagerModal && (
        <AddDesktopModal closeModal={closeAddAccessModal} />
      )}
    </>
  );
};

export default DesktopManager;
