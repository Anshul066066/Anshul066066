import { useReducer, useState } from "react";
import { useNavigate } from "react-router-dom";
import PageHeader from "../../components/PageHeader/PageHeader";

function AddMandatoryFields() {
  const navigate = useNavigate();
  const formList = ["Details", "Mandatory Fields"];
  const [form, setForm] = useState(formList[0]);
  const [details, setDetails] = useReducer(
    (prev, next) => ({
      ...prev,
      ...next,
    }),
    {
      Name: "",
      Description: "",
    }
  );
  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={
            <div className="text-[17px]">Mandatory Fields Information</div>
          }
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
              <button className="themeBtn">Duplicate</button>
              <button
                className="themeBtn"
                onClick={() => {
                  handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/mandatory-fields/manage")}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>

        {form === formList[0] ? (
          <div className="document-form">
            <div className="sub-head">Details</div>
            <div className="personal-info">
              <div className="section-body">
                <div className="group-input">
                  <label>
                    <div className="required"></div>
                    Name
                  </label>
                  <input
                    value={details.Name}
                    onChange={(e) => setDetails({ Name: e.target.value })}
                    type="text"
                    required
                  />
                </div>
                <div className="group-input">
                  <label>
                    <div className="required"></div>
                    Description
                  </label>
                  <input
                    value={details.Description}
                    onChange={(e) =>
                      setDetails({ Description: e.target.value })
                    }
                    type="text"
                    required
                  />
                </div>
              </div>
            </div>
          </div>
        ) : form === formList[1] ? (
          <div className="document-form">
            <div className="sub-head">Mandatory Fields</div>
            <div className="personal-info">
              <div className="section-body"></div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
}

export default AddMandatoryFields;
