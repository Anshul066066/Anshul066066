import { useEffect, useState } from "react";
import PageHeader from "../../components/PageHeader/PageHeader";
import PageSearchBar from "../../components/PageSearchBar/PageSearchBar";
import { tableBody, tableHead } from "./PersonManagementData";
import { Each } from "../../components/Each";
import {
  AddIcon,
  DefaultColor,
  Download,
  Edit,
} from "../../components/Icons";
import "./PersonManagement.css";
import apiService from "../../api/apiService";
import { Link, useNavigate } from "react-router-dom";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ManageAccountsIcon from "@mui/icons-material/ManageAccounts";

function PersonManagement() {
  const navigation = useNavigate();
  const [allPersons, setallPersons] = useState([]);
  const [personactive, setPersonactive] = useState("Active");
  const closeAddPersonModal = () => setAddPersonModal(false);
  const [search, setSearch] = useState("");
  const [filterData, setFilterData] = useState(tableBody);
  const SearchValue = (value) => {
    setSearch(value);
    const filteredData = tableBody.filter((item) => {
      const lowerCaseValue = value.toLowerCase();
      const lowerCaseName = item.name.toLowerCase();
      const lowerCasePersonID = item.personID.toLowerCase();
      return (
        lowerCaseName.includes(lowerCaseValue) ||
        lowerCasePersonID.includes(lowerCaseValue)
      );
    });
    setFilterData(filteredData);
  };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await apiService.getallPersons();
        setallPersons(response);
      } catch (error) {
        console.error("Error fetching all persons:", error);
      }
    };
    fetchData();
  }, []);
  return (
    <>
      <PageHeader
        title={
          <div className="text-[17px]">
            <ManageAccountsIcon />
            Person Management
          </div>
        }
      />

      <div id="person-management-page">
        <div className="top-block">
          <PageSearchBar value={search} setValue={SearchValue} />

          <div className="btn-bar">
            <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
            {personactive === "Active" ? (
              <div
                onClick={() => setPersonactive("Inactive")}
                className="themeBtn w-[110px]"
              >
                {<ToggleOffIcon />}Inactivate
              </div>
            ) : (
              <div
                className="themeBtn w-[110px]"
                onClick={() => setPersonactive("Active")}
              >
                {<ToggleOnIcon />}Activate
              </div>
            )}
            <div className="themeBtn">{Download(20, "#000000")}Report</div>
            <div
              className="themeBtn"
              onClick={() => navigation("/person-information")}
            >
              {AddIcon(20, "#000000")}Add
            </div>
          </div>
        </div>

        <div className="table-block px-2">
          <table>
            <thead className="thead-colour">
              <tr>
                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
              </tr>
            </thead>
            <tbody>
              <Each
                of={filterData}
                render={(item, index) => (
                  <tr>
                    {/* <td className="serial">{index + 1}</td> */}
                    <td
                      className="serial"
                      style={{ justifyContent: "space-between" }}
                    >
                      <input type="checkbox" className="w-3 mr-3" />
                      {index + 1}
                    </td>
                    <td>{item.personID}</td>
                    <td>{item.name}</td>
                    <td>{item.department}</td>
                    <td>{item.mail}</td>
                    <td>
                      <div className="action">
                        <Link to="/person-information">
                          <div>{Edit(20, DefaultColor)}</div>
                        </Link>
                        <div>{Download(20, "#000000")}</div>
                      </div>
                    </td>
                  </tr>
                )}
              />
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

export default PersonManagement;
