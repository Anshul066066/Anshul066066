export const tableHead = [
    {
        id: 1,
        th: 'Row #'
    }, {
        id: 2, 
        th: 'Person ID'
    }, {
        id: 3, 
        th: 'Name'
    },  {
        id: 4, 
        th: 'Department'
    }, {
        id: 5,
        th: 'Mail ID'
    } , {
        id: 6, 
        th: 'Action'
    },
]

export const tableBody = [
    {
        id: 1,
        personID: 'UID-0000001',
        name: 'Amit Guru',
        department: 'Quality Assurance',
        mail: 'amit.guru@connexo.io',
    }, {
        id: 2,
        name: 'Shaleen Mishra',
        personID: 'UID-0000002',
        department: 'Quality Assurance',
        mail: 'shaleen.mishra@connexo.io',
    }, {
        id: 3,
        name: 'Madhulika Mishra',
        personID: 'UID-0000003',
        department: 'Quality Assurance',
        mail: 'madhulika.mishra@connexo.io',
    }, {
        id: 4,
        name: 'Amit Patel',
        personID: 'UID-0000004',
        department: 'Quality Assurance',
        mail: 'amit.patel@connexo.io',
    }, {
        id: 5,
        name: 'Anshul Jain',
        personID: 'UID-0000005',
        department: 'Quality Assurance',
        mail: 'anshul.jain@connexo.io',
    }, {
        id: 6,
        name: 'Gopal Sen',
        personID: 'UID-0000006',
        department: 'Quality Assurance',
        mail: 'gopal.sen@connexo.io',
    }, {
        id: 6,
        name: 'Pankaj Jat',
        personID: 'UID-0000007',
        department: 'Quality Assurance',
        mail: 'Pankaj.jat@connexo.io',
    }, 
]