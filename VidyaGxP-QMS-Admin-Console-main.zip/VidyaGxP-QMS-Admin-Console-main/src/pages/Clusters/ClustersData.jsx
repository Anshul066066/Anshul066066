export const tableHead = [
    {
        th: 'Row #'
    }, {
        th: 'Name'
    }, {
        th: 'Config Form'
    }, {
        th: 'Action'
    },
]

export const tableBody = [
    {
        id: 1,
        name: 'Test',
        configForm: 'Test'
    }
]