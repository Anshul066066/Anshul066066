import React, { useReducer, useState } from "react";
import "./Clusters.css";
import PageHeader from "../../components/PageHeader/PageHeader";
import Grid from "../../components/DataFields/Grid";
import { useNavigate } from "react-router-dom";
import DoorBackIcon from '@mui/icons-material/DoorBack';


const AddClusters = () => {
  const [tab, setTab] = useState("General");
  const [privileges, setPrivileges] = useState({});
  const navigate = useNavigate();
  const [cluster, setCluster] = useReducer(
    (prev, next) => ({
      ...prev,
      ...next,
    }),
    {
      name: "",
      configForm: "",
      description: "",
    }
  );

  const workFlow = {
    label: "WorkFlow",
    isRequired: true,
    columnList: [
      {
        id: 1.1,
        name: "Initial Stage",
        type: "singleSelection",
        selectionValues: ["Opened", "HOD Review", "Closed-Cancelled"],
      },
      {
        id: 1.2,
        name: "Action",
        type: "singleSelection",
        selectionValues: ["Submit", "Cancel"],
      },
      {
        id: 1.3,
        name: "Destination Stage",
        type: "singleSelection",
        selectionValues: ["Opened", "HOD Review", "Closed-Cancelled"],
      },
    ],
  };

  const handlePrivilegesChange = (privilegeName, isChecked) => {
    setPrivileges((prevPrivileges) => {
      if (!Array.isArray(prevPrivileges)) {
        prevPrivileges = [];
      }

      if (isChecked) {
        if (!prevPrivileges.includes(privilegeName)) {
          return [...prevPrivileges, privilegeName];
        }
      } else {
        return prevPrivileges.filter((item) => item !== privilegeName);
      }
      return prevPrivileges;
    });
  };
  return (
    <div>
      <PageHeader title={<div className="text-[17px]"><DoorBackIcon sx={{color:"#00000"}}/>Clusters</div>} />
      <div className="document-block">
        <div className="flex justify-between items-center">
          <div className="form-tabs">
            <div
              onClick={() => setTab("General")}
              className={tab === "General" ? "active" : ""}
            >
              Details
            </div>

            <div
              onClick={() => setTab("Authorizations")}
              className={tab === "Authorizations" ? "active" : ""}
            >
              Permissions
            </div>
            <div
              onClick={() => setTab("Tasks Progressions")}
              className={tab === "Tasks Progressions" ? "active" : ""}
            >
              Work Flow
            </div>
          </div>
          <div className="button-block">
            <button
              className="themeBtn"
              onClick={() => navigate("/clusters/manage")}
            >
              Save
            </button>
            <button
              className="themeBtn"
              onClick={() => navigate("/clusters/manage")}
            >
              Duplicate
            </button>
            <button
              className="themeBtn"
              onClick={() => navigate("/clusters/manage")}
            >
              Cancel
            </button>
          </div>
        </div>

        {tab === "General" ? (
          <div className="document-form">
            <div className="sub-head"> General Information</div>
            <div className="section-body">
              <div className="dual-group-input">
                <div className="group-input">
                  <label>
                    <div className="required"></div>
                    Name
                  </label>
                  <input
                    value={cluster.name}
                    onChange={(e) => setCluster({ name: e.target.value })}
                    type="text"
                    required
                  />
                </div>
                <div className="group-input">
                  <label>Config Form</label>

                  <select
                    onChange={(e) => setCluster({ configForm: e.target.value })}
                  >
                    <option value={""}>----select----</option>
                    <option value={"yes"}>Yes</option>
                    <option value={"no"}>No</option>
                  </select>
                </div>
              </div>
              <div className="dual-group-input">
              <div className="group-input">
                <label>
                  <div className="required"></div>
                  Abbrv Name
                </label>
                <input
                  value={cluster.description}
                  onChange={(e) => setCluster({ description: e.target.value })}
                  type="text"
                  required
                />
              </div>
              <div className="group-input">
                  <label>Activity Location</label>

                  <select
                    onChange={(e) => setCluster({ configForm: e.target.value })}
                  >
                    <option value={""}>----select----</option>
                    <option value={"yes"}>Yes</option>
                    <option value={"no"}>No</option>
                  </select>
                </div>
                </div>
                <div className="group-input">
                  <label>Report Class</label>

                  <select
                    onChange={(e) => setCluster({ configForm: e.target.value })}
                  >
                 
                    <option value={"yes"}>No Option Available</option>
              
                  </select>
                </div>
            </div>
          </div>
        ) : null}

        {tab === "Authorizations" ? (
          <>
            <div className="document-form">
              <div className="sub-head">Privileges</div>
              <div className="section-body">
                <div className="dual-group-input">
                  <div className="group-input-2">
                    <label>Can Open</label>
                    <input
                      onChange={(e) =>
                        handlePrivilegesChange("Can Open", e.target.checked)
                      }
                      type="checkbox"
                    />
                  </div>
                  <div className="group-input-2">
                    <label>Can Re-Open</label>
                    <input
                      onChange={(e) =>
                        handlePrivilegesChange("Can Re-Open", e.target.checked)
                      }
                      type="checkbox"
                    />
                  </div>
                  <div className="group-input-2">
                    <label>Can Create Children</label>
                    <input
                      onChange={(e) =>
                        handlePrivilegesChange(
                          "Can Create Children",
                          e.target.checked
                        )
                      }
                      type="checkbox"
                    />
                  </div>
                  <div className="group-input-2">
                    <label>Can Create as Child Only</label>
                    <input
                      onChange={(e) =>
                        handlePrivilegesChange(
                          "Can Create as Child Only",
                          e.target.checked
                        )
                      }
                      type="checkbox"
                    />
                  </div>
                </div>
                <div className="group-input-2">
                  <label>Can Post Actions</label>
                  <input
                    onChange={(e) =>
                      handlePrivilegesChange(
                        "Can Post Actions",
                        e.target.checked
                      )
                    }
                    type="checkbox"
                  />
                </div>
              </div>
              <div className="sub-head mt-5">Data Field Matrix</div>
              <div className="section-body">
                <table>
                  <thead>
                    <tr>
                      <th>Data Field Name</th>
                      <th>Field Type</th>
                      <th>Can View</th>
                      <th>Can Edit</th>
                      <th>Can Insert</th>
                      <th>Can Delete</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Short Description</td>
                      <td>String</td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                    </tr>
                    <tr>
                      <td>Assigned To</td>
                      <td>Single Selection</td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </>
        ) : null}
        {tab === "Tasks Progressions" ? (
          <>
            <div className="document-form">
              <div className="form-section">
                <div className="section-body">
                  <Grid
                    label={workFlow.label}
                    isRequired={workFlow.isRequired}
                    columnList={workFlow.columnList}
                  />
                </div>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
};

export default AddClusters;
