import React, { useState } from 'react'
import {Download} from "../../components/Icons";
import PageHeader from "../../components/PageHeader/PageHeader";
import "../PersonInformation/PersonInformation.css";
import { useNavigate } from "react-router-dom";

function AddLoginAccountManagement(_props) {
  const [tab, setTab] = useState("Details");
  const navigate = useNavigate();
  return (
    <>
      <PageHeader
        title={<div className="text-[17px]">Multi Action Information</div>}
      />

      <div id="PersonalInformation">
        <div className="document-block">
          <div className="flex justify-between items-center">
            <div className="form-tabs">
              <div
                onClick={() => setTab("Details")}
                className={tab === "Details" ? "active" : ""}
              >
               Details
              </div>

              <div
                onClick={() => setTab("Multi Actions")}
                className={tab === "Multi Actions" ? "active" : ""}
              >
               Multi Actions
              </div>
              
            </div>
            <div className="button-block">
              <button className="themeBtn" onClick={() => navigate()}>
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/multi-actions/manage")}
              >
                Cancel
              </button>
              <div className="themeBtn">{Download(20, "#000000")}Report</div>
            </div>
          </div>

          <div className="modal-middle">
            {tab === "Details" && (
              <div className="document-form">
                <div className="sub-head"></div>
            
              </div>
            )}

            {tab === "Multi Actions" && (
              <div className="document-form">
                <div className="sub-head"></div>
                
              </div>
            )}

           
          </div>
        </div>
      </div>
    </>
  );
}

export default AddLoginAccountManagement;
