import React, { useEffect, useReducer, useState } from "react";
import PageHeader from "../../components/PageHeader/PageHeader";
import "./TemplateDesigner.css";
import { getCountries, getCountryCallingCode } from "libphonenumber-js";
import MultiSelectionField from "../../components/DataFields/MultiSelectionField";
import Grid from "../../components/DataFields/Grid";
import { useNavigate } from "react-router-dom";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

function TemplateDesignerForm() {
  const [countryCodes, setCountryCodes] = useState([]);
  const divisions = ["Egypt", "Estonia", "EHS-North America", "KSA"];
  const [search, setSearch] = useState("");
  const navigate = useNavigate();
  // ===========================================validation============================================//
  // ==================firstName========//
  const [firstName, setFirstName] = useState("");
  const [firstNameError, setFirstNameError] = useState("");

  const handleFirstNameChange = (event) => {
    const { value } = event.target;
    setFirstName(value);

    if (!value.trim()) {
      setFirstNameError("First name is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setFirstNameError("First name must contain only letters");
    } else {
      setFirstNameError("");
    }
  };
  // =======================Last name=======================//
  const [lastName, setLastName] = useState("");
  const [lastNameError, setLastNameError] = useState("");

  const handleLastNameChange = (event) => {
    const { value } = event.target;
    setLastName(value);

    if (!value.trim()) {
      setLastNameError("Last name is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setLastNameError("LAst name must contain only letters");
    } else {
      setLastNameError("");
    }
  };
  // ======================= Title =======================//
  const [title, setTitle] = useState("");
  const [titleError, setTitleError] = useState("");

  const handletitleChange = (event) => {
    const { value } = event.target;
    setTitle(value);

    if (!value.trim()) {
      setTitleError("This filed is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setTitleError("This filed is required");
    } else {
      setTitleError("");
    }
  };
  // ====================Salutation==========================//
  const [salutation, setSalutation] = useState("");
  const [salutationError, setSalutationError] = useState("");

  const handleSalutationChange = (event) => {
    const { value } = event.target;
    setSalutation(value);

    if (!value) {
      setSalutationError("Please select an option");
    } else {
      setSalutationError("");
    }
  };
  // ======================= Gender =======================//
  const [gender, setGender] = useState("");
  const [genderError, setGenderError] = useState("");

  const handleGenderChange = (event) => {
    const { value } = event.target;
    setGender(value);

    if (!value) {
      setGenderError("Please select Gender");
    } else {
      setGenderError("");
    }
  };
  // ======================= Department =======================//
  const [department, setDepartment] = useState("");
  const [departmentError, setDepartmentError] = useState("");

  const handleDepartmentChange = (event) => {
    const { value } = event.target;
    setDepartment(value);

    if (!value) {
      setDepartmentError("Please select an Option");
    } else {
      setDepartmentError("");
    }
  };
  // ======================= Status =======================//
  const [status, setStatus] = useState("");
  const [statusError, setStatusError] = useState("");

  const handleStatusChange = (event) => {
    const { value } = event.target;
    setStatus(value);

    if (!value) {
      setStatusError("Please select an Option");
    } else {
      setStatusError("");
    }
  };

  // ======================== Email ======================//

  const [email, setEmail] = useState("");

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };
  const validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  // ======================================================//
  const formList = [
    "Details",
    "Template Designer"
    
  ];

  const [form, setForm] = useState(formList[0]);

  useEffect(() => {
    const allCountries = getCountries();
    const codes = allCountries.map((country) => getCountryCallingCode(country));
    setCountryCodes(codes);
  }, []);
  const handleSubmit = async () => {
    try {
      const response = await apiService.addPerson(person);
      console.log("Person Created :", response);
    } catch (error) {
      console.error("Error Creating Person :", error);
    }
  };
  const references = {
    id: 1,
    label: "References",
    isRequired: "false",
    instruction: "",
    columnList: [
      { id: 1.1, name: "Title of Document", type: "text" },
      { id: 1.2, name: "Attachment", type: "file" },
      { id: 1.3, name: "Remarks", type: "text" },
    ],
  };
  const [person, setPerson] = useReducer(
    (prev, next) => ({
      ...prev,
      ...next,
    }),
    {
      personID: "",
      profilePhoto: "",
      firstName: "",
      middleName: "",
      lastName: "",
      title: "",
      manager: "",
      gender: "",
      salutation: "",
      function: "",
      department: "",
      otherDepartment: "",
      phoneNum: "",
      mobileNum: "",
      personEmail: "",
      managerEmail: "",
      status: "",
      fax: "",
      address: "",
      postalCode: "",
      country: "",
      city: "",
      detailedAddress: "",

      comments: "",
      references: "",
    }
  );
  useEffect(() => {
    setPerson({ personEmail: email });
    setPerson({ firstName: firstName });
    setPerson({ title: title });
    setPerson({ salutation: salutation });
    setPerson({ gender: gender });
    setPerson({ department: department });
    setPerson({ status: status });
  }, [email, firstName, title, salutation, gender, department, status]);

  const [value, setValue] = React.useState("1");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">Template Designer</div>}
        />
      </div>
      <div id="personinformation">
        <div className="document-block">
          <div className="flex m-5 justify-between items-center">
            <div>
              <div className="document-tabs flex">
                {formList.map((item, index) => (
                  <div
                    key={index}
                    className={form === item ? "active" : ""}
                    onClick={() => setForm(item)}
                  >
                    {item}
                  </div>
                ))}
              </div>
            </div>
            <div className=" justify-between items-center ">
              <div className="button-block" style={{ width: "100%" }}>
                <button
                  className="themeBtn"
                  onClick={() => {
                    handleSave(differentialPRecord);
                  }}
                >
                  Save
                </button>
                <button
                  className="themeBtn"
                  onClick={() => navigate("/template-designer/manage")}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>

          {form === formList[0] ? (
            <div className="document-form">
              <div className="sub-head">Details</div>
             
            </div>
          ) : form === formList[1] ? (
            <div className="document-form">
              <div className="sub-head">Template Designer Information</div>
             
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
    </>
  );
}

export default TemplateDesignerForm;
