import React, { useState } from "react";
import "./Divisions.css";
import PageHeader from "../../components/PageHeader/PageHeader";
import {

  Download,
} from "../../components/Icons";
import { useNavigate } from "react-router-dom";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { TbArrowBigUpFilled } from "react-icons/tb";
import { TbArrowBigDownFilled } from "react-icons/tb";
import ErrorIcon from "@mui/icons-material/Error";

const AddDesktopInformation = () => {
  const navigate = useNavigate();
  const formList = ["Information"];
  const [form, setForm] = useState(formList[0]);
  const [passwordType, setPasswordType] = useState("password");

  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">Site/Location Information</div>}
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
            <button
                className="themeBtn"
                
              >
                Duplicate
              </button>
              <button
                className="themeBtn"
                onClick={() => {
                  handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/site-location/manage")}
              >
                Exit
              </button>
            </div>
          </div>
        </div>

        {form === formList[0] ? (
          <div className="document-form">
            <div className="sub-head">Site/Location Details</div>
            <div className="personal-info">
              <div className="section-body">
                <div className="">
                  <div className="group-input">
                    <label>Name</label>
                    <input type="text" />
                  </div>
                
                </div>
                {/* Only When Desktop is Edit */}
                <div className="group-input">
                  <label>Description</label>
                  <textarea></textarea>
                </div>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
};

export default AddDesktopInformation;
