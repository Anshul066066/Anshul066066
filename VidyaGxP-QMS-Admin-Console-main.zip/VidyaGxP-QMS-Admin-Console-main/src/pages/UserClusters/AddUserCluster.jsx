import React, { useEffect, useState } from "react";
import PageHeader from "../../components/PageHeader/PageHeader";
import { useNavigate } from "react-router-dom";
import { Download } from "../../components/Icons";
import Grid from "../../components/DataFields/Grid";

function AddUserCluster() {
  const navigate = useNavigate();
  const formList = ["Details", "User Cluster Matrix"];
  const [form, setForm] = useState(formList[0]);
  const [cluster, setCluster] = useState("");

  const clusterMatrix = {
    label: "Cluster Matrix",
    required: true,
    columnList: [
      {
        id: 1,
        name: "Person Role",
        type: "singleSelection",
        selectionValues: ["Initiator", "QA Approver"],
      },
      {
        id: 2,
        name: "Clusters",
        type: "singleSelection",
        selectionValues: ["Initiator-C", "QA Approver-C"],
      },
    ],
  };
  //   ========================Name Validation=================
  const [clustername, setClusterName] = useState("");
  const [clusternameError, setClusterNameError] = useState("");

  const handleClusterNameChange = (event) => {
    const { value } = event.target;
    setClusterName(value);

    if (!value.trim()) {
      setClusterNameError("Name is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setClusterNameError("Name must contain only letters");
    } else {
      setClusterNameError("");
    }
  };
  //   ========================Description Validation=================
  const [clusterdescription, setClusterDescription] = useState("");
  const [clusterdescriptionError, setClusterDescriptionError] = useState("");

  const handleClusterDescriptionChange = (event) => {
    const { value } = event.target;
    setClusterDescription(value);

    if (!value.trim()) {
      setClusterDescriptionError("Description is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setClusterDescriptionError("Name must contain only letters");
    } else {
      setClusterDescriptionError("");
    }
  };
  //   ========================End Validation=================
  useEffect(() => {
    setCluster({ clustername: clustername });
    setCluster({ clusterdescription: clusterdescription });
  }, [clustername, clusterdescription]);

  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">User Cluster Information</div>}
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
              <button
                className="themeBtn"
                onClick={() => {
                  handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/user-clusters/manage")}
              >
                Cancel
              </button>
              <button
                className="themeBtn"
                // onClick={() => navigate("/login-accounts/manage")}
              >
                Duplicate
              </button>
              <div className="themeBtn">{Download(20, "#000000")}Report</div>
            </div>
          </div>
        </div>

        {form === formList[0] ? (
          <div className="document-form">
            <div className="sub-head">Details</div>
            <div className="personal-info">
              <div className="section-body">
                <div className="group-input">
                  <label>
                    <div className="required"></div>Name
                  </label>
                  <input
                    value={clustername}
                    onChange={handleClusterNameChange}
                    type="text"
                    required
                  />
                  {setClusterNameError && (
                    <p
                      style={{
                        color: "red",
                        padding: "0",
                        margin: "7px",
                        fontWeight: "bold",
                        fontSize: "14px",
                      }}
                    >
                      {clusternameError}
                    </p>
                  )}
                </div>
                <div className="group-input">
                  <label>
                    <div className="required"></div>Description
                  </label>
                  <textarea
                    value={clusterdescription}
                    onChange={handleClusterDescriptionChange}
                    type="text"
                    required
                  ></textarea>
                  {setClusterDescriptionError && (
                    <p
                      style={{
                        color: "red",
                        padding: "0",
                        margin: "7px",
                        fontWeight: "bold",
                        fontSize: "14px",
                      }}
                    >
                      {clusterdescriptionError}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : form === formList[1] ? (
          <div className="document-form">
            <div className="sub-head">User Cluster Matrix</div>
            <div className="personal-info">
              <div className="section-body">
                <Grid
                  label={clusterMatrix.label}
                  isRequired={clusterMatrix.required}
                  columnList={clusterMatrix.columnList}
                />
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
}

export default AddUserCluster;
