export const tableHead = [
    {
        th: 'Row #'
    }, {
        th: 'Name'
    }, {
        th: 'Description'
    }, {
        th: 'Action'
    }
]

export const tableBody = [
    {
        id: 1,
        name: 'Shaleen Mishra',
        description: 'Change Control FP'
    }
]