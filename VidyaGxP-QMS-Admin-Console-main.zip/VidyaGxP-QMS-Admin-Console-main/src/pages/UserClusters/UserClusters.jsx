
import PageHeader from '../../components/PageHeader/PageHeader';
import { AddIcon, DefaultColor, Download, Edit, PersonIcon } from '../../components/Icons';
import PageSearchBar from '../../components/PageSearchBar/PageSearchBar';
import { Each } from '../../components/Each';
import { tableBody, tableHead } from './UserClustersData';
import './UserClusters.css'
import { useState } from 'react';
import AddUserClusterModal from '../../components/Modals/AddEntitiesModal/AddUserClusterModal';
import Person4Icon from '@mui/icons-material/Person4';
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import { useNavigate } from 'react-router-dom';


function UserClusters() {
    const [addModal, setAddModal] = useState(false)
    const closeAddModal = () => setAddModal(false)
    const navigate = useNavigate();
    const [search, setSearch] = useState("");
    const [filterData, setFilterData] = useState(tableBody);
    const SearchValue = (value) => {
      setSearch(value);
      const filteredData = tableBody.filter((item) => {
        const lowerCaseValue = value.toLowerCase();
        const lowerCaseName = item.name.toLowerCase();
        const lowerCasePersonID = item.description.toLowerCase();
        return (
          lowerCaseName.includes(lowerCaseValue) ||
          lowerCasePersonID.includes(lowerCaseValue)
        );
      });
      setFilterData(filteredData);
    };
    return (
        <>

            <PageHeader title={<div><Person4Icon/>User Clusters</div>} />

            <div id="user-clusters-page">

            <div className="top-block">
                    <PageSearchBar value={search} setValue={SearchValue}/>
                    <div className="btn-bar">
                    <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
                        <div className="themeBtn">
                            {Download(20, '#000000')}Report
                        </div>
                        <div className="themeBtn" onClick={() => navigate("/add-user-cluster")}>{AddIcon(20, "#000000")}Add</div>
                    </div>
                </div>
                

                <div className="table-block">
                    <table>
                        <thead>
                            <tr>
                                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
                            </tr>
                        </thead>
                        <tbody>
                            <Each of={filterData} render={(item, index) =>
                                <tr>
                                    {/* <td className='serial'>{index + 1}</td> */}
                                    <td className="serial" style={{justifyContent:"space-between"}}><input type="checkbox" className="w-3 mr-3" />{index + 1}</td>
                                    <td>{item.name}</td>
                                    <td>{item.description}</td>
                                    <td>
                                        <div className="action">
                                            <div>{Edit(20, DefaultColor)}</div>
                                        </div>
                                    </td>
                                </tr>
                            } />
                        </tbody>
                    </table>
                </div>

            </div>

            {addModal && <AddUserClusterModal closeModal={closeAddModal} />}

        </>
    )
}

export default UserClusters
