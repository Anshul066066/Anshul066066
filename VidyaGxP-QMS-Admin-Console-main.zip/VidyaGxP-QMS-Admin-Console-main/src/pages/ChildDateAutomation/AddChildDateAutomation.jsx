import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import PageHeader from '../../components/PageHeader/PageHeader';

function AddChildDateAutomation() {
    const navigate = useNavigate();
    const formList = ["Details", "Manager"];
    const [form, setForm] = useState(formList[0]);
  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={
            <div className="text-[17px]">Child Date Automation</div>
          }
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
              <button className="themeBtn">Duplicate</button>
              <button
                className="themeBtn"
                onClick={() => {
                  handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/child-date-automation/manage")}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>

        {form === formList[0] ? (
          <div className="document-form">
            <div className="sub-head">Details</div>
            <div className="personal-info">
              <div className="section-body">
              </div>
            </div>
          </div>
        ) : form === formList[1] ? (
          <div className="document-form">
            <div className="sub-head">Manager</div>
            <div className="personal-info">
              <div className="section-body"></div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  )
}

export default AddChildDateAutomation
