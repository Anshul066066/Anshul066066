export const tableHead = [
    {
        id: 1,
        th: 'Row #'
    }, {
        id: 2, 
        th: 'Rapid Summary'
    }, {
        id: 3, 
        th: 'Date Performed'
    },  {
        id: 4, 
        th: 'Tier'
    }, {
        id: 5,
        th: 'Accountable'
    } , {
        id: 6, 
        th: 'Action'
    },
]

export const tableBody = [
    {
        id: 1,
        rapidSummary: 'Login Account created for Shaleen Mishra',
        datePerformed: '19 Jan 2024 11:00PM',
        tier: 'New',
        accountable: 'Amit Guru',
    }, {
        id: 2,
        rapidSummary: 'Login Account modified of Shaleen Mishra',
        datePerformed: '21 Jan 2024 11:00PM',
        tier: 'Modify',
        accountable: 'Amit Guru',
    },
]