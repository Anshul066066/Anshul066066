import { useState } from 'react'
import { AuditTrailIcon, DefaultColor, Download, DocumentViewIcon } from '../../components/Icons'
import PageHeader from '../../components/PageHeader/PageHeader'
import PageSearchBar from '../../components/PageSearchBar/PageSearchBar'
import { tableBody, tableHead } from './AuditTrailData'
import { Each } from '../../components/Each'
import AuditTrailModal from '../../components/Modals/AuditTrailModal'
import './AuditTrail.css'

export default function AuditTrail() {
    const [search, setSearch] = useState('')
    const [element, setElement] = useState('')
    const [filterData, setFilterData] = useState(tableBody)
    const [auditModal, setAuditModal] = useState(false)
    const closeAuditModal = () => setAuditModal(false)
    const SearchValue = (value) => {
        setSearch(value);
        const filteredData = tableBody.filter((item) => {
            const lowerCaseValue = value.toLowerCase();
            const lowerCaseName = item.rapidSummary.toLowerCase();
            const lowerCasePersonID = item.datePerformed.toLowerCase();
            const lowerCaseTier = item.tier.toLowerCase();
            const lowerCaseAccountable = item.accountable.toLowerCase();
            return lowerCaseName.includes(lowerCaseValue) || lowerCasePersonID.includes(lowerCaseValue) || lowerCaseTier.includes(lowerCaseValue) || lowerCaseAccountable.includes(lowerCaseValue);
        });
        setFilterData(filteredData);
    }
    const handleShow = (ele) => {
        setAuditModal(true)
        setElement(ele)
    }
    return (
        <>

            <PageHeader title={<div>{AuditTrailIcon(28, '#000000')}Audit Trail</div>} />

            <div id="audit-trail-page">

                <div className="top-block">
                    <PageSearchBar value={search} setValue={SearchValue} />
                    <div className="btn-bar">
                        <div className="themeBtn">{Download(20, '#000000')}Report</div>
                    </div>
                </div>

                <div className="table-block">
                    <table>
                        <thead>
                            <tr>
                                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
                            </tr>
                        </thead>
                        <tbody>
                            <Each of={filterData} render={(item, index) =>
                                <tr>
                                    <td className='serial'>{index + 1}</td>
                                    <td>{item.rapidSummary}</td>
                                    <td>{item.datePerformed}</td>
                                    <td>{item.tier}</td>
                                    <td>{item.accountable}</td>
                                    <td>
                                        <div className="action">
                                            <div onClick={() => handleShow(item)}>{DocumentViewIcon(20, DefaultColor)}</div>
                                            <div>{Download(20, '#000000')}</div>
                                        </div>
                                    </td>
                                </tr>
                            } />
                        </tbody>
                    </table>
                </div>

            </div>

            {auditModal && <AuditTrailModal closeModal={closeAuditModal} element={element} />}

        </>
    )
}
