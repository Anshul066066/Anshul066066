import React, { useState } from "react";
// import "./AddDesktopInformation.css";
import PageHeader from "../../components/PageHeader/PageHeader";
// import MultiSelectionField from "../../components/DataFields/MultiSelectionField";
import {
  AddIcon,
  DefaultColor,
  Download,
  Edit,
  EyeIcon,
  EyeSlashIcon,
} from "../../components/Icons";
import { useNavigate } from "react-router-dom";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import ContentCopyIcon from "@mui/icons-material/ContentCopy";
import { TbArrowBigUpFilled } from "react-icons/tb";
import { TbArrowBigDownFilled } from "react-icons/tb";
import ErrorIcon from "@mui/icons-material/Error";

const AddAudience = () => {
  const navigate = useNavigate();
  const formList = ["Information",  "Details"];
  const [form, setForm] = useState(formList[0]);
  const [passwordType, setPasswordType] = useState("password");
  // const optionList = [
  //   "Change Control",
  //   "CAPA",
  //   "Internal Audit",
  //   "External Audit",
  // ];

  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">Audience Information</div>}
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
              <button
                className="themeBtn"
                onClick={() => {
                  handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/audience/manage")}
              >
                Exit
              </button>
            </div>
          </div>
        </div>

        {form === formList[0] ? (
          <div className="document-form">
            <div className="sub-head">Audience Details</div>
            <div className="personal-info">
              <div className="section-body">
                <div className="dual-group-input">
                  <div className="group-input">
                    <label>UID</label>
                    <input type="text" disabled />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Login Name
                    </label>
                    <input type="text" required />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Person Name
                    </label>
                    <select required>
                      <option value="">-- Select --</option>
                      <option value="amit_guru">Amit Guru</option>
                      <option value="shaleen_mishra">Shaleen Mishra</option>
                    </select>
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Password
                    </label>
                    <div className="password-field">
                      <input type={passwordType} required />
                      {passwordType === "password" ? (
                        <div onClick={() => setPasswordType("text")}>
                          {EyeIcon(20, "#808080")}
                        </div>
                      ) : (
                        <div onClick={() => setPasswordType("password")}>
                          {EyeSlashIcon(20, "#808080")}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="group-input">
                    <label>Person E-Mail</label>
                    <input type="email" disabled />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Status
                    </label>
                    <select required>
                      <option value="">-- Select --</option>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>
                {/* Only When Desktop is Edit */}
                <div className="group-input">
                  <label>Comments</label>
                  <textarea></textarea>
                </div>
              </div>
            </div>
          </div>
        ) : form === formList[1] ? (
          <div className="document-form">
            <div className="sub-head">Layout</div>
            <div className="btn-bar flex gap-2 float-right mb-2">
              <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
              <div className="themeBtn">{<ContentCopyIcon />}Duplicate</div>
              <div className="themeBtn">{Download(20, "#000000")}Report</div>
            </div>
            <div className="personal-info">
              <div className="section-body">
                <div className="table-block px-2">
                  <table>
                    <thead className="thead-colour">
                      <tr>
                        <th>Row</th>
                        <th>Column Position</th>
                        <th>Data Field</th>
                        <th>Source</th>
                        <th>Displayed Column Name</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          1<TbArrowBigDownFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="cars" id="cars">
                                <option value="volvo">Parent Id</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          2<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="cars" id="cars">
                                <option value="volvo">Site/Division</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          3<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Process</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          4<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Short Discription</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          5<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Date Opened</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          6<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Date Due</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          7<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Assigned To</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          8<TbArrowBigDownFilled style={{ color: "green" }} />
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">State</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>

                      <tr>
                        <td className="serial">
                          <input type="checkbox" />
                        </td>
                        <td className="arrow-position">
                          9
                          <TbArrowBigUpFilled style={{ color: "green" }} />
                        </td>
                        <td>
                          <div className="slect-box-table">
                            <div className="">
                              <select name="" id="">
                                <option value="">Originator</option>
                              </select>
                            </div>
                            <div>
                              <ErrorIcon sx={{ color: "#5b8beb" }} />
                            </div>
                          </div>
                        </td>
                        <td>View Only</td>
                        <td>
                          <input
                            type="text"
                            placeholder="Enter Displayed Column Name"
                          />
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>

            <div className="pt-5">
              <div className="sub-head mt-2">Desktop Table Preview</div>
              <table className="">
                <thead style={{ backgroundColor: "#fcd6a1 !important" }}>
                  <tr>
                    <th style={{ backgroundColor: "#fcd6a1" }}>1</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>2</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>3</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>4</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>5</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>6</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>7</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>8</th>
                    <th style={{ backgroundColor: "#fcd6a1" }}>9</th>
                  </tr>
                  <tr>
                    <th>Row</th>
                    <th>Parent ID</th>
                    <th>Division</th>
                    <th>Process</th>
                    <th>Short Description</th>
                    <th>Date Opened</th>
                    <th>Date Due</th>
                    <th>Assigned To</th>
                    <th>Status</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td></td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        ) : form === formList[2] ? (
          <div className="document-form">
            <div className="sub-head"></div>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
};

export default AddAudience;
