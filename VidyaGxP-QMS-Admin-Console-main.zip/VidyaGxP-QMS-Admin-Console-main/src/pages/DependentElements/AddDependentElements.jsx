import React, { useReducer, useState } from 'react'
import PageHeader from '../../components/PageHeader/PageHeader'
import { Download } from '../../components/Icons';
import { Grid } from '@mui/material';
import { Each } from '../../components/Each';
import { useNavigate } from 'react-router-dom';

const AddDependentElements = () => {
    const navigate = useNavigate();

    // const tabData = ["Details", "Dependent Entities Manager"]
    // const [tab, setTab] = useState(tabData[0])
    const formList = ["Details", "Dependent Entities Manager"];
    const [form, setForm] = useState(formList[0]);
    const [DependentElements, setDependentElements] = useReducer(
        (prev, next) => ({
            ...prev, ...next
        }),
        {
            name: "",
            description: "",
            ParentFieldName: "",
            ParentFieldValue: "",
            ChildFieldName: ""

        }
    )


    return (
        <>
            <div style={{ position: "fixed", width: "100%" }}>
                <PageHeader
                    title={
                        <div className="text-[17px]">Conditionally View Information</div>
                    }
                />
            </div>
            <div className="document-block">
                <div className="flex m-5 justify-between items-center">
                    <div>
                        <div className="document-tabs flex">
                            {formList.map((item, index) => (
                                <div
                                    key={index}
                                    className={form === item ? "active" : ""}
                                    onClick={() => setForm(item)}
                                >
                                    {item}
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className=" justify-between items-center ">
                        <div className="button-block" style={{ width: "100%" }}>
                            <button className="themeBtn">Duplicate</button>
                            <button
                                className="themeBtn"
                                onClick={() => {
                                    //   handleSave(differentialPRecord);
                                }}
                            >
                                Save
                            </button>
                            <button
                                className="themeBtn"
                                onClick={() => navigate("/dependent-elements/manage")}
                            >
                                Cancel
                            </button>
                        </div>
                    </div>
                </div>
                {form === formList[0] ? (
                    <div className="document-form">
                        <div className="sub-head">Details</div>
                        <div className="personal-info">
                            <div className="section-body">
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Name
                                    </label>
                                    <input type="text" value={DependentElements.name} onChange={(e) => setDependentElements({ name: e.target.value })} required />
                                </div>
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Description
                                    </label>
                                    <input value={DependentElements.description} onChange={(e) => setDependentElements({ description: e.target.value })} type="text" required />
                                </div>
                            </div>
                        </div>
                    </div>
                ) : form === formList[1] ? (
                    <div className="document-form">
                        <div className="sub-head">Dependent Entities Manager</div>
                        <div className="personal-info">
                            <div className="section-body">
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Parent Field Name
                                    </label>
                                    <select required onChange={(e) => setDependentElements({ ParentFieldName: e.target.value })}>
                                        <option value="">-- Select --</option>
                                        <option value="test_1">Test 1</option>
                                        <option value="test_2">Test 2</option>
                                        <option value="test_3">Test 3</option>
                                        <option value="test_4">Test 4</option>
                                        <option value="test_5">Test 5</option>
                                    </select>
                                </div>
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Parent Field Value
                                    </label>
                                    <select required onChange={(e) => setDependentElements({ ParentFieldValue: e.target.value })}>
                                        <option value="">-- Select --</option>
                                        <option value="test_1">Test 1</option>
                                        <option value="test_2">Test 2</option>
                                        <option value="test_3">Test 3</option>
                                        <option value="test_4">Test 4</option>
                                        <option value="test_5">Test 5</option>
                                    </select>
                                </div>
                                <div className="child-button-grid-field">
                                    <div className="group-input mb-0">
                                        <label>
                                            <div className="required"></div>
                                            Child Field Name
                                        </label>
                                        <select required onChange={(e) => setDependentElements({ ChildFieldName: e.target.value })}>
                                            <option value="">-- Select --</option>
                                            <option value="test_1">Test 1</option>
                                            <option value="test_2">Test 2</option>
                                            <option value="test_3">Test 3</option>
                                            <option value="test_4">Test 4</option>
                                            <option value="test_5">Test 5</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                ) : (
                    ""
                )}
            </div>

            {/* <div className="modal-middle">
                    <div className="form-tabs">
                        <Each of={tabData} render={(item) =>
                            <div onClick={() => setTab(item)} className={tab === item ? 'active' : ''}>{item}</div>
                        } />
                    </div>
                    {tab === tabData[0] &&
                        <div className="document-form">
                            <div className='sub-head'></div>
                            <div className='personal-info'>
                                <div className="section-body">
                                    <div className="group-input">
                                        <label>
                                            <div className="required"></div>
                                            Name
                                        </label>
                                        <input type="text" value={DependentElements.name} onChange={(e) => setDependentElements({ name: e.target.value })} required />
                                    </div>
                                    <div className="group-input">
                                        <label>
                                            <div className="required"></div>
                                            Description
                                        </label>
                                        <input value={DependentElements.description} onChange={(e) => setDependentElements({ description: e.target.value })} type="text" required />
                                    </div>
                                </div>
                            </div>


                        </div>
                    }
                    {tab === tabData[1] &&
                        <div className="form-section">
                            <div className="section-body">
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Parent Field Name
                                    </label>
                                    <select required onChange={(e) => setDependentElements({ ParentFieldName: e.target.value })}>
                                        <option value="">-- Select --</option>
                                        <option value="test_1">Test 1</option>
                                        <option value="test_2">Test 2</option>
                                        <option value="test_3">Test 3</option>
                                        <option value="test_4">Test 4</option>
                                        <option value="test_5">Test 5</option>
                                    </select>
                                </div>
                                <div className="group-input">
                                    <label>
                                        <div className="required"></div>
                                        Parent Field Value
                                    </label>
                                    <select required onChange={(e) => setDependentElements({ ParentFieldValue: e.target.value })}>
                                        <option value="">-- Select --</option>
                                        <option value="test_1">Test 1</option>
                                        <option value="test_2">Test 2</option>
                                        <option value="test_3">Test 3</option>
                                        <option value="test_4">Test 4</option>
                                        <option value="test_5">Test 5</option>
                                    </select>
                                </div>
                                <div className="child-button-grid-field">
                                    <div className="group-input mb-0">
                                        <label>
                                            <div className="required"></div>
                                            Child Field Name
                                        </label>
                                        <select required onChange={(e) => setDependentElements({ ChildFieldName: e.target.value })}>
                                            <option value="">-- Select --</option>
                                            <option value="test_1">Test 1</option>
                                            <option value="test_2">Test 2</option>
                                            <option value="test_3">Test 3</option>
                                            <option value="test_4">Test 4</option>
                                            <option value="test_5">Test 5</option>
                                        </select>
                                    </div>
                                    <div className="launch-btn" onClick={() => setOpenModal(true)}>Launch Values</div>
                                </div>
                            </div>
                        </div>
                    }
                </div> */}

        </>
    )
}

export default AddDependentElements