import { useState } from 'react';
import PageHeader from '../../components/PageHeader/PageHeader';
import { AddIcon, DefaultColor, Download, Edit, } from '../../components/Icons';
import PageSearchBar from '../../components/PageSearchBar/PageSearchBar';
import { Each } from '../../components/Each';
import './DependentElements.css'
import { tableBody, tableHead } from './DependentElementsData';
import AddDependentElementsModal from '../../components/Modals/AddEntitiesModal/AddDependentElementsModal';
import DynamicFeedIcon from '@mui/icons-material/DynamicFeed';
import { useNavigate } from 'react-router-dom';


function DependentElements() {
    const navigate = useNavigate();
    const [addModal, setAddModal] = useState(false)
    const closeAddModal = () => setAddModal(false);
    const [search, setSearch] = useState("");
    const [filterData, setFilterData] = useState(tableBody);
    const SearchValue = (value) => {
      setSearch(value);
      const filteredData = tableBody.filter((item) => {
        const lowerCaseValue = value.toLowerCase();
        const lowerCaseName = item.name.toLowerCase();
        const lowerCasePersonID = item.description.toLowerCase();
        return (
          lowerCaseName.includes(lowerCaseValue) ||
          lowerCasePersonID.includes(lowerCaseValue)
        );
      });
      setFilterData(filteredData);
    };
    return (
        <>

            <PageHeader title={<div><DynamicFeedIcon/>Dependent Elements</div>} />

            <div id="dependent-elements-page">

                <div className="top-block">
                    <PageSearchBar value={search} setValue={SearchValue} />
                    <div className="group-input-2">
                        <label>Process Sets</label>
                        <select>
                            <option value="change_control">Change Control</option>
                            <option value="audit_program">Audit Program</option>
                        </select>
                    </div>
                    <div className="btn-bar">
                        <div className="themeBtn">
                            {Download(20, '#000000')}Report
                        </div>
                        <div className="themeBtn" onClick={() =>navigate('/Add-dependent/manage')}>{AddIcon(20, '#000000')}Add</div>

                    </div>
                </div>

                <div className="table-block">
                    <table>
                        <thead>
                            <tr>
                                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
                            </tr>
                        </thead>
                        <tbody>
                            <Each of={filterData} render={(item, index) =>
                                <tr>
                                    <td className='serial'>{index + 1}</td>
                                    <td>{item.name}</td>
                                    <td>{item.description}</td>
                                    <td>
                                        <div className="action">
                                            <div onClick={() => setAddModal(true)}>{Edit(20, DefaultColor)}</div>
                                            <div>{Download(20, '#000000')}</div>
                                        </div>
                                    </td>
                                </tr>
                            } />
                        </tbody>
                    </table>
                </div>

            </div>

            {addModal && <AddDependentElementsModal closeModal={closeAddModal} />}

        </>
    )
}

export default DependentElements
