import React from "react";
import PageHeader from "../../components/PageHeader/PageHeader";

const AddActions = () => {
  return (<>
  <PageHeader title={<div className="text-[17px]">Actions</div>} />
    <div className="document-block">
      <div className="flex justify-between items-center">
        <div className="form-tabs"></div>
        <div className="button-block">
          <button
            className="themeBtn"
            onClick={() => navigate("/clusters/manage")}
          >
            Save
          </button>
          <button
            className="themeBtn"
            onClick={() => navigate("/clusters/manage")}
          >
            Duplicate
          </button>
          <button
            className="themeBtn"
            onClick={() => navigate("/record-stages/manage")}
          >
            Cancel
          </button>
        </div>
      </div>

      <div className="document-form">
        <div className="sub-head">Details</div>
      </div>
    </div>
    </>
  );
};

export default AddActions;
