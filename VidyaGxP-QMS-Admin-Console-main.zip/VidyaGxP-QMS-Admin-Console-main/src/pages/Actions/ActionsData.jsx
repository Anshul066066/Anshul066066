export const tableHead = [
    {
        th: 'Row #'
    }, {
        th: 'Name'
    }, {
        th: 'Description'
    }, {
        th: 'Action'
    },
]

export const tableBody = [
    {
        id: 1,
        name: 'Test',
        description: 'Test'
    }
]