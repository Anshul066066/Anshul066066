import React, { useEffect, useState } from "react";
import "./AddProcessSets.css";
import { useNavigate } from "react-router-dom";
import PageHeader from "../../components/PageHeader/PageHeader";
import { Download } from "../../components/Icons";

function AddProcessSets() {
  const navigate = useNavigate();
  const formList = ["Details"];
  const [form, setForm] = useState(formList[0]);
  const [details, setDetails] = useState("");

  //   ========================Name Validation=================
  const [name, setName] = useState("");
  const [nameError, setNameError] = useState("");

  const handleNameChange = (event) => {
    const { value } = event.target;
    setName(value);

    if (!value.trim()) {
      setNameError("Name is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setNameError("Name must contain only letters");
    } else {
      setNameError("");
    }
  };
  //   ========================Description Validation=================
  const [description, setDescription] = useState("");
  const [descriptionError, setDescriptionError] = useState("");

  const handleDescriptionChange = (event) => {
    const { value } = event.target;
    setDescription(value);

    if (!value.trim()) {
      setDescriptionError("Description is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setDescriptionError("Name must contain only letters");
    } else {
      setDescriptionError("");
    }
  };
  //   ========================End Validation=================
  useEffect(() => {
    setDetails({ name: name });
    setDetails({ description: description });
  }, [name, description,]);

  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">Process Sets Information</div>}
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
              <button
                className="themeBtn"
                onClick={() => {
                  handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/process-sets/manage")}
              >
                Cancel
              </button>
              <button
                className="themeBtn"
                // onClick={() => navigate("/login-accounts/manage")}
              >
                Duplicate
              </button>
              <div className="themeBtn">{Download(20, "#000000")}Report</div>
            </div>
          </div>
        </div>

        {form === formList[0] ? (
          <div className="document-form">
            <div className="sub-head">Details</div>
            <div className="personal-info">
              <div className="section-body">
                <div className="group-input">
                  <label>
                    {" "}
                    <div className="required"></div>Name
                  </label>
                  <input
                    value={name}
                    onChange={handleNameChange}
                    type="text"
                    required
                  />
                  {nameError && (
                    <p
                      style={{
                        color: "red",
                        padding: "0",
                        margin: "7px",
                        fontWeight: "bold",
                        fontSize: "14px",
                      }}
                    >
                      {nameError}
                    </p>
                  )}
                </div>
                <div className="group-input">
                  <label>
                    <div className="required"></div>Description
                  </label>
                  <textarea  value={description}
                    onChange={handleDescriptionChange}
                    type="text" required>
                  </textarea>
                  {setDescriptionError && (
                    <p
                      style={{
                        color: "red",
                        padding: "0",
                        margin: "7px",
                        fontWeight: "bold",
                        fontSize: "14px",
                      }}
                    >
                      {descriptionError}
                    </p>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
}

export default AddProcessSets;
