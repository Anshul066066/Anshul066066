import { useState } from "react";
import PageHeader from "../../components/PageHeader/PageHeader";
import { tableBody, tableHead } from "./ProcessSetsData";
import { AddIcon, DefaultColor, Download, Edit } from "../../components/Icons";
import PageSearchBar from "../../components/PageSearchBar/PageSearchBar";
import { Each } from "../../components/Each";
import AddProcessSetsModal from "../../components/Modals/AddEntitiesModal/AddProcessSetsModal";
import "./ProcessSets.css";
import ViewInArIcon from "@mui/icons-material/ViewInAr";
import { useNavigate } from "react-router-dom";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";

function ProcessSets() {
  const [addModal, setAddModal] = useState(false);
  const closeAddModal = () => setAddModal(false);
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [filterData, setFilterData] = useState(tableBody);
  console.log(19,filterData)
  const SearchValue = (value) => {
    setSearch(value);
    const filteredData = tableBody.filter((item) => {
      const lowerCaseValue = value.toLowerCase();
      const lowerCaseName = item.name.toLowerCase();
      const lowerCasePersonID = item.description.toLowerCase();
      return (
        lowerCaseName.includes(lowerCaseValue) ||
        lowerCasePersonID.includes(lowerCaseValue)
      );
    });
    setFilterData(filteredData);
  };
  return (
    <>
      <PageHeader
        title={
          <div>
            <ViewInArIcon />
            Process Sets
          </div>
        }
      />

      <div id="process-sets-page">
        <div className="top-block">
          <PageSearchBar   value={search} setValue={SearchValue}/>
          <div className="btn-bar">
            <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
            <div className="themeBtn">{Download(20, "#000000")}Report</div>
            <div
              className="themeBtn"
              onClick={() => navigate("/add-process-set")}
            >
              {AddIcon(20, "#000000")}Add
            </div>
          </div>
        </div>

        <div className="table-block">
          <table>
            <thead>
              <tr>
                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
              </tr>
            </thead>
            <tbody>
              <Each
                of={filterData}
                render={(item, index) => (
                  <tr>
                    {/* <td className='serial'>{index + 1}</td> */}
                    <td
                      className="serial"
                      style={{ justifyContent: "space-between" }}
                    >
                      <input type="checkbox" className="w-3 mr-3" />
                      {index + 1}
                    </td>
                    <td>{item.name}</td>
                    <td>{item.description}</td>
                    <td>
                      <div className="action">
                        <div onClick={() => setAddModal(true)}>
                          {Edit(20, DefaultColor)}
                        </div>
                        <div>{Download(20, "#000000")}</div>
                      </div>
                    </td>
                  </tr>
                )}
              />
            </tbody>
          </table>
        </div>
      </div>

      {addModal && <AddProcessSetsModal closeModal={closeAddModal} />}
    </>
  );
}

export default ProcessSets;
