import React, { useState } from "react";
import { Route, useNavigate } from "react-router-dom";
import PageHeader from "../../components/PageHeader/PageHeader";

const AddAncestors = () => {
  const navigate = useNavigate();
  const formList = ["Details", "Ancestors Manager"];
  const [form, setForm] = useState(formList[0]);

  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">Ancestors Information</div>}
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
              <button
                className="themeBtn"
                onClick={() => {
                  // handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/ancestors/manage")} // Corrected path to '/ancestors'
              >
                Exit
              </button>
            </div>
          </div>
        </div>

        {/* Form content */}
        {/* ... */}
      </div>
    </>
  );
};

export default AddAncestors;
