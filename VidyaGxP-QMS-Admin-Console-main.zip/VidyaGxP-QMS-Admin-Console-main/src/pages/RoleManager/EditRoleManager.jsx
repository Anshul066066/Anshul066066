import React from "react";
import { useEffect, useReducer, useState } from "react";
import { Each } from "../../components/Each";
import { CrossIcon } from "../../components/Icons";
import PageHeader from "../../components/PageHeader/PageHeader";
import "../PersonInformation/PersonInformation.css";
import { useNavigate } from "react-router-dom";

const EditRoleManager = (_props) => {
  const person = [
    "Amit Guru",
    "Shaleen Mishra",
    "Madhulika Mishra ",
    "Amit Patel",
    "Harsh Mishra",
    "Anshul Jain",
    "Gopal Sen",
  ];
  const [tab, setTab] = useState("General");
  const handlesubmit = () => {
    console.log(info);
  };
  const [info, setInfo] = useReducer(
    (prev, next) => ({                                                                                                                                                                       
      ...prev,
      ...next,
    }),
    {
      ProcessName: " ",
      Description: " ",
    }
  );

  const [roleMatrix, setRoleMatrix] = useState({});
  const navigate = useNavigate();
  const handleCheckboxChange = (personName, role) => {
    setRoleMatrix((prevState) => ({
      ...prevState,
      [personName]: {
        ...prevState[personName],
        [role]: !prevState[personName]?.[role],
      },
    }));
  };

  useEffect(() => {
    console.log(roleMatrix);
  }, [roleMatrix]);
  return (
    <>
      <div style={{ position: "fixed", width: "82.5%" }} className="h-full">
        <PageHeader title={<div className="text-[17px]">Role Manager</div>} />
        <div className="document-block">
        <div className="flex justify-between items-center">
          <div className="form-tabs">
            <div
              onClick={() => setTab("General")}
              className={tab === "General" ? "active" : ""}
            >
            General Information
            </div>
            
            <div
              onClick={() => setTab("roleMatrix")}
              className={tab === "roleMatrix" ? "active" : ""}
            >
             Role Matrix
            </div>
          </div>
          <div className="button-block">
          <button
                      className="themeBtn"
                      onClick={() => navigate("role-manager/manage")}
                    >
                      Cancel
                    </button>
                    <button className="themeBtn" onClick={() => navigate()}>
                      Save
                    </button>
                
                  </div>
          </div>
          {tab === "General" && (
            <div className="document-form">
              <div className="sub-head"> General Information</div>
              <div className="personal-info">
                <div className="section-body">
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Process Name
                    </label>
                    <input
                      value={info.ProcessName}
                      onChange={(e) => setInfo({ ProcessName: e.target.value })}
                      type="text"
                      required
                    />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Description
                    </label>
                    <textarea
                      value={info.Description}
                      onChange={(e) => setInfo({ Description: e.target.value })}
                      required
                    ></textarea>
                  </div>
                </div>
              </div>
            
            </div>
          )}
           {tab === "roleMatrix" && (
                <div className="document-form">
                  <div className="sub-head">Role Matrix</div>
                  <div className="personal-info">
                  <div className="section-body">
                    <table>
                      <thead>
                        <tr>
                          <th>&nbsp;</th>
                          <th>Initiator</th>
                          <th>HOD</th>
                          <th>QA</th>
                          <th>Can Create Children</th>
                        </tr>
                      </thead>
                      <tbody>
                        <Each
                          of={person}
                          render={(item, index) => (
                            <tr key={index}>
                              <td>{item}</td>
                              <td>
                                <input
                                  type="checkbox"
                                  checked={roleMatrix[item]?.Initiator}
                                  onChange={() =>
                                    handleCheckboxChange(item, "Initiator")
                                  }
                                />
                              </td>
                              <td>
                                <input
                                  type="checkbox"
                                  checked={roleMatrix[item]?.HOD}
                                  onChange={() =>
                                    handleCheckboxChange(item, "HOD")
                                  }
                                />
                              </td>
                              <td>
                                <input
                                  type="checkbox"
                                  checked={roleMatrix[item]?.QA}
                                  onChange={() =>
                                    handleCheckboxChange(item, "QA")
                                  }
                                />
                              </td>
                              <td>
                                <input
                                  type="checkbox"
                                  checked={roleMatrix[item]?.CreateChildren}
                                  onChange={() =>
                                    handleCheckboxChange(item, "CreateChildren")
                                  }
                                />
                              </td>
                            </tr>
                          )}
                        />
                      </tbody>
                    </table>
                  </div>
                  </div>
                  <div className="button-block" style={{ width: "100%" }}>
              <button
                className="themeBtn"
                onClick={() => {
         
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => {
                  setTab("General");
                }}
              >
                Back
              </button>
        
              <button
                className="themeBtn"
                onClick={() => navigate("/role-manager/manage")}
              >
                Exit
              </button>
            </div>
                </div>
              )}
              
        </div>

       
      </div>
    </>
  );
};

export default EditRoleManager;
