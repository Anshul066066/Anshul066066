import React from "react";
import { useEffect, useReducer, useState } from "react";
import { Each } from "../../components/Each";
import { CrossIcon } from "../../components/Icons";
import PageHeader from "../../components/PageHeader/PageHeader";
import "../PersonInformation/PersonInformation.css";
import { useNavigate } from "react-router-dom";
import { FormControl, Select } from "@mui/material";

const AddRoleManager = (_props) => {
  const person = [
    "Amit Guru",
    "Shaleen Mishra",
    "Madhulika Mishra ",
    "Amit Patel",
    "Harsh Mishra",
    "Anshul Jain",
    "Gopal Sen",
  ];
  const [tab, setTab] = useState("General");
  const handlesubmit = () => {
    console.log(info);
  };
  const [info, setInfo] = useReducer(
    (prev, next) => ({
      ...prev,
      ...next,
    }),
    {
      ProcessName: " ",
      Description: " ",
    }
  );

  const [roleMatrix, setRoleMatrix] = useState({});
  const navigate = useNavigate();
  const handleCheckboxChange = (personName, role) => {
    setRoleMatrix((prevState) => ({
      ...prevState,
      [personName]: {
        ...prevState[personName],
        [role]: !prevState[personName]?.[role],
      },
    }));
  };

  useEffect(() => {
    console.log(roleMatrix);
  }, [roleMatrix]);

  const userRole = [
    'Initiator',
    'Lead Investigator',
    'Manager',
    'FP',
    'Lead Investigator',
    'Manager',

  ];

  const [personName, setPersonName] = React.useState([]);
  const handleChangeMultiple = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonName(value);
  };

  const userProgram = [
    'Initiator',
    'Lead Investigator',
    'Manager',
    'FP',
    'Lead Investigator',
    'Manager',

  ];

  const [personProgram, setPersonProgram] = React.useState([]);
  const handleChangeMultipleProgram = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonProgram(value);
  };

  const userCalibration = [
    'Initiator',
    'Lead Investigator',
    'Manager',
    'FP',
    'Lead Investigator',
    'Manager',

  ];

  const [personCalibration, setPersonCalibration] = React.useState([]);
  const handleChangeMultipleCalibration = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonCalibration(value);
  };
  // ====================User Group====================//
  const usrGropu = [
    'FP/Action Item FP',

  ];
  const [personUsrGropu, setPersonUsrGropu] = React.useState([]);
  const handleChangeMultipleUsrGropu = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonUsrGropu(value);
  };

  const usrGropuProgram = [
    'FP/FP',

  ];
  const [personUsrGropuProgram, setPersonUsrGropuProgram] = React.useState([]);
  const handleChangeMultipleUsrGropuProgram = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonUsrGropuProgram(value);
  };

  // ================================== View UFD =========================//
  const UFD = [
    'Additional Investigator',
    'Approved By',
    'Approvers',
  ];

  const [viewUFDProgram, setViewUFDProgram] = React.useState([]);
  const handleChangeMultipleUFDProgram = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setViewUFDProgram(value);
  };

  const UFDProgram = [
       'Originator VGC'

  ];

  const [viewUFD, setViewUFD] = React.useState([]);
  const handleChangeMultipleUFD = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setViewUFD(value);
  };

  const UFDCalibration = [
    'Completed BY',
    'Lead Investigator',
    'QA Approvers'

];

const [viewUFDCalibration, setViewUFDCalibration] = React.useState([]);
const handleChangeMultipleUFDCalibration = (event) => {
 const { options } = event.target;
 const value = [];
 for (let i = 0, l = options.length; i < l; i += 1) {
   if (options[i].selected) {
     value.push(options[i].value);
   }
 }
 setViewUFDCalibration(value);
};

  return (
    <>
      <div style={{  width: "100%" }} className="h-full">
        <PageHeader title={<div className="text-[17px]">Role Manager</div>} />
        <div className="document-block">
          <div className="flex justify-between items-center">
            <div className="form-tabs">
              <div
                onClick={() => setTab("General")}
                className={tab === "General" ? "active" : ""}
              >
                General Information
              </div>

              <div
                onClick={() => setTab("roleMatrix")}
                className={tab === "roleMatrix" ? "active" : ""}
              >
                Role Matrix
              </div>
            </div>
            <div className="button-block">
              <button
                className="themeBtn"
                onClick={() => navigate("/role-manager/manage")}
              >
                Cancel
              </button>
              <button className="themeBtn" onClick={() => navigate()}>
                Save
              </button>
              <button className="themeBtn" onClick={() => navigate()}>
                Duplicate
              </button>
            </div>
          </div>
          {tab === "General" && (
            <div className="document-form">
              <div className="sub-head"> General Information</div>
              <div className="personal-info">
                <div className="section-body">
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Process Name
                    </label>
                    <input
                      value={info.ProcessName}
                      onChange={(e) => setInfo({ ProcessName: e.target.value })}
                      type="text"
                      required
                    />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Description
                    </label>
                    <textarea
                      value={info.Description}
                      onChange={(e) => setInfo({ Description: e.target.value })}
                      required
                    ></textarea>
                  </div>
                </div>
              </div>
            </div>
          )}
          {tab === "roleMatrix" && (
            <div className="document-form">
              <div className="sub-head">Role Matrix</div>

              <div className="table-block">
                  <table>
                    <thead>
                      <tr>
                        <th>Process</th>
                        <th>Person Roles</th>
                        <th>User Group/Group Category</th>
                        <th>Is Member</th>
                        <th>Is Active</th>
                        <th>View All</th>
                        <th>View By UFD</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>Action Item</td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                              <Select
                                multiple
                                native
                                value={personName}
                                onChange={handleChangeMultiple}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {userRole.map((name) => (
                                  <option key={name} value={name}>
                                    {name}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                            <p style={{ fontWeight: "bold" }}>
                              Selected Values:
                            </p>
                            <input value={personName} />
                          </div>
                        </td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 170, maxWidth: 300 }}>
                              <Select
                                native
                                value={personUsrGropu}
                                onChange={handleChangeMultipleUsrGropu}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {usrGropu.map((user) => (
                                  <option key={user} value={user}>
                                    {user}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                          </div>
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                              <Select
                                multiple
                                native
                                value={viewUFD}
                                onChange={handleChangeMultipleUFD}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {UFD.map((name) => (
                                  <option key={name} value={name}>
                                    {name}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                            <p style={{ fontWeight: "bold" }}>
                              Selected Values:
                            </p>
                            <input value={viewUFD} />
                          </div>
                        </td>
                      </tr>

                      <tr>
                        <td>Audit Program</td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                              <Select
                                multiple
                                native
                                value={personProgram}
                                onChange={handleChangeMultipleProgram}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {userRole.map((name) => (
                                  <option key={name} value={name}>
                                    {name}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                            <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                            <input value={personProgram} />
                          </div>
                        </td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 170, maxWidth: 300 }}>
                              <Select
                                native
                                value={personUsrGropuProgram}
                                onChange={handleChangeMultipleUsrGropuProgram}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {usrGropuProgram.map((user) => (
                                  <option key={user} value={user}>
                                    {user}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                          </div>
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                              <Select
                                multiple
                                native
                                value={viewUFDProgram}
                                onChange={handleChangeMultipleUFDProgram}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {UFDProgram.map((name) => (
                                  <option key={name} value={name} >
                                    {name}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                            <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                            <input value={viewUFDProgram} />
                          </div>
                        </td>
                      </tr>

                      <tr>
                        <td>Calibration</td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                              <Select
                                multiple
                                native
                                value={personCalibration}
                                onChange={handleChangeMultipleCalibration}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {userCalibration.map((name) => (
                                  <option key={name} value={name} >
                                    {name}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                            <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                            <input value={personCalibration} />
                          </div>
                        </td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 170, maxWidth: 300 }}>
                              <Select
                                native
                                value={personUsrGropu}
                                onChange={handleChangeMultipleUsrGropu}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {usrGropu.map((user) => (
                                  <option key={user} value={user}>
                                    {user}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                          </div>
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <input type="checkbox" />
                        </td>
                        <td>
                          <div>
                            <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                              <Select
                                multiple
                                native
                                value={viewUFDCalibration}
                                onChange={handleChangeMultipleUFDCalibration}
                                inputProps={{
                                  id: "select-multiple-native",
                                }}
                              >
                                {UFDCalibration.map((name) => (
                                  <option key={name} value={name} >
                                    {name}
                                  </option>
                                ))}
                              </Select>
                            </FormControl>
                            <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                            <input value={viewUFDCalibration} />
                          </div>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                
                  </div>
              <div className="button-block" style={{ width: "100%",  }}>
                <button className="themeBtn" onClick={() => {}}>
                  Save
                </button>
                <button
                  className="themeBtn"
                  onClick={() => {
                    setTab("General");
                  }}
                >
                  Back
                </button>

                <button
                  className="themeBtn"
                  onClick={() => navigate("/role-manager/manage")}
                >
                  Exit
                </button>
              </div>
            
            </div>
          )}
        </div>
      </div>
    </>
  );
};

export default AddRoleManager;
