import { useState } from "react";
import { Each } from "../../components/Each";
import { tableBody, tableHead } from "./RoleManagerData";
import {
  AddIcon,
  DefaultColor,
  Download,
  Edit,
} from "../../components/Icons";
import PageHeader from "../../components/PageHeader/PageHeader";
import PageSearchBar from "../../components/PageSearchBar/PageSearchBar";
import AddRoleManagerModal from "../../components/Modals/AddEntitiesModal/AddRoleManagerModal";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import "./RoleManager.css";
import { useNavigate } from "react-router-dom";
import AssignmentIndIcon from '@mui/icons-material/AssignmentInd';


function RoleManager() {
  const [roleManagerModal, setRoleManagerModal] = useState(false);
  const closeAddAccessModal = () => setRoleManagerModal(false);
  const [search, setSearch] = useState("");
  const [filterData, setFilterData] = useState(tableBody);
  const navigate = useNavigate();
  const SearchValue = (value) => {
    setSearch(value);
    const filteredData = tableBody.filter((item) => {
      const lowerCaseValue = value.toLowerCase();
      const lowerCaseName = item.processName.toLowerCase();
      const lowerCasePersonID = item.description.toLowerCase();
      return (
        lowerCaseName.includes(lowerCaseValue) ||
        lowerCasePersonID.includes(lowerCaseValue)
      );
    });
    setFilterData(filteredData);
  };
  return (
    <>
    <div style={{maxWidth:"100%"}}>

      <PageHeader
        title={
          <div className="text-[17px]">
            <AssignmentIndIcon/>Role Manager
          </div>
        }
      />
     
      <div id="role-manager-page">

        <div className="top-block"  >
         
          <PageSearchBar value={search} setValue={SearchValue} />

         
          <div className="btn-bar" >
            <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
            <div className="themeBtn">{Download(20, "#000000")}Report</div>
            <div
              className="themeBtn"
              onClick={() => navigate("/add-role-manager")}
            >
              {AddIcon(20, "#000000")}Add{" "}
            </div>
           
          </div>
        </div>

        <div className="table-block">
          <table>
            <thead>
              <tr>
                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
              </tr>
            </thead>
            <tbody>
              <Each
                of={filterData}
                render={(item, index) => (
                  <tr>
                    <td
                      className="serial"
                      style={{ justifyContent: "space-between" }}
                    >
                      <input type="checkbox" className="w-3 mr-3" />
                      {index + 1}
                    </td>
                    <td>{item.processName}</td>
                    <td>{item.description}</td>
                    <td>
                      <div className="action">
                        <div onClick={() => navigate("/edit-role-manager")}>
                          {Edit(20, DefaultColor)}
                        </div>
                        <div>{Download(20, "#000000")}</div>
                      </div>
                    </td>
                  </tr>
                )}
              />
            </tbody>
          </table>
        </div>
      </div>

      {roleManagerModal && (
        <AddRoleManagerModal closeModal={closeAddAccessModal} />
      )}
          </div>

    </>
  );
}

export default RoleManager;
