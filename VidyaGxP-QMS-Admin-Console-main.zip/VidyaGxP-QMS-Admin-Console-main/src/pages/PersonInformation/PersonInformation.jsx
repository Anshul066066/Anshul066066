import React, { useEffect, useReducer, useState } from "react";
import PageHeader from "../../components/PageHeader/PageHeader";
import "./PersonInformation.css";
import { getCountries, getCountryCallingCode } from "libphonenumber-js";
import MultiSelectionField from "../../components/DataFields/MultiSelectionField";
import Grid from "../../components/DataFields/Grid";
import { useNavigate } from "react-router-dom";
import PhoneInput from "react-phone-input-2";
import "react-phone-input-2/lib/style.css";

function PersonInformation() {
  const [countryCodes, setCountryCodes] = useState([]);
  const divisions = ["Egypt", "Estonia", "EHS-North America", "KSA"];
  const [search, setSearch] = useState("");
  const navigate = useNavigate();
  // ===========================================validation============================================//
  // ==================firstName========//
  const [firstName, setFirstName] = useState("");
  const [firstNameError, setFirstNameError] = useState("");

  const handleFirstNameChange = (event) => {
    const { value } = event.target;
    setFirstName(value);

    if (!value.trim()) {
      setFirstNameError("First name is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setFirstNameError("First name must contain only letters");
    } else {
      setFirstNameError("");
    }
  };
  // =======================Last name=======================//
  const [lastName, setLastName] = useState("");
  const [lastNameError, setLastNameError] = useState("");

  const handleLastNameChange = (event) => {
    const { value } = event.target;
    setLastName(value);

    if (!value.trim()) {
      setLastNameError("Last name is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setLastNameError("LAst name must contain only letters");
    } else {
      setLastNameError("");
    }
  };
  // ======================= Title =======================//
  const [title, setTitle] = useState("");
  const [titleError, setTitleError] = useState("");

  const handletitleChange = (event) => {
    const { value } = event.target;
    setTitle(value);

    if (!value.trim()) {
      setTitleError("This filed is required");
    } else if (!/^[a-zA-Z]+$/.test(value)) {
      setTitleError("This filed is required");
    } else {
      setTitleError("");
    }
  };
  // ====================Salutation==========================//
  const [salutation, setSalutation] = useState("");
  const [salutationError, setSalutationError] = useState("");

  const handleSalutationChange = (event) => {
    const { value } = event.target;
    setSalutation(value);

    if (!value) {
      setSalutationError("Please select an option");
    } else {
      setSalutationError("");
    }
  };
  // ======================= Gender =======================//
  const [gender, setGender] = useState("");
  const [genderError, setGenderError] = useState("");

  const handleGenderChange = (event) => {
    const { value } = event.target;
    setGender(value);

    if (!value) {
      setGenderError("Please select Gender");
    } else {
      setGenderError("");
    }
  };
  // ======================= Department =======================//
  const [department, setDepartment] = useState("");
  const [departmentError, setDepartmentError] = useState("");

  const handleDepartmentChange = (event) => {
    const { value } = event.target;
    setDepartment(value);

    if (!value) {
      setDepartmentError("Please select an Option");
    } else {
      setDepartmentError("");
    }
  };
  // ======================= Status =======================//
  const [status, setStatus] = useState("");
  const [statusError, setStatusError] = useState("");

  const handleStatusChange = (event) => {
    const { value } = event.target;
    setStatus(value);

    if (!value) {
      setStatusError("Please select an Option");
    } else {
      setStatusError("");
    }
  };

  // ======================== Email ======================//

  const [email, setEmail] = useState("");

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };
  const validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  // ======================================================//
  const formList = [
    "Person Details",
    "Geographic Information",
    "Additional Details",
  ];

  const [form, setForm] = useState(formList[0]);

  useEffect(() => {
    const allCountries = getCountries();
    const codes = allCountries.map((country) => getCountryCallingCode(country));
    setCountryCodes(codes);
  }, []);
  const handleSubmit = async () => {
    try {
      const response = await apiService.addPerson(person);
      console.log("Person Created :", response);
    } catch (error) {
      console.error("Error Creating Person :", error);
    }
  };
  const references = {
    id: 1,
    label: "References",
    isRequired: "false",
    instruction: "",
    columnList: [
      { id: 1.1, name: "Title of Document", type: "text" },
      { id: 1.2, name: "Attachment", type: "file" },
      { id: 1.3, name: "Remarks", type: "text" },
    ],
  };
  const [person, setPerson] = useReducer(
    (prev, next) => ({
      ...prev,
      ...next,
    }),
    {
      personID: "",
      profilePhoto: "",
      firstName: "",
      middleName: "",
      lastName: "",
      title: "",
      manager: "",
      gender: "",
      salutation: "",
      function: "",
      department: "",
      otherDepartment: "",
      phoneNum: "",
      mobileNum: "",
      personEmail: "",
      managerEmail: "",
      status: "",
      fax: "",
      address: "",
      postalCode: "",
      country: "",
      city: "",
      detailedAddress: "",

      comments: "",
      references: "",
    }
  );
  useEffect(() => {
    setPerson({ personEmail: email });
    setPerson({ firstName: firstName });
    setPerson({ title: title });
    setPerson({ salutation: salutation });
    setPerson({ gender: gender });
    setPerson({ department: department });
    setPerson({ status: status });
  }, [email, firstName, title, salutation, gender, department, status]);

  const [value, setValue] = React.useState("1");

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">Person Information</div>}
        />
      </div>
      <div id="personinformation">
        <div className="document-block">
          <div className="flex m-5 justify-between items-center">
            <div>
              <div className="document-tabs flex">
                {formList.map((item, index) => (
                  <div
                    key={index}
                    className={form === item ? "active" : ""}
                    onClick={() => setForm(item)}
                  >
                    {item}
                  </div>
                ))}
              </div>
            </div>
            <div className=" justify-between items-center ">
              <div className="button-block" style={{ width: "100%" }}>
                <button
                  className="themeBtn"
                  onClick={() => {
                    handleSave(differentialPRecord);
                  }}
                >
                  Save
                </button>
                <button
                  className="themeBtn"
                  onClick={() => navigate("/person/manage")}
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>

          {form === formList[0] ? (
            <div className="document-form">
              <div className="sub-head">Person Details</div>
              <div className="personal-info">
                <div className="section-body">
                  <div className="dual-group-input">
                    <div className="group-input">
                      <label>Person ID</label>
                      <input value="" type="text" disabled />
                    </div>
                    <div className="group-input">
                      <label>Profile Photo</label>
                      <input value="" type="file" />
                    </div>
                  </div>
                  <div className="triple-group-input">
                    <div className="group-input">
                      <label>
                        <div className="required"></div>First Name
                      </label>
                      <input
                        value={firstName}
                        onChange={handleFirstNameChange}
                        type="text"
                        required
                      />
                      {firstNameError && (
                        <p
                          style={{
                            color: "red",
                            padding: "0",
                            margin: "7px",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          {firstNameError}
                        </p>
                      )}
                    </div>
                    <div className="group-input">
                      <label>Middle Name</label>
                      <input
                        value={person.middleName}
                        onChange={(e) =>
                          setPerson({
                            middleName: e.target.value,
                          })
                        }
                        type="text"
                      />
                    </div>
                    <div className="group-input">
                      <label>
                        <div className="required"></div>Last Name
                      </label>
                      <input
                        value={lastName}
                        onChange={handleLastNameChange}
                        type="text"
                        required
                      />
                      {lastNameError && (
                        <p
                          style={{
                            color: "red",
                            padding: "0",
                            margin: "7px",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          {lastNameError}
                        </p>
                      )}
                    </div>
                  </div>
                  <MultiSelectionField
                    label="Division"
                    optionList={divisions}
                  />
                  <div className="dual-group-input">
                    <div className="group-input">
                      <label>
                        <div className="required"></div>Title
                      </label>
                      <input
                        value={title}
                        onChange={handletitleChange}
                        type="text"
                        required
                      />
                      {titleError && (
                        <p
                          style={{
                            color: "red",
                            padding: "0",
                            margin: "7px",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          {titleError}
                        </p>
                      )}
                    </div>
                    <div className="group-input">
                      <label>Manager</label>
                      <select
                        value={person.manager}
                        onChange={(e) =>
                          setPerson({
                            manager: e.target.value,
                          })
                        }
                      >
                        <option value="">-- Select --</option>
                        <option value="amit_guru">Amit Guru</option>
                        <option value="shaleen_mishra">Shaleen Mishra</option>
                      </select>
                    </div>
                    <div className="group-input">
                      <label>
                        <div className="required"></div>Salutation
                      </label>
                      <select
                        required
                        value={salutation}
                        onChange={handleSalutationChange}
                      >
                        <option value="">-- Select --</option>
                        <option value="Ms.">Ms.</option>
                        <option value="Mr.">Mr.</option>
                        <option value="Mrs.">Mrs.</option>
                        <option value="Miss">Miss</option>
                        <option value="Dr.">Dr.</option>
                        <option value="Br.">Br.</option>
                        <option value="Sr.">Sr.</option>
                      </select>
                      {salutationError && (
                        <p
                          style={{
                            color: "red",
                            padding: "0",
                            margin: "7px",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          {salutationError}
                        </p>
                      )}
                    </div>
                    <div className="group-input">
                      <label>
                        <div className="required"></div>Gender
                      </label>
                      <select
                        required
                        value={gender}
                        onChange={handleGenderChange}
                      >
                        <option value="">-- Select --</option>
                        <option value="Male">Male</option>
                        <option value="Female">Female</option>
                        <option value="Others">Others</option>
                      </select>
                      {genderError && (
                        <p
                          style={{
                            color: "red",
                            padding: "0",
                            margin: "7px",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          {genderError}
                        </p>
                      )}
                    </div>
                    <div className="group-input">
                      <label>Function</label>
                      <select
                        value={person.function}
                        onChange={(e) =>
                          setPerson({
                            function: e.target.value,
                          })
                        }
                      >
                        <option value="">-- Select --</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                      </select>
                    </div>
                    <div className="group-input">
                      <label>
                        <div className="required"></div>Department
                      </label>
                      <select
                        value={department}
                        onChange={handleDepartmentChange}
                      >
                        <option value="">-- Select --</option>
                        <option value="CQA">Corporate Quality Assurance</option>
                        <option value="QAB">Quality Assurance BioPharma</option>
                        <option value="CQC">Central Quality Control</option>
                        <option value="Manu">Manufacturing</option>
                        <option value="PSG">Plasma Sourcing Group</option>
                        <option value="CS">Central Stores</option>
                        <option value="ITG">
                          Information Technology Group
                        </option>
                        <option value="MM">Molecular Medicine</option>
                        <option value="CL">Central Laboratory</option>
                        <option value="TT">Tech Team</option>
                        <option value="QA">Quality Assurance</option>
                        <option value="QM">Quality Management</option>
                        <option value="IA">IT Administration</option>
                        <option value="Acc">Accounting</option>
                        <option value="Log">Logistics</option>
                        <option value="SM">Senior Management</option>
                        <option value="BA">Business Administration</option>
                        <option value="Others">Others</option>
                      </select>
                      {departmentError && (
                        <p
                          style={{
                            color: "red",
                            padding: "0",
                            margin: "7px",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          {departmentError}
                        </p>
                      )}
                    </div>
                  </div>
                  <div className="dual-group-input">
                    <div className="">
                      <label>Phone Number</label>
                      <div className="mobile-field">
                        <PhoneInput
                          country={"in"}
                          countryCodeEditable={false}
                          placeholder="enter your phone number"
                          dropdownStyle={{ top: "-200px" }}
                          value={person.phoneNum}
                          onChange={(value) => setPerson({ phoneNum: value })}
                        />
                      </div>
                    </div>
                    <div style={{ width: "100%" }}>
                      <label>Mobile Number</label>
                      <div className="">
                        <PhoneInput
                          country={"in"}
                          countryCodeEditable={false}
                          placeholder="enter your phone number"
                          dropdownStyle={{ top: "-200px" }}
                          value={person.mobileNum}
                          onChange={(value) => setPerson({ mobileNum: value })}
                        />
                      </div>
                    </div>
                    <div className="group-input">
                      <label>
                        <div className="required"></div>Person E-Mail
                      </label>
                      <input
                        value={email}
                        onChange={handleEmailChange}
                        type="email"
                        required
                      />
                      {email && !validateEmail(email) && (
                        <p
                          style={{
                            color: "red",
                            padding: "0",
                            margin: "7px",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          Please enter a valid email
                        </p>
                      )}
                    </div>
                    <div className="group-input">
                      <label>Manager E-Mail</label>
                      <input
                        value={person.managerEmail}
                        onChange={(e) =>
                          setPerson({
                            managerEmail: e.target.value,
                          })
                        }
                        type="email"
                      />
                    </div>

                    <div className="group-input">
                      <label>Fax</label>
                      <input
                        value={person.fax}
                        onChange={(e) =>
                          setPerson({
                            fax: e.target.value,
                          })
                        }
                        type="text"
                      />
                    </div>
                    <div className="group-input">
                      <label>
                        <div className="required"></div>Status
                      </label>
                      <select
                        required
                        value={status}
                        onChange={handleStatusChange}
                      >
                        <option value="">-- Select --</option>
                        <option value="Active">Active</option>
                        <option value="Inactive">Inactive</option>
                      </select>
                      {statusError && (
                        <p
                          style={{
                            color: "red",
                            padding: "0",
                            margin: "7px",
                            fontWeight: "bold",
                            fontSize: "14px",
                          }}
                        >
                          {statusError}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          ) : form === formList[1] ? (
            <div className="document-form">
              <div className="sub-head">Geographic Information</div>
              <div className="section-body">
                <div className="dual-group-input">
                  <div className="group-input">
                    <label>Address</label>
                    <input
                      value={person.address}
                      onChange={(e) =>
                        setPerson({
                          address: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                  <div className="group-input">
                    <label>Postal Code</label>
                    <input
                      value={person.postalCode}
                      onChange={(e) =>
                        setPerson({
                          postalCode: e.target.value,
                        })
                      }
                      type="number"
                    />
                  </div>
                  <div className="group-input">
                    <label>Country</label>
                    <input
                      value={person.country}
                      onChange={(e) =>
                        setPerson({
                          country: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                  <div className="group-input">
                    <label>City</label>
                    <input
                      value={person.city}
                      onChange={(e) =>
                        setPerson({
                          city: e.target.value,
                        })
                      }
                      type="text"
                    />
                  </div>
                </div>
                <div className="group-input mb-0">
                  <label>Detailed Address</label>
                  <input
                    value={person.detailedAddress}
                    onChange={(e) =>
                      setPerson({
                        detailedAddress: e.target.value,
                      })
                    }
                    type="text"
                  />
                </div>
              </div>
            </div>
          ) : form === formList[2] ? (
            <div className="document-form">
              <div className="sub-head">Additional Details</div>
              <div className="section-body">
                <div className="group-input">
                  <label>Comments</label>
                  <textarea
                    value={person.comments}
                    onChange={(e) =>
                      setPerson({
                        comments: e.target.value,
                      })
                    }
                  ></textarea>
                </div>
                <Grid
                  label={references.label}
                  isRequired={references.isRequired}
                  instruction={references.instruction}
                  columnList={references.columnList}
                  onChange={(data) => setPerson({ references: data })}
                  //   onChange={(data) => console.log(data)}
                />
              </div>
            </div>
          ) : (
            ""
          )}
        </div>
      </div>
    </>
  );
}

export default PersonInformation;
