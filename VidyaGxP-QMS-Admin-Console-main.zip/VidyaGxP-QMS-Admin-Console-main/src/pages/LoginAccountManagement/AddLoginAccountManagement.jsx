import React, { useState } from 'react'

import {
  CrossIcon,
  DefaultColor,
  Download,
  Edit,
  EyeIcon,
  EyeSlashIcon,
} from "../../components/Icons";
import MultiSelectionField from "../../components/DataFields/MultiSelectionField";
import PageHeader from "../../components/PageHeader/PageHeader";
import { Card } from "@mui/material";
import "../PersonInformation/PersonInformation.css";
import { useNavigate } from "react-router-dom";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";

function AddLoginAccountManagement(_props) {
  const [passwordType, setPasswordType] = useState("password");
  const [tab, setTab] = useState("Login Account");

  const optionList = [
    "Change Control",
    "CAPA",
    "Internal Audit",
    "External Audit",
  ];
  const userDivision = ["Globle"];

  const [personDivision, setPersonDivision] = React.useState([]);
  const handleChangeMultipleDivision = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonDivision(value);
  };
  const userRole = [
    "Initiator",
    "Lead Investigator",
    "Manager",
    "FP",
    "Lead Investigator",
    "Manager",
  ];
  const initialData = [
    { name: "Super Admin", canEdit: false },
    { name: "Actions", canEdit: false },
    { name: "Audit Manager Admin", canEdit: false },
    { name: "Audit Manager Distribution", canEdit: false },
    { name: "Audit Trail", canEdit: false },
    { name: "Auitomation", canEdit: false },
    { name: "Cluster", canEdit: false },
    { name: "Login Accounts", canEdit: false },
    { name: "Migrator", canEdit: false },
    { name: "Notification Manager", canEdit: false },
    { name: "Projects", canEdit: false },
    { name: "Record Stages", canEdit: false },
    { name: "System Flags", canEdit: false },
    { name: "Terminology", canEdit: false },
  ];

  const [tableData, setTableData] = useState(initialData);
  const navigate = useNavigate();

  const handleCheckboxChange = (index) => {
    if (index === 0) {
      const isSuperAdminChecked = !tableData[0].canEdit;
      const newTableData = tableData.map((row, i) => {
        if (row.name === "Migrator") {
          return row;
        } else if (i === 0) {
          return { ...row, canEdit: isSuperAdminChecked };
        } else {
          return { ...row, canEdit: isSuperAdminChecked };
        }
      });

      setTableData(newTableData);
    } else {
      const newTableData = tableData.map((row, i) => {
        if (i === index) {
          return { ...row, canEdit: !row.canEdit };
        }
        return row;
      });

      setTableData(newTableData);
    }
  };

  const [personName, setPersonName] = React.useState([]);
  const handleChangeMultiple = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonName(value);
  };

  const userProgram = [
    "Initiator",
    "Lead Investigator",
    "Manager",
    "FP",
    "Lead Investigator",
    "Manager",
  ];

  const [personProgram, setPersonProgram] = React.useState([]);
  const handleChangeMultipleProgram = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonProgram(value);
  };

  const userCalibration = [
    "Initiator",
    "Lead Investigator",
    "Manager",
    "FP",
    "Lead Investigator",
    "Manager",
  ];

  const [personCalibration, setPersonCalibration] = React.useState([]);
  const handleChangeMultipleCalibration = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonCalibration(value);
  };
  // ====================User Group====================//
  const usrGropu = ["FP/Action Item FP"];
  const [personUsrGropu, setPersonUsrGropu] = React.useState([]);
  const handleChangeMultipleUsrGropu = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonUsrGropu(value);
  };

  const usrGropuProgram = ["FP/FP"];
  const [personUsrGropuProgram, setPersonUsrGropuProgram] = React.useState([]);
  const handleChangeMultipleUsrGropuProgram = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setPersonUsrGropuProgram(value);
  };

  // ================================== View UFD =========================//
  const UFD = ["Additional Investigator", "Approved By", "Approvers"];

  const [viewUFDProgram, setViewUFDProgram] = React.useState([]);
  const handleChangeMultipleUFDProgram = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setViewUFDProgram(value);
  };

  const UFDProgram = ["Originator VGC"];

  const [viewUFD, setViewUFD] = React.useState([]);
  const handleChangeMultipleUFD = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setViewUFD(value);
  };

  const UFDCalibration = ["Completed BY", "Lead Investigator", "QA Approvers"];

  const [viewUFDCalibration, setViewUFDCalibration] = React.useState([]);
  const handleChangeMultipleUFDCalibration = (event) => {
    const { options } = event.target;
    const value = [];
    for (let i = 0, l = options.length; i < l; i += 1) {
      if (options[i].selected) {
        value.push(options[i].value);
      }
    }
    setViewUFDCalibration(value);
  };

  return (
    <>
      <PageHeader
        title={<div className="text-[17px]">Login Account Information</div>}
      />

      <div id="PersonalInformation">
        <div className="document-block">
          <div className="flex justify-between items-center">
            <div className="form-tabs">
              <div
                onClick={() => setTab("Login Account")}
                className={tab === "Login Account" ? "active" : ""}
              >
                Login Account Information
              </div>

              <div
                onClick={() => setTab("Access Management")}
                className={tab === "Access Management" ? "active" : ""}
              >
                Access Management
              </div>
              <div
                onClick={() => setTab("Membership")}
                className={tab === "Membership" ? "active" : ""}
              >
                Membership
              </div>
            </div>
            <div className="button-block">
              <button className="themeBtn" onClick={() => navigate()}>
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/login-accounts/manage")}
              >
                Cancel
              </button>
              <button
                className="themeBtn"
                // onClick={() => navigate("/login-accounts/manage")}
              >
                Duplicate
              </button>
              <div className="themeBtn">{Download(20, "#000000")}Report</div>
            </div>
          </div>
        </div>

        <div className="modal-middle">
          {tab === "Login Account" && (
            <div className="document-form">
              <div className="sub-head">Login Account Details</div>
              <div className="section-body">
                <div className="dual-group-input">
                  <div className="group-input">
                    <label>UID</label>
                    <input type="text" disabled />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Login Name
                    </label>
                    <input type="text" required />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Person Name
                    </label>
                    <select required>
                      <option value="">-- Select --</option>
                      <option value="amit_guru">Amit Guru</option>
                      <option value="shaleen_mishra">Shaleen Mishra</option>
                    </select>
                  </div>
                  <div className="group-input ">
                    <label>
                      <div className="required"></div>Password
                    </label>
                    <div className="password-field flex items-center">
                      <input type={passwordType} required />
                      {passwordType === "password" ? (
                        <div onClick={() => setPasswordType("text")}>
                          {EyeIcon(20, "#808080")}
                        </div>
                      ) : (
                        <div onClick={() => setPasswordType("password")}>
                          {EyeSlashIcon(20, "#808080")}
                        </div>
                      )}
                    </div>
                  </div>
                  <div className="group-input">
                    <label>Person E-Mail</label>
                    <input type="email" disabled />
                  </div>
                  <div className="group-input">
                    <label>
                      <div className="required"></div>Status
                    </label>
                    <select required>
                      <option value="">-- Select --</option>
                      <option value="Active">Active</option>
                      <option value="Inactive">Inactive</option>
                    </select>
                  </div>
                </div>
                <div className="group-input">
                  <label>Comments</label>
                  <textarea></textarea>
                </div>
              </div>
            </div>
          )}

          {tab === "Access Management" && (
            <div className="document-form">
              <div className="sub-head">Access Management</div>
              <div className="section-body">
                <div className="dual-group-input">
                  <MultiSelectionField
                    label={
                      <div>
                        User Interface
                        <span className="text-themeColor">(View Only)</span>
                      </div>
                    }
                    optionList={optionList}
                  />
                  <MultiSelectionField
                    label={
                      <div>
                        User Interface
                        <span className="text-themeColor">
                          (Supreme Administrator)
                        </span>
                      </div>
                    }
                    optionList={optionList}
                    direction="right"
                  />
                  <div className=" border-b border-black flex justify-between p-2">
                    <div>
                      <label>
                        Admin Console
                        <span className="text-themeColor font-bold text-sm ">
                          (View Only)
                        </span>
                      </label>
                    </div>
                    <div>
                      {" "}
                      <input type="checkbox" />
                    </div>
                  </div>
                  <div className=" border-b border-black flex justify-between p-2">
                    <div>
                      <label>
                        Admin Console
                        <span className="text-themeColor font-bold text-sm">
                          (Supreme Administrator)
                        </span>
                      </label>
                    </div>
                    <div>
                      {" "}
                      <input type="checkbox" />
                    </div>
                  </div>
                </div>
                <div className="sub-head">Permission</div>
                <div>
                  <table>
                    <thead>
                      <tr className="">
                        <th className="w-[90%]">Name</th>
                        <th className="w-[10%] text-center ">Can Edit</th>
                      </tr>
                    </thead>
                    <tbody>
                      {tableData.map((row, index) => (
                        <tr key={index} className="">
                          <td
                            className={`${
                              row.name === "Super Admin" ? "font-bold" : ""
                            }`}
                          >
                            {row.name}
                          </td>
                          <td className="flex justify-end items-center">
                            <input
                              type="checkbox"
                              checked={row.canEdit}
                              onChange={() => handleCheckboxChange(index)}
                            />
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {tab === "Membership" && (
            <div className="document-form">
              <div
                className="sub-head"
                style={{ display: "flex", justifyContent: "space-between" }}
              >
                <div>Membership</div>
                <div>
                  <div>
                    <FormControl sx={{ minWidth: 150, maxWidth: 250 }}>
                      <Select
                        sx={{ height: "3vh" }}
                        native
                        value={personDivision}
                        onChange={handleChangeMultipleDivision}
                        inputProps={{
                          id: "select-multiple-native",
                        }}
                      >
                        {userDivision.map((name) => (
                          <option key={name} value={name}>
                            {name}
                          </option>
                        ))}
                      </Select>
                    </FormControl>
                  </div>
                </div>
              </div>
              <div className="table-block">
                <table>
                  <thead>
                    <tr>
                      <th>Process</th>
                      <th>Person Roles</th>
                      <th>User Group/Group Category</th>
                      <th>Is Member</th>
                      <th>Is Active</th>
                      <th>View All</th>
                      <th>View By UFD</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>Action Item</td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                            <Select
                              multiple
                              native
                              value={personName}
                              onChange={handleChangeMultiple}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {userRole.map((name) => (
                                <option key={name} value={name}>
                                  {name}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                          <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                          <input value={personName} />
                        </div>
                      </td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 170, maxWidth: 300 }}>
                            <Select
                              native
                              value={personUsrGropu}
                              onChange={handleChangeMultipleUsrGropu}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {usrGropu.map((user) => (
                                <option key={user} value={user}>
                                  {user}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                        </div>
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                            <Select
                              multiple
                              native
                              value={viewUFD}
                              onChange={handleChangeMultipleUFD}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {UFD.map((name) => (
                                <option key={name} value={name}>
                                  {name}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                          <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                          <input value={viewUFD} />
                        </div>
                      </td>
                    </tr>

                    <tr>
                      <td>Audit Program</td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                            <Select
                              multiple
                              native
                              value={personProgram}
                              onChange={handleChangeMultipleProgram}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {userRole.map((name) => (
                                <option key={name} value={name}>
                                  {name}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                          <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                          <input value={personProgram} />
                        </div>
                      </td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 170, maxWidth: 300 }}>
                            <Select
                              native
                              value={personUsrGropuProgram}
                              onChange={handleChangeMultipleUsrGropuProgram}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {usrGropuProgram.map((user) => (
                                <option key={user} value={user}>
                                  {user}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                        </div>
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                            <Select
                              multiple
                              native
                              value={viewUFDProgram}
                              onChange={handleChangeMultipleUFDProgram}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {UFDProgram.map((name) => (
                                <option key={name} value={name}>
                                  {name}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                          <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                          <input value={viewUFDProgram} />
                        </div>
                      </td>
                    </tr>

                    <tr>
                      <td>Calibration</td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                            <Select
                              multiple
                              native
                              value={personCalibration}
                              onChange={handleChangeMultipleCalibration}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {userCalibration.map((name) => (
                                <option key={name} value={name}>
                                  {name}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                          <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                          <input value={personCalibration} />
                        </div>
                      </td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 170, maxWidth: 300 }}>
                            <Select
                              native
                              value={personUsrGropu}
                              onChange={handleChangeMultipleUsrGropu}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {usrGropu.map((user) => (
                                <option key={user} value={user}>
                                  {user}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                        </div>
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <input type="checkbox" />
                      </td>
                      <td>
                        <div>
                          <FormControl sx={{ minWidth: 100, maxWidth: 250 }}>
                            <Select
                              multiple
                              native
                              value={viewUFDCalibration}
                              onChange={handleChangeMultipleUFDCalibration}
                              inputProps={{
                                id: "select-multiple-native",
                              }}
                            >
                              {UFDCalibration.map((name) => (
                                <option key={name} value={name}>
                                  {name}
                                </option>
                              ))}
                            </Select>
                          </FormControl>
                          <p style={{ fontWeight: "bold" }}>Selected Values:</p>
                          <input value={viewUFDCalibration} />
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}

export default AddLoginAccountManagement;
