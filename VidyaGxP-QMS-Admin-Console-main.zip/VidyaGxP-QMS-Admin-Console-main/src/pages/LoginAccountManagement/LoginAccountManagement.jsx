import React, { useState } from "react";
import {
  AddIcon,
  DefaultColor,
  Download,
  Edit,
} from "../../components/Icons";
import PageHeader from "../../components/PageHeader/PageHeader";
import PageSearchBar from "../../components/PageSearchBar/PageSearchBar";
import "./LoginAccountManagement.css";
import { Each } from "../../components/Each";
import { tableBody, tableHead } from "./LoginAccountManagementData";
import LicenseModal from "../../components/Modals/LicenseModal";
import { useNavigate } from "react-router-dom";
import DeleteForeverIcon from "@mui/icons-material/DeleteForever";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import { IoPersonAddSharp } from "react-icons/io5";

function LoginAccountManagement() {
  const [addLoginAccountModal, setAddLoginAccountModal] = useState(false);
  const [addLicenseModal, setLicenseModal] = useState(false);
  const [active, setActive] = useState("Active");
  const closeLicenseModal = () => setLicenseModal(false);
  const navigate = useNavigate();
  const handleAddLoginAccount = () => {
    if (tableBody.length <= 55) {
      setAddLoginAccountModal(true);
    } else {
      setLicenseModal(true);
    }
  };
  const [search, setSearch] = useState("");
  const [filterData, setFilterData] = useState(tableBody);
  const SearchValue = (value) => {
    setSearch(value);
    const filteredData = tableBody.filter((item) => {
      const lowerCaseValue = value.toLowerCase();
      const lowerCaseName = item.loginName.toLowerCase();
      const lowerCasePersonID = item.personName.toLowerCase();
      return (
        lowerCaseName.includes(lowerCaseValue) ||
        lowerCasePersonID.includes(lowerCaseValue)
        
      );
    });
    setFilterData(filteredData);
  };
  return (
    <>
      <PageHeader
        title={
          <div className="text-[17px]">
            {<IoPersonAddSharp/>}Login Accounts
          </div>
        }
      />

      <div id="login-account-management-page">
        <div className="top-block">
          <PageSearchBar value={search} setValue={SearchValue} />
          {/* <div className="group-input-2">
            <label>Status</label>
            <select>
              <option value="All">All</option>
              <option value="Active">Active</option>
              <option value="Inactive">Inactive</option>
            </select>
          </div> */}
          <div className="btn-bar">
            <div className="themeBtn">{<DeleteForeverIcon />}Delete</div>
            {active === "Active" ? (
              <div
                onClick={() => setActive("Inactive")}
                className="themeBtn w-[110px]"
              >
                {<ToggleOffIcon />}Inactivate
              </div>
            ) : (
              <div
                className="themeBtn w-[110px]"
                onClick={() => setActive("Active")}
              >
                {<ToggleOnIcon />}Activate
              </div>
            )}
            <div className="themeBtn">{Download(20, "#000000")}Report</div>
            <div
              className="themeBtn"
              onClick={() => (
                handleAddLoginAccount, navigate("/add-login-account-management")
              )}
            >
              {AddIcon(20, "#000000")}Add
            </div>
          </div>
        </div>

        <div className="table-block">
          <table>
            <thead>
              <tr>
                <Each of={tableHead} render={(item) => <th>{item.th}</th>} />
              </tr>
            </thead>
            <tbody>
              <Each
                of={filterData}
                render={(item, index) => (
                  <tr>
                    <td
                      className="serial"
                      style={{ justifyContent: "space-between" }}
                    >
                      <input type="checkbox" className="w-3 mr-3" />
                      {index + 1}
                    </td>
                    <td>{item.uid}</td>
                    <td>{item.loginName}</td>
                    <td>{item.personName}</td>
                    <td>{item.mailID}</td>
                    <td>
                      <div className="action">
                        <div onClick={() => setAddLoginAccountModal(true)}>
                          {Edit(20, DefaultColor)}
                        </div>
                        <div>{Download(20, "#000000")}</div>
                      </div>
                    </td>
                  </tr>
                )}
              />
            </tbody>
          </table>
        </div>
      </div>

      {addLicenseModal && <LicenseModal closeModal={closeLicenseModal} />}
    </>
  );
}

export default LoginAccountManagement;
