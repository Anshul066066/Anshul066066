export const tableHead = [
    {
        id: 1,
        th: 'Row #'
    }, {
        id: 2, 
        th: 'UID'
    }, {
        id: 3, 
        th: 'Login Name'
    },  {
        id: 4, 
        th: 'Person Name'
    }, {
        id: 5,
        th: 'Mail ID'
    } , {
        id: 6, 
        th: 'Action'
    },
]

export const tableBody = [
    {
        id: 1,
        uid: 'UID-0000001',
        loginName: 'amitg',
        personName: 'Amit Guru',
        mailID: 'amit.guru@connexo.io',
    }, {
        id: 2,
        uid: 'UID-0000002',
        loginName: 'shaleen',
        personName: 'Shaleen Mishra',
        mailID: 'shaleen.mishra@connexo.io',
    }, {
        id: 3,
        uid: 'UID-0000003',
        loginName: 'madhulika',
        personName: 'Madhulika Mishra',
        mailID: 'madhulika.mishra@connexo.io',
    }, {
        id: 4,
        uid: 'UID-0000004',
        loginName: 'amitp',
        personName: 'Amit Patel',
        mailID: 'amit.patel@connexo.io',
    }, {
        id: 5,
        uid: 'UID-0000005',
        loginName: 'anshul',
        personName: 'Anshul Jain',
        mailID: 'anshul.jain@connexo.io',
    }, {
        id: 6,
        uid: 'UID-0000006',
        loginName: 'gopal',
        personName: 'Gopal Sen',
        mailID: 'gopal.sen@connexo.io',
    }, 
]