import { useReducer, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import PageHeader from '../../components/PageHeader/PageHeader';

function AddDataFields() {
  const navigate = useNavigate();
  const formList = ["Details"];
  const [form, setForm] = useState(formList[0]);
  const [data, setData] = useReducer(
    (prev, next) => ({
        ...prev, ...next
    }),
    {
        FieldName: "",
        FieldType: "",
        TriggerAPI: false,
        ApiUrl: ""
    }
)
  return (
    <>
      <div style={{ position: "fixed", width: "100%" }}>
        <PageHeader
          title={<div className="text-[17px]">Data Fields Information</div>}
        />
      </div>
      <div className="document-block">
        <div className="flex m-5 justify-between items-center">
          <div>
            <div className="document-tabs flex">
              {formList.map((item, index) => (
                <div
                  key={index}
                  className={form === item ? "active" : ""}
                  onClick={() => setForm(item)}
                >
                  {item}
                </div>
              ))}
            </div>
          </div>
          <div className=" justify-between items-center ">
            <div className="button-block" style={{ width: "100%" }}>
              <button className="themeBtn">Duplicate</button>
              <button
                className="themeBtn"
                onClick={() => {
                  handleSave(differentialPRecord);
                }}
              >
                Save
              </button>
              <button
                className="themeBtn"
                onClick={() => navigate("/data-fields/manage")}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>

        {form === formList[0] ? (
          <div className="document-form">
            <div className="sub-head">Data Fields Information</div>
            <div className="personal-info">
              <div className="section-body">
                <div className="group-input">
                  <label>
                    <div className="required"></div>
                    Field Name
                  </label>
                  <input
                    value={data.FieldName}
                    onChange={(e) => setData({ FieldName: e.target.value })}
                    type="text"
                    required
                  />
                </div>
                <div className="group-input">
                  <label>
                    <div className="required"></div>
                    Field Type
                  </label>
                  <select
                    onChange={(e) => setData({ FieldType: e.target.value })}
                  >
                    <option value="">-- Select --</option>
                    <option value="String">String</option>
                    <option value="Data">Date</option>
                    <option value="Number">Number</option>
                    <option value="File">File</option>
                    <option value="single Selection">Single Selection</option>
                  </select>
                </div>
                <div className="dual-group-input">
                  <div className="group-input-2">
                    <label>Trigger API</label>
                    <input
                      checked={data.TriggerApi}
                      onChange={() => handleInputChange("TriggerAPI")}
                      type="checkbox"
                    />
                  </div>
                  <div className="group-input">
                    <label>API URL</label>
                    <input
                      value={data.ApiUrl}
                      onChange={(e) => setData({ ApiUrl: e.target.value })}
                      type="url"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : (
          ""
        )}
      </div>
    </>
  );
}

export default AddDataFields;
