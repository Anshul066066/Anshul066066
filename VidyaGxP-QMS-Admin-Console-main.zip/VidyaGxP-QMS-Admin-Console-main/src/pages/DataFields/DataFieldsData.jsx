export const tableHead = [
    {
        th: 'Row #'
    }, {
        th: 'Field Name'
    }, {
        th: 'Field Type'
    }, {
        th: 'Action'
    },
]

export const tableBody = [
    {
        id: 1,
        fieldName: 'Test',
        fieldType: 'String'
    }
]