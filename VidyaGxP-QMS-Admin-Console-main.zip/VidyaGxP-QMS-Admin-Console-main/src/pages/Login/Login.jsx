import { useEffect } from "react";
import { Envelope, PasswordLock } from "../../components/Icons";
import "../../Default.css";
import "./Login.css";
import { LoginAPI } from "../../assets/login/login";
import { useState } from "react";
import apiService from "../../api/apiService";
import { useNavigate } from "react-router-dom";
import DateRangeIcon from '@mui/icons-material/DateRange';
import { useTimezoneSelect, allTimezones } from 'react-timezone-select'


const labelStyle = 'original'
const timezones = {
    ...allTimezones,
    'India': 'Mumbai'
}

function Login() {
    const navigate = useNavigate();

    //======== For Date And Time========//
    const { options, parseTimezone } = useTimezoneSelect({ labelStyle, timezones })




    // ================================= // 

    const [email, setEmail] = useState();
    const [password, setPassword] = useState();


    const handleSubmit = async () => {
        if (loginData.email === "Gaurav" && loginData.password === "Gaurav") navigate("/person/manage");
        try {
            const response = await apiService.login(loginData);
            console.log("Login successful:", response);
            localStorage.setItem("token", response.token);
            window.location.href = "/person/manage";
        } catch (error) {
            console.error("Login failed:", error);
        }
    };

    //   const handleSubmit2 = () => {
    //     window.location.href = "/";
    //   };

    //   const LoginApiCall = () => {
    //     LoginAPI(loginData).then((res) => {
    //       console.log(14, res);
    //       localStorage.setItem("token", res.data.token);
    //       if (localStorage.getItem("token")) {
    //         handleSubmit();
    //       } else {
    //         handleSubmit2();
    //       }
    //     });
    //   };

    const loginData = {
        email: email,
        password: password
    }
    const LoginApiCall = () => {
        handleSubmit()
        LoginAPI(loginData).then((res) => {
            console.log(14, res)
            localStorage.setItem('token', res.data.token)

            // if (localStorage.getItem('token')) {
            //     
            // } else {

            //     handleSubmit2() 

            // }

            // handleSubmit()
        })
    }

    const [loginEmailOrPhone, setLoginEmailOrPhone] = useState();
    console.log(85,loginEmailOrPhone)
    const [data, setData] = useState(true);
    const [disabled, setDisabled] = useState(false);

    const toggleDisable = () => {
        setDisabled(!disabled);
    };
    const Clicked = () => {
        setData(!data);
        toggleDisable()
    };
  

    return (
        <>

            <div id="admin-console-login-page">
                <div className="login-form-block">
                    <div className="top-block">
                        <div className="logo">
                            <img src="/vidyagxplogo.png" alt="..." />
                        </div>
                        <div className="head">
                            Welcome to Admin Console
                        </div>
                    </div>
                    <form>
                        <div className="group-input">
                            <label>{Envelope(20, '#EB7F00')}</label>
                            <input type="text" placeholder="Enter Your User ID" disabled={disabled}
                                onChange={(e) => setEmail(e.target.value)}

                            />
                        </div>

                        <div className="group-input ">
                            <label>{PasswordLock(20, '#EB7F00')}</label>
                            <input type="password" placeholder="Enter Your Password" disabled={disabled}
                                onChange={(e) => setPassword(e.target.value)}
                            />

                        </div>

                        <div className="mb-3 flex " style={{ justifyContent: "space-between" }}><a style={{ color: "blue", cursor: "pointer" }}>Forget Password ?</a>
                            {data ? (<a style={{ color: "blue", cursor: "pointer" }} onClick={Clicked}> Login With OTP?</a>)
                                : (<a style={{ color: "blue", cursor: "pointer" }} onClick={Clicked}> Cancel</a>)}
                        </div>
                        {
                            data ? (
                                ""
                            ) :

                                (
                                    <div className="group-input">
                                        <label>{Envelope(20, '#EB7F00')}</label>
                                        <input type="text" placeholder="Enter Your Mail or Number"
                                            onChange={(e) => setLoginEmailOrPhone(e.target.value)} />

                                    </div>
                                )
                        }

                        <div className="group-input flex"  >
                            <div>
                                <DateRangeIcon sx={{ color: "#EB7F00" }} />
                            </div>
                            <div style={{ maxWidth: "25vw" }}>
                                <select onChange={(e) => parseTimezone(e.target.value)} >
                                    {options.map(option => (
                                        <>
                                            <option key={option.value} value={option.value}>{option.label}</option>
                                        </>
                                    ))}
                                </select>
                            </div>

                        </div>

                        <div>
                            <div className="submit-btn"
                                //onClick={handleSubmit}
                                onClick={()=>LoginApiCall()}
                            >Login</div>
                        </div>
                    </form>
                </div>
            </div>
        </>
    );
}

export default Login;
