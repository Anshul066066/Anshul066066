import React, { useState, useEffect } from 'react';
import { TextField, Button } from '@mui/material';
import PhoneInput from 'react-phone-input-2';
import 'react-phone-input-2/lib/style.css';
import Box from '@mui/material/Box';
import FormControl from '@mui/material/FormControl';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { Envelope } from '../../components/Icons';
// import VerificationInput from "react-verification-input";

function OtpVerification() {
  const [open, setOpen] = useState(false);
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [value, setValue] = useState('');
  const [isNumber, setIsNumber] = useState(false);
  const [otp, setOtp] = useState('');
  const [resendDisabled, setResendDisabled] = useState(false);
  const [timer, setTimer] = useState(60);

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const handleChange = (event) => {
    const input = event.target.value;
    // Ensure input is a number and has a length not greater than 6
    const sanitizedInput = input.replace(/\D/g, '').slice(0, 6);
    setOtp(sanitizedInput);
  };

  const validateEmail = (email) => {
    // Regular expression for email validation
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
  };

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handleResendClick = () => {
    setResendDisabled(true);
    setTimer(60);
  };

  useEffect(() => {
    let intervalId;
    if (resendDisabled) {
      intervalId = setInterval(() => {
        setTimer((prevTimer) => {
          if (prevTimer === 0) {
            clearInterval(intervalId);
            setResendDisabled(false);
          }
          return Math.max(0, prevTimer - 1);
        });
      }, 1000);
    }

    return () => clearInterval(intervalId);
  }, [resendDisabled]);

  return (
    <>
      <div id="admin-console-login-page">
        <div className="login-form-block">
          <div className="top-block">
            <div className="logo">
              <img src="/vidyagxplogo.png" alt="..." />
            </div>
            <div style={{ fontWeight: 'bold',fontSize: "1.5rem",textTransform: "uppercase"}} className="head">
              Otp Verification
            </div>
          </div>
          <form>
            <Box sx={{ minWidth: 120 }}>
              <FormControl fullWidth></FormControl>
            </Box>
            {isNumber === false ? (
              <>
                <div style={{ marginBottom: "0px" }} className="group-input">
                  <label>{Envelope(30, '#EB7F00')}</label>
                  <input
                    type="email"
                    placeholder="Ayush***@gmail.com"
                    value={email}
                    onChange={handleEmailChange}
                  />
                </div>
                {email && !validateEmail(email) && (
                  <p style={{ color: 'red', padding: '0', margin: '7px', fontWeight: "bold", fontSize: "14px" }}>
                    Please enter a valid email
                  </p>
                )}
                <div
                  style={{
                    color: 'black',
                    marginBottom: '30px',
                    cursor: 'pointer',
                    marginTop: '20px'
                  }}
                  onClick={() => setIsNumber(true)}
                >
                  Continue with Phone Number
                </div>
              </>
            ) : null}

            {isNumber === true ? (
              <>
                <div style={{ marginBottom: '20px', border: '2px solid black', padding: '5px', borderRadius: '5px' }}>
                  <PhoneInput
                    country={'in'}
                    countryCodeEditable={false}
                    placeholder="enter your phone number"
                    dropdownStyle={{ top: '-200px' }}
                  />
                </div>
                <div
                  style={{
                    color: 'black',
                    marginBottom: '30px',
                    cursor: 'pointer',
                  }}
                  onClick={() => setIsNumber(false)}
                >
                  Continue with Email
                </div>
              </>
            ) : null}

            <Button className='otpbtn' sx={{ width: '100%',backgroundColor: 'black',color: 'white','&:hover': {backgroundColor: '#EB7F00',  }, }} variant="contained" onClick={handleClickOpen}>
              Continue
            </Button>
          </form>
        </div>
      </div>

      <Dialog
        open={open}
        onClose={handleClose}
        PaperProps={{
          component: 'form',
          onSubmit: (event) => {
            event.preventDefault();
            const formData = new FormData(event.currentTarget);
            const formJson = Object.fromEntries(formData.entries());
            const email = formJson.email;
            console.log(email);
            handleClose();
          },
          style: {
            background: 'linear-gradient(to bottom, #add8e6, #ffffff)',
            color: '#000000',
          },
        }}
      >
        <DialogTitle>Verify Code</DialogTitle>
        <DialogContent>
          <DialogContentText>Enter the verification code we sent to</DialogContentText>
          <small>788****6252</small>
          {/* <VerificationInput /> */}
          <TextField
          
            autoFocus
            required
            margin="dense"
            id="otp"
            name="otp"
            label="Enter Code"
            value={otp}
            onChange={handleChange}
            type="text"
            fullWidth
            variant="standard"
            inputProps={{ maxLength: 6 }}
            error={otp.length !== 6}
            helperText={otp.length !== 6 ? 'Please enter a 6-digit code' : ''}
          />

          <div style={{ fontSize: "13px" }}>
            {!resendDisabled ? "Don't received OTP? " : null}
            <span onClick={!resendDisabled ? handleResendClick : null} style={{ cursor: resendDisabled ? 'not-allowed' : 'pointer', color: resendDisabled ? 'black' : 'blue' }}>Resend OTP</span>
            {resendDisabled ? ` in ${timer} seconds` : null}
          </div>

        </DialogContent>
        <DialogActions style={{ margin: '10px', marginLeft: '30px' }}>
          <Button color="error" variant="outlined" onClick={handleClose}>
            Cancel
          </Button>
          <Button variant="outlined" color="success" type="submit">
            Verify
          </Button>
        </DialogActions>
      </Dialog>
    </>
  );
}

export default OtpVerification;
