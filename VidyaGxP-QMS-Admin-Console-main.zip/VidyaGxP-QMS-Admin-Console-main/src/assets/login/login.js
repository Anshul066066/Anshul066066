import { BASE_URL } from "../BaseURL";
import axios from 'axios'
export const LoginAPI = async (data)=>{
let res;
try{
    const url = BASE_URL+'/v1/auth/signin'
    res = await axios.post(url,data)
}
catch(error){
    res = error
}
return res;
}