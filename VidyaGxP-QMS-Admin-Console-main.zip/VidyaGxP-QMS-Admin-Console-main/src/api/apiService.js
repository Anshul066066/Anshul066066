import axios from "axios";

const BASE_URL = "http://localhost:9018/qms-app/api/v1"; // Base URL for your APIs
const token = localStorage.getItem("token");
const apiService = {
  login: async (data) => {
    try {
      const response = await axios.post(`${BASE_URL}/auth/signin`, data);
      return response.data;
    } catch (error) {
      throw error;
    }
  },
  addPerson: async (data) => {
    // console.log(token);
    try {
      
      const response = await axios.post("http://localhost:9018/qms-app/Person/create", data, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      return response.data;
    } catch (error) {
      throw error;
    }
  },
  getallPersons: async () => {
    try {
      const response = await axios.get("http://localhost:9018/qms-app/Person/create", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (error) {
      throw error;
    }
  },
};

export default apiService;
